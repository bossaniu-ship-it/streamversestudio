'use client';

import { useMemo, useState } from 'react';
import ShowCard from './ShowCard';
import CatalogControls from './CatalogControls';
import { attachLatestEpisodes, filterGenre, sortShows } from '@/lib/catalog';

export default function ShowsCatalog({ shows, episodes }) {
  const [genre, setGenre] = useState('All');
  const [sort, setSort] = useState('latest');
  const catalog = useMemo(() => attachLatestEpisodes(shows, episodes), [shows, episodes]);
  const visible = useMemo(() => sortShows(filterGenre(catalog, genre), sort), [catalog, genre, sort]);

  return (
    <div className="space-y-6">
      <CatalogControls genre={genre} setGenre={setGenre} sort={sort} setSort={setSort} showSort />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {visible.map((show, i) => <ShowCard key={show.id || show.title || i} show={show} priority={i < 2} />)}
      </div>
      {!visible.length && <div className="py-20 text-center text-sm text-muted">No shows match that filter.</div>}
    </div>
  );
}
