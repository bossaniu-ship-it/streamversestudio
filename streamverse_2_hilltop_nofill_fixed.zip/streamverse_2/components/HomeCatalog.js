'use client';

import { useMemo, useState } from 'react';
import { Clapperboard, Sparkles, Tv2 } from 'lucide-react';
import HeroSection from './HeroSection';
import EpisodeCard from './EpisodeCard';
import ShowCard from './ShowCard';
import CatalogControls from './CatalogControls';
import StatsBar from './StatsBar';
import { filterGenre, sortEpisodes, sortShows, attachLatestEpisodes } from '@/lib/catalog';

export default function HomeCatalog({ history, activeShows }) {
  const [genre, setGenre] = useState('All');
  const [episodeSort, setEpisodeSort] = useState('latest');
  const [showSort, setShowSort] = useState('latest');

  const shows = useMemo(() => attachLatestEpisodes(activeShows, history), [activeShows, history]);
  const filteredEpisodes = useMemo(() => sortEpisodes(filterGenre(history, genre), episodeSort), [history, genre, episodeSort]);
  const filteredShows = useMemo(() => sortShows(filterGenre(shows, genre), showSort), [shows, genre, showSort]);
  const hero = filteredEpisodes[0] || history?.[0] || null;

  return (
    <>
      {hero && <HeroSection episode={hero} />}

      {shows.length > 0 && (
        <div className="space-y-5">
          <div className="flex items-center gap-2">
            <Clapperboard size={17} className="text-violet-light" />
            <div>
              <h2 className="font-display text-2xl font-bold text-white">Shows</h2>
              <p className="text-xs text-muted mt-0.5">Enter a collection to explore every release in order.</p>
            </div>
          </div>
          <CatalogControls genre={genre} setGenre={setGenre} sort={showSort} setSort={setShowSort} showSort />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filteredShows.map((show, i) => <ShowCard key={show.id || show.title || i} show={show} priority={i < 2} />)}
          </div>
        </div>
      )}

      <div className="space-y-5 pt-3">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-violet-light" />
          <div>
            <h2 className="font-display text-2xl font-bold text-white">Recent Releases</h2>
            <p className="text-xs text-muted mt-0.5">The latest episodes across StreamVerse Studio.</p>
          </div>
        </div>
        <CatalogControls genre={genre} setGenre={setGenre} sort={episodeSort} setSort={setEpisodeSort} />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEpisodes.map((ep, i) => <EpisodeCard key={ep.id || i} episode={ep} priority={i < 3} />)}
        </div>
      </div>

      {activeShows?.length > 0 && <StatsBar shows={activeShows} totalEpisodes={history?.length || 0} />}
      {!history?.length && <div className="flex items-center justify-center py-20 text-muted"><Tv2 size={26} className="mr-2" />No releases yet.</div>}
    </>
  );
}
