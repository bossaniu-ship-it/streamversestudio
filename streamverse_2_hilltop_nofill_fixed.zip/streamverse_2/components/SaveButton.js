'use client';

import { Bookmark, Loader2 } from 'lucide-react';
import { useAuth } from './AuthContext';
import { useState } from 'react';

export default function SaveButton({ episodeId, compact = false, className = '' }) {
  const { user, loading, savedIds, toggleSaved } = useAuth();
  const [busy, setBusy] = useState(false);
  if (loading || !user || !episodeId) return null;
  const saved = savedIds.has(String(episodeId));
  const handle = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (busy) return;
    setBusy(true);
    try { await toggleSaved(episodeId); } catch (err) { console.warn('[StreamVerse] save episode:', err.message); }
    finally { setBusy(false); }
  };
  return (
    <button type="button" onClick={handle} disabled={busy} aria-label={saved ? 'Remove from My List' : 'Save episode'} title={saved ? 'Remove from My List' : 'Save to My List'}
      className={`${compact ? 'px-2.5 py-1.5 rounded-lg' : 'px-3 py-2 rounded-xl'} inline-flex items-center gap-1.5 text-[11px] font-medium border backdrop-blur transition-all ${saved ? 'bg-violet/20 text-violet-light border-violet/30' : 'bg-black/35 text-white/70 border-white/10 hover:text-white hover:border-white/20'} ${className}`}>
      {busy ? <Loader2 size={13} className="animate-spin" /> : <Bookmark size={13} className={saved ? 'fill-current' : ''} />}
      {!compact && <span>{saved ? 'Saved' : 'Save'}</span>}
    </button>
  );
}
