'use client';

import { useEffect, useRef, useState } from 'react';

export default function PreviewVideo({
  src,
  poster,
  title,
  priority = false,
  className = '',
  overlay = false,
  showSoundHint = false,
}) {
  const videoRef = useRef(null);
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !src) return;

    let observer;
    const start = () => {
      video.muted = true;
      video.defaultMuted = true;
      const promise = video.play();
      if (promise?.catch) promise.catch(() => {});
    };

    if (typeof IntersectionObserver === 'undefined' || priority) {
      start();
    } else {
      observer = new IntersectionObserver((entries) => {
        const visible = entries[0]?.isIntersecting;
        if (visible) start();
        else video.pause();
      }, { rootMargin: '160px 0px', threshold: 0.05 });
      observer.observe(video);
    }

    return () => observer?.disconnect();
  }, [src, priority]);

  if (!src || failed) {
    return poster ? (
      <img src={poster} alt="" aria-hidden="true" className={className} />
    ) : null;
  }

  return (
    <>
      <video
        ref={videoRef}
        src={src}
        poster={poster || undefined}
        className={className}
        autoPlay
        muted
        loop
        playsInline
        preload={priority ? 'auto' : 'metadata'}
        controls={false}
        onLoadedData={() => {
          setReady(true);
          const video = videoRef.current;
          video?.play?.().catch(() => {});
        }}
        onCanPlay={() => videoRef.current?.play?.().catch(() => {})}
        onError={() => setFailed(true)}
        aria-label={`${title || 'Show'} preview`}
      />
      {!ready && poster && (
        <img
          src={poster}
          alt=""
          aria-hidden="true"
          className={`${className} absolute inset-0 pointer-events-none`}
        />
      )}
      {overlay && <div className="absolute inset-0 bg-black/10 pointer-events-none" />}
      {showSoundHint && ready && (
        <span className="absolute bottom-3 right-3 rounded-full bg-black/55 backdrop-blur px-2 py-1 text-[10px] text-white/75 pointer-events-none">
          Silent preview
        </span>
      )}
    </>
  );
}
