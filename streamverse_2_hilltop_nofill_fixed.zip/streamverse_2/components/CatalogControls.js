'use client';

import { ArrowDownUp, SlidersHorizontal } from 'lucide-react';

export default function CatalogControls({ genre, setGenre, sort, setSort, showSort = false }) {
  const genres = ['All', 'Drama', 'Thriller', 'Sci-Fi', 'Rom-Com', 'Horror', 'Action', 'Comedy'];
  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <SlidersHorizontal size={14} className="text-muted shrink-0" />
        {genres.map((g) => (
          <button
            key={g}
            type="button"
            onClick={() => setGenre(g)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${genre === g ? 'bg-violet/20 text-violet-light border border-violet/30' : 'glass border border-white/8 text-muted hover:text-white hover:border-white/20'}`}
          >
            {g}
          </button>
        ))}
      </div>
      <label className="inline-flex items-center gap-2 self-start sm:self-auto shrink-0">
        <ArrowDownUp size={13} className="text-muted" />
        <select value={sort} onChange={(e) => setSort(e.target.value)} className="bg-surface/90 text-xs text-white border border-white/10 rounded-lg px-3 py-2 outline-none">
          {showSort ? (
            <>
              <option value="latest">Latest release</option>
              <option value="title">A–Z</option>
              <option value="episodes">Most episodes</option>
            </>
          ) : (
            <>
              <option value="latest">Newest first</option>
              <option value="oldest">Oldest first</option>
              <option value="order">Series order</option>
              <option value="title">Title A–Z</option>
            </>
          )}
        </select>
      </label>
    </div>
  );
}
