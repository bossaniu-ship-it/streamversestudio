'use client';

import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { fetchMe, login as apiLogin, register as apiRegister, logout as apiLogout, getToken } from '@/lib/authApi';
import { clientBackend } from '@/lib/api';

const AuthContext = createContext({
  user: null,
  loading: true,
  login: async () => {},
  register: async () => {},
  logout: () => {},
  refresh: async () => {},
  savedIds: new Set(),
  refreshSaved: async () => {},
  toggleSaved: async () => {},
});

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [savedIds, setSavedIds] = useState(() => new Set());

  const refresh = useCallback(async () => {
    if (!getToken()) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const u = await fetchMe();
      setUser(u);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const refreshSaved = useCallback(async () => {
    const token = getToken();
    if (!token) { setSavedIds(new Set()); return new Set(); }
    try {
      const r = await fetch(`${clientBackend()}/api/account/favorites`, { headers: { Authorization: `Bearer ${token}` }, cache: 'no-store' });
      const d = await r.json().catch(() => null);
      if (!r.ok || !d?.ok) throw new Error(d?.error || 'Could not load saved episodes');
      const ids = new Set((d.favorites || []).map(x => String(x.episodeId)));
      setSavedIds(ids);
      return ids;
    } catch {
      setSavedIds(new Set());
      return new Set();
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { if (user) refreshSaved(); else setSavedIds(new Set()); }, [user, refreshSaved]);

  const login = useCallback(async (creds) => {
    const data = await apiLogin(creds);
    setUser(data.user);
    await refreshSaved();
    return data.user;
  }, []);

  const register = useCallback(async (fields) => {
    return apiRegister(fields);
  }, []);

  const logout = useCallback(() => {
    apiLogout();
    setSavedIds(new Set());
    setUser(null);
  }, []);

  const toggleSaved = useCallback(async (episodeId) => {
    const id = String(episodeId || '').trim();
    const token = getToken();
    if (!id || !token) throw new Error('Sign in to save episodes');
    const exists = savedIds.has(id);
    const r = await fetch(`${clientBackend()}/api/account/favorites/${encodeURIComponent(id)}`, {
      method: exists ? 'DELETE' : 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
    const d = await r.json().catch(() => null);
    if (!r.ok || !d?.ok) throw new Error(d?.error || (exists ? 'Could not remove saved episode' : 'Could not save episode'));
    setSavedIds(prev => {
      const next = new Set(prev);
      if (exists) next.delete(id); else next.add(id);
      return next;
    });
    return !exists;
  }, [savedIds]);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refresh, savedIds, refreshSaved, toggleSaved }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
