'use client';

import Link from 'next/link';
import { Clapperboard, Film, Layers, Play } from 'lucide-react';
import GenreBadge from './GenreBadge';
import PreviewVideo from './PreviewVideo';

const genreGradients = {
  romcom: 'from-pink-500/20 to-rose-500/10',
  thriller: 'from-red-500/20 to-orange-500/10',
  'sci-fi': 'from-cyan-500/20 to-blue-500/10',
  drama: 'from-amber-500/20 to-yellow-500/10',
};

function showHref(show) {
  return show?.id != null
    ? `/shows/${encodeURIComponent(String(show.id))}`
    : `/shows?title=${encodeURIComponent(show?.title || '')}`;
}

export default function ShowCard({ show, priority = false }) {
  const g = (show.genre || '').toLowerCase();
  const grad = genreGradients[g] || 'from-violet/20 to-violet/5';
  const preview = show.latestEpisode?.previewUrl || show.previewUrl || null;
  const thumb = show.latestEpisode?.thumbnailUrl || show.thumbnailUrl || null;
  const latestEpisode = show.latestEpisode;

  return (
    <Link
      href={showHref(show)}
      className="group block glass rounded-2xl overflow-hidden border border-white/5 hover:border-violet/30 transition-all duration-300 card-lift"
    >
      <div className={`relative aspect-video bg-gradient-to-br ${grad} overflow-hidden`}>
        {preview ? (
          <PreviewVideo
            src={preview}
            poster={thumb}
            title={show.title}
            priority={priority}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            overlay
          />
        ) : thumb ? (
          <img src={thumb} alt="" className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading={priority ? 'eager' : 'lazy'} />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <Clapperboard size={42} className="text-violet-light/25" />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-transparent pointer-events-none" />
        <div className="absolute left-3 top-3 flex items-center gap-2">
          <GenreBadge genre={show.genre} size="xs" />
          <span className="text-[10px] px-2 py-1 rounded-full bg-black/55 border border-white/10 text-white/75 backdrop-blur">
            Series
          </span>
        </div>

        <div className="absolute left-4 right-4 bottom-4 flex items-end justify-between gap-3">
          <div>
            <p className="text-[10px] uppercase tracking-[0.18em] text-white/55">Latest preview</p>
            <p className="mt-1 text-sm font-semibold text-white line-clamp-1">
              {latestEpisode?.episodeTitle || `S${show.current_season || 1}E${show.current_episode || 1}`}
            </p>
          </div>
          <span className="w-9 h-9 shrink-0 rounded-full bg-white/12 backdrop-blur flex items-center justify-center border border-white/15 group-hover:bg-violet/80 transition-colors">
            <Play size={14} className="fill-white text-white ml-0.5" />
          </span>
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="min-w-0">
            <h3 className="font-display font-bold text-white text-base leading-tight truncate">{show.title}</h3>
            {latestEpisode?.postedAt && <p className="text-[11px] text-muted mt-1">Latest release available to watch</p>}
          </div>
          <span className={`shrink-0 text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${
            show.status === 'active'
              ? 'bg-green-500/20 text-green-400 border border-green-500/30'
              : 'bg-muted/20 text-muted border border-white/10'
          }`}>
            {show.status === 'active' ? '● Airing' : 'Completed'}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/[0.03] border border-white/5">
            <Layers size={12} className="text-violet-light mb-1" />
            <span className="text-sm font-bold text-white">{show.current_season || 1}</span>
            <span className="text-[10px] text-muted">Season</span>
          </div>
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/[0.03] border border-white/5">
            <Film size={12} className="text-cyan mb-1" />
            <span className="text-sm font-bold text-white">{show.posted_episode_count ?? show.episode_count ?? 0}</span>
            <span className="text-[10px] text-muted">Episodes</span>
          </div>
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/[0.03] border border-white/5">
            <Clapperboard size={12} className="text-gold mb-1" />
            <span className="text-sm font-bold text-white">S{latestEpisode?.seasonNumber || show.current_season || 1}E{latestEpisode?.episodeNumber || show.current_episode || 1}</span>
            <span className="text-[10px] text-muted">Latest</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
