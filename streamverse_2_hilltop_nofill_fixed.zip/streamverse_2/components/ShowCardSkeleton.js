export default function ShowCardSkeleton() {
  return (
    <div className="glass rounded-2xl overflow-hidden border border-white/5">
      <div className="aspect-video shimmer" />
      <div className="p-4 space-y-3">
        <div className="h-4 w-2/3 rounded shimmer" />
        <div className="h-3 w-1/2 rounded shimmer" />
        <div className="grid grid-cols-3 gap-2 pt-1">
          <div className="h-14 rounded-lg shimmer" />
          <div className="h-14 rounded-lg shimmer" />
          <div className="h-14 rounded-lg shimmer" />
        </div>
      </div>
    </div>
  );
}
