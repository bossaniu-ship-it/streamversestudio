import ShowCardSkeleton from '@/components/ShowCardSkeleton';

export default function Loading() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="space-y-3"><div className="h-3 w-28 rounded shimmer" /><div className="h-10 w-72 rounded shimmer" /><div className="h-4 w-96 max-w-full rounded shimmer" /></div>
      <div className="h-12 rounded-xl shimmer" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /></div>
    </div>
  );
}
