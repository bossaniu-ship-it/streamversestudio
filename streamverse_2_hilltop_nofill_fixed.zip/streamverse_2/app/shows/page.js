import { Suspense } from 'react';
import { fetchHistory } from '@/lib/api';
import ShowsCatalog from '@/components/ShowsCatalog';
import ShowCardSkeleton from '@/components/ShowCardSkeleton';
import { Clapperboard } from 'lucide-react';

export const metadata = {
  title: 'Shows — StreamVerse Studio',
  description: 'Browse every original series on StreamVerse Studio.',
};

async function ShowsData() {
  try {
    const data = await fetchHistory();
    return <ShowsCatalog shows={data?.activeShows || []} episodes={data?.history || []} />;
  } catch (e) {
    return <div className="py-24 text-center text-sm text-muted">Couldn&apos;t load the shows: {e.message}</div>;
  }
}

function ShowsLoading() {
  return <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /></div>;
}

export default function ShowsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2"><Clapperboard size={18} className="text-violet-light" /><span className="text-xs text-muted tracking-widest uppercase font-semibold">The Library</span></div>
        <h1 className="font-display text-4xl font-black text-white">All <span className="gradient-text">Shows</span></h1>
        <p className="text-sm text-muted mt-2">Choose a series to enter its complete episode collection.</p>
      </div>
      <Suspense fallback={<ShowsLoading />}><ShowsData /></Suspense>
    </div>
  );
}
