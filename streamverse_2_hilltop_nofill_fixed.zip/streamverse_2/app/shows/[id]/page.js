import Link from 'next/link';
import { ArrowLeft, Clapperboard, Play, CalendarDays, Film, Layers } from 'lucide-react';
import { fetchHistory } from '@/lib/api';
import EpisodeCard from '@/components/EpisodeCard';
import ShowCardSkeleton from '@/components/ShowCardSkeleton';
import { normalizeShow, sortEpisodes } from '@/lib/catalog';

function titleMatch(episode, show) {
  const a = String(episode.showTitle || episode.show_title || episode.title || '').trim().toLowerCase();
  const b = String(show.title || '').trim().toLowerCase();
  return a && b && a === b;
}

export async function generateMetadata({ params }) {
  const { id } = await params;
  try {
    const data = await fetchHistory();
    const show = (data.activeShows || []).map(normalizeShow).find(s => String(s.id) === String(id));
    return {
      title: show ? `${show.title} — StreamVerse Studio` : 'Series — StreamVerse Studio',
      description: show ? `Watch every episode of ${show.title} on StreamVerse Studio.` : 'Browse the full series collection on StreamVerse Studio.',
    };
  } catch {
    return { title: 'Series — StreamVerse Studio' };
  }
}

export default async function ShowPage({ params }) {
  const { id } = await params;
  const data = await fetchHistory();
  const shows = (data.activeShows || []).map(normalizeShow);
  const show = shows.find(s => String(s.id) === String(id));

  if (!show) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center">
        <Clapperboard size={42} className="mx-auto text-violet/40 mb-5" />
        <h1 className="font-display text-3xl font-bold text-white">Series not found</h1>
        <p className="text-sm text-muted mt-2">This collection may have been removed or is not published yet.</p>
        <Link href="/shows" className="inline-flex mt-6 items-center gap-2 px-5 py-3 rounded-xl bg-violet text-white text-sm font-semibold"><ArrowLeft size={16} /> Back to Shows</Link>
      </div>
    );
  }

  const episodes = (data.history || []).filter(ep => String(ep.showId ?? '') === String(show.id) || titleMatch(ep, show));
  const ordered = sortEpisodes(episodes, 'order');
  const latest = ordered[0] || null;

  const seasons = new Map();
  for (const episode of ordered) {
    const season = Number(episode.seasonNumber || 1);
    if (!seasons.has(season)) seasons.set(season, []);
    seasons.get(season).push(episode);
  }
  const seasonEntries = Array.from(seasons.entries()).sort((a, b) => b[0] - a[0]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link href="/shows" className="inline-flex items-center gap-2 text-xs text-muted hover:text-white mb-5 transition-colors"><ArrowLeft size={14} /> All Shows</Link>

      <section className="relative overflow-hidden rounded-3xl border border-white/10 glass-strong min-h-[46vh] flex items-end mb-10">
        {latest?.previewUrl ? (
          <video src={latest.previewUrl} poster={latest.thumbnailUrl || undefined} className="absolute inset-0 w-full h-full object-cover" autoPlay muted loop playsInline preload="auto" onCanPlay={e => e.currentTarget.play().catch(() => {})} />
        ) : latest?.thumbnailUrl ? (
          <img src={latest.thumbnailUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-void via-void/70 to-void/20" />
        <div className="absolute inset-0 bg-gradient-to-r from-void/85 via-void/30 to-transparent" />

        <div className="relative z-10 p-7 md:p-12 max-w-3xl">
          <div className="flex items-center gap-2 mb-4"><span className="text-[10px] uppercase tracking-[0.22em] text-violet-light">Series Collection</span><span className="text-white/25">•</span><span className="text-xs text-white/55">{episodes.length} {episodes.length === 1 ? 'episode' : 'episodes'}</span></div>
          <h1 className="font-display text-4xl md:text-6xl font-black text-white leading-none">{show.title}</h1>
          <div className="flex items-center gap-2 mt-4"><span className="px-2.5 py-1 rounded-full glass border border-white/10 text-xs text-white/75">{show.genre || 'Original'}</span><span className="text-xs text-white/55">Season {show.current_season || 1}</span></div>
          <p className="text-sm md:text-base text-white/65 max-w-2xl mt-5">Every published episode in one collection. Start with the latest release or explore the series from the beginning.</p>
          {latest?.id && <Link href={`/watch/${latest.id}`} className="inline-flex items-center gap-2 mt-7 px-6 py-3 rounded-xl bg-gradient-to-r from-violet to-violet-dark text-white font-semibold shadow-glow-violet"><Play size={17} className="fill-white" /> Watch Latest</Link>}
        </div>
      </section>

      <div className="grid grid-cols-3 gap-3 max-w-xl mb-10">
        <div className="glass rounded-xl border border-white/10 p-4"><Film size={15} className="text-cyan mb-2" /><p className="text-xl font-bold text-white">{episodes.length}</p><p className="text-[10px] uppercase tracking-wider text-muted">Episodes</p></div>
        <div className="glass rounded-xl border border-white/10 p-4"><Layers size={15} className="text-violet-light mb-2" /><p className="text-xl font-bold text-white">{seasonEntries.length}</p><p className="text-[10px] uppercase tracking-wider text-muted">Seasons</p></div>
        <div className="glass rounded-xl border border-white/10 p-4"><CalendarDays size={15} className="text-gold mb-2" /><p className="text-sm font-bold text-white mt-1">{latest ? new Date(latest.postedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—'}</p><p className="text-[10px] uppercase tracking-wider text-muted">Latest release</p></div>
      </div>

      <div className="flex items-center gap-3 mb-6"><Clapperboard size={17} className="text-violet-light" /><div><h2 className="font-display text-2xl font-bold text-white">Episodes</h2><p className="text-xs text-muted">Complete {show.title} collection</p></div></div>

      {seasonEntries.map(([season, seasonEpisodes]) => (
        <section key={season} className="mb-10">
          <div className="flex items-center gap-3 mb-4"><h3 className="font-display text-lg font-bold text-white">Season {season}</h3><span className="text-xs text-muted">{seasonEpisodes.length} {seasonEpisodes.length === 1 ? 'release' : 'releases'}</span></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {seasonEpisodes.map((episode, i) => <EpisodeCard key={episode.id || `${season}-${i}`} episode={episode} priority={i < 2} />)}
          </div>
        </section>
      ))}
    </div>
  );
}
