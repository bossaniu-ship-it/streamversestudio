import ShowCardSkeleton from '@/components/ShowCardSkeleton';

export default function Loading() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="h-4 w-24 rounded shimmer" />
      <div className="h-[46vh] rounded-3xl shimmer" />
      <div className="h-7 w-44 rounded shimmer" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /></div>
    </div>
  );
}
