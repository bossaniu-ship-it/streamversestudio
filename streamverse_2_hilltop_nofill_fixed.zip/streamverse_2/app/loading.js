import ShowCardSkeleton from '@/components/ShowCardSkeleton';
import SkeletonCard from '@/components/SkeletonCard';

export default function Loading() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-7">
      <div className="h-7 w-72 mx-auto rounded shimmer" />
      <div className="h-[56vh] rounded-3xl shimmer" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /></div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"><SkeletonCard /><SkeletonCard /><SkeletonCard /></div>
    </div>
  );
}
