import { Suspense } from 'react';
import { fetchHistory } from '@/lib/api';
import HomeCatalog from '@/components/HomeCatalog';
import SkeletonCard from '@/components/SkeletonCard';
import ShowCardSkeleton from '@/components/ShowCardSkeleton';
import { AlertCircle, Tv2 } from 'lucide-react';

async function Catalog() {
  try {
    const data = await fetchHistory();
    if (!data?.history?.length && !data?.activeShows?.length) {
      return <div className="col-span-full flex flex-col items-center justify-center py-24 gap-4"><div className="w-16 h-16 rounded-2xl glass border border-white/10 flex items-center justify-center"><Tv2 size={28} className="text-muted/60" /></div><p className="text-sm text-muted text-center max-w-xs">No releases yet. Check back soon — new cinema drops are coming.</p></div>;
    }
    return <HomeCatalog history={data.history || []} activeShows={data.activeShows || []} />;
  } catch (e) {
    return <div className="col-span-full flex flex-col items-center justify-center py-24 gap-4"><div className="w-16 h-16 rounded-2xl glass border border-white/10 flex items-center justify-center"><AlertCircle size={28} className="text-danger/70" /></div><p className="text-sm text-muted text-center max-w-md">Couldn&apos;t reach the cinema backend: {e.message}</p></div>;
  }
}

function LoadingGrid() {
  return (
    <>
      <div className="col-span-full"><div className="relative min-h-[60vh] rounded-3xl overflow-hidden shimmer" /></div>
      <div className="col-span-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /><ShowCardSkeleton /></div>
      <div className="col-span-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"><SkeletonCard /><SkeletonCard /><SkeletonCard /></div>
    </>
  );
}

export default function HomePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8 text-center">
        <h1 className="font-display text-5xl sm:text-6xl font-black text-white mb-3 leading-none">Stream<span className="gradient-text">Verse</span><span className="block text-2xl sm:text-3xl font-light text-muted mt-1 tracking-widest uppercase">Studio</span></h1>
        <p className="text-sm text-muted max-w-md mx-auto">Cinematic original series. New episodes daily.</p>
      </div>
      <Suspense fallback={<div className="grid grid-cols-1 gap-6"><LoadingGrid /></div>}>
        <Catalog />
      </Suspense>
    </div>
  );
}
