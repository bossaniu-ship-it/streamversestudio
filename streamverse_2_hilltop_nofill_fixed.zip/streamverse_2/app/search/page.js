import Link from 'next/link';
import { Search, Clapperboard, Sparkles, ArrowRight } from 'lucide-react';
import { searchCatalog } from '@/lib/api';
import EpisodeCard from '@/components/EpisodeCard';

export const metadata = { title: 'Search — StreamVerse Studio', description: 'Search StreamVerse Studio by shows, episodes, genres, stories and themes.' };

export default async function SearchPage({ searchParams }) {
  const params = await searchParams;
  const q = String(params?.q || '').trim();
  let data = { episodes: [], shows: [] };
  let error = '';
  if (q) {
    try { data = await searchCatalog(q, 50); } catch (e) { error = e.message; }
  }
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="max-w-4xl mb-10">
        <p className="text-xs uppercase tracking-[0.22em] text-violet-light font-semibold mb-2">Find your next story</p>
        <h1 className="font-display text-4xl md:text-5xl font-black text-white">Search the <span className="gradient-text">Studio</span></h1>
        <form className="relative mt-6">
          <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/35" />
          <input autoFocus defaultValue={q} name="q" placeholder="Try “romantic comedy”, “mystery”, “student”, or a show title…" className="w-full h-14 rounded-2xl bg-white/[.06] border border-white/10 pl-12 pr-5 text-base text-white placeholder:text-white/30 outline-none focus:border-violet/40" />
        </form>
        {q && <p className="text-xs text-muted mt-3">Smart matching across show titles, episode titles, genres, synopses and story themes.</p>}
      </div>

      {error && <div className="rounded-xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-200 mb-8">{error}</div>}

      {!q ? (
        <div className="glass rounded-3xl border border-white/10 p-10 text-center"><Sparkles size={28} className="mx-auto text-violet-light mb-4"/><h2 className="font-display text-xl font-bold text-white">Search by meaning, not just title</h2><p className="text-sm text-muted max-w-lg mx-auto mt-2">Use themes, genres, moods, story ideas or character situations. StreamVerse expands related terms and ranks the most relevant Episodes and Shows.</p></div>
      ) : data.shows?.length || data.episodes?.length ? (
        <div className="space-y-12">
          {data.shows?.length > 0 && <section><div className="flex items-end justify-between mb-5"><div><div className="flex items-center gap-2"><Clapperboard size={16} className="text-violet-light"/><h2 className="font-display text-2xl font-bold text-white">Shows</h2></div><p className="text-xs text-muted mt-1">Collections most closely related to “{q}”.</p></div><Link href="/shows" className="text-xs text-violet-light inline-flex items-center gap-1">Browse all <ArrowRight size={13}/></Link></div><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">{data.shows.map(show => <Link key={show.id} href={`/shows/${show.id}`} className="glass rounded-2xl border border-white/10 p-5 hover:border-violet/30 transition-colors group"><p className="text-[10px] uppercase tracking-widest text-violet-light">{show.genre || 'Original'}</p><h3 className="font-display text-xl font-bold text-white mt-2 group-hover:text-violet-light">{show.title}</h3><p className="text-xs text-muted mt-2">Open the complete collection →</p></Link>)}</div></section>}

          {data.episodes?.length > 0 && <section><div className="flex items-center gap-2 mb-5"><Sparkles size={16} className="text-violet-light"/><div><h2 className="font-display text-2xl font-bold text-white">Episodes</h2><p className="text-xs text-muted mt-1">Ranked by relevance to your search.</p></div></div><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">{data.episodes.map((ep,i)=><EpisodeCard key={ep.id || i} episode={ep} priority={i<3}/>)}</div></section>}
        </div>
      ) : <div className="glass rounded-3xl border border-white/10 p-10 text-center"><Search size={28} className="mx-auto text-white/20 mb-4"/><h2 className="font-display text-xl font-bold text-white">Nothing matched yet</h2><p className="text-sm text-muted mt-2">Try a broader theme, genre, character situation, or another phrase.</p></div>}
    </div>
  );
}
