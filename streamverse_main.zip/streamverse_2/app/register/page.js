'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Mail, Lock, User, Loader2, AlertCircle, MailCheck } from 'lucide-react';
import { useAuth } from '@/components/AuthContext';

export default function RegisterPage() {
  const searchParams = useSearchParams();
  const { register } = useAuth();

  const [displayName, setDisplayName] = useState('');
  const [email, setEmail]             = useState('');
  const [password, setPassword]       = useState('');
  const [error, setError]             = useState(null);
  const [submitting, setSubmitting]   = useState(false);
  const [done, setDone]               = useState(null); // success message

  const onSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const data = await register({ email, password, displayName });
      setDone(data.warning || data.message || 'Account created. Check your email to verify your address.');
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="max-w-md mx-auto px-4 sm:px-6 py-16">
        <div className="glass rounded-2xl border border-white/10 p-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet to-cyan flex items-center justify-center mx-auto mb-4 shadow-glow-violet">
            <MailCheck size={24} className="text-white" />
          </div>
          <h1 className="font-display text-xl font-bold text-white mb-2">Check your inbox</h1>
          <p className="text-sm text-muted mb-6">{done}</p>
          <Link href={`/login?next=${encodeURIComponent(searchParams.get('next') || '/account')}`} className="text-sm text-violet-light hover:underline">Back to sign in</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-16">
      <div className="glass rounded-2xl border border-white/10 p-8">
        <h1 className="font-display text-2xl font-bold text-white mb-1">Create your account</h1>
        <p className="text-sm text-muted mb-6">Free to join. Free to watch.</p>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted mb-1.5">Name (optional)</label>
            <div className="relative">
              <User size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="text"
                value={displayName}
                onChange={e => setDisplayName(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:border-violet/50 transition-colors"
                placeholder="Jamie"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted mb-1.5">Email</label>
            <div className="relative">
              <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:border-violet/50 transition-colors"
                placeholder="you@example.com"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted mb-1.5">Password</label>
            <div className="relative">
              <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="password"
                required
                minLength={8}
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:border-violet/50 transition-colors"
                placeholder="At least 8 characters"
              />
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2 px-3 py-2.5 rounded-xl bg-danger/10 border border-danger/20">
              <AlertCircle size={14} className="text-danger mt-0.5 flex-shrink-0" />
              <p className="text-xs text-danger">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300 disabled:opacity-60"
          >
            {submitting && <Loader2 size={14} className="animate-spin" />}
            Create Account
          </button>
        </form>

        <p className="text-xs text-muted text-center mt-6">
          Already have an account?{' '}
          <Link href={`/login?next=${encodeURIComponent(searchParams.get('next') || '/account')}`} className="text-violet-light hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
