'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Mail, Lock, Loader2, AlertCircle } from 'lucide-react';
import { useAuth } from '@/components/AuthContext';
import { resendVerification } from '@/lib/authApi';

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { login } = useAuth();

  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState(null);
  const [unverified, setUnverified] = useState(false);
  const [resent, setResent]     = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setUnverified(false);
    setSubmitting(true);
    try {
      await login({ email, password });
      router.push(searchParams.get('next') || '/account');
    } catch (err) {
      setError(err.message);
      setUnverified(!!err.unverified);
    } finally {
      setSubmitting(false);
    }
  };

  const onResend = async () => {
    try {
      await resendVerification(email);
      setResent(true);
    } catch {}
  };

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-16">
      <div className="glass rounded-2xl border border-white/10 p-8">
        <h1 className="font-display text-2xl font-bold text-white mb-1">Sign in</h1>
        <p className="text-sm text-muted mb-6">Welcome back to StreamVerse Studio.</p>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-muted mb-1.5">Email</label>
            <div className="relative">
              <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:border-violet/50 transition-colors"
                placeholder="you@example.com"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted mb-1.5">Password</label>
            <div className="relative">
              <Lock size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-sm text-white placeholder:text-muted/60 focus:outline-none focus:border-violet/50 transition-colors"
                placeholder="••••••••"
              />
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2 px-3 py-2.5 rounded-xl bg-danger/10 border border-danger/20">
              <AlertCircle size={14} className="text-danger mt-0.5 flex-shrink-0" />
              <div className="text-xs text-danger">
                {error}
                {unverified && (
                  <button type="button" onClick={onResend} className="block mt-1.5 underline hover:no-underline">
                    {resent ? 'Verification email sent' : 'Resend verification email'}
                  </button>
                )}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300 disabled:opacity-60"
          >
            {submitting && <Loader2 size={14} className="animate-spin" />}
            Sign In
          </button>
        </form>

        <p className="text-xs text-muted text-center mt-6">
          Don&apos;t have an account?{' '}
          <Link href={`/register?next=${encodeURIComponent(searchParams.get('next') || '/account')}`} className="text-violet-light hover:underline">Create one</Link>
        </p>
      </div>
    </div>
  );
}
