'use client';

import Link from 'next/link';
import { Play, Clock, Tv } from 'lucide-react';
import GenreBadge from './GenreBadge';
import { timeAgo } from '@/lib/api';

export default function EpisodeCard({ episode, priority = false }) {
  const thumb = episode.thumbnailUrl || null;
  const preview = episode.previewUrl || null;
  const hasId = !!episode.id;

  const href = hasId ? `/watch/${episode.id}` : null;

  const cardContent = (
    <div className="group glass rounded-2xl overflow-hidden card-lift cursor-pointer border border-white/5 hover:border-violet/30 transition-colors duration-300">
      {/* Thumbnail */}
      <div className="relative aspect-video bg-gradient-to-br from-surface to-nebula overflow-hidden">
        {preview ? (
          <video
            src={preview}
            poster={thumb || undefined}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            autoPlay
            muted
            loop
            playsInline
            preload={priority ? 'auto' : 'metadata'}
            aria-label={`${episode.episodeTitle || episode.title} preview`}
          />
        ) : thumb ? (
          <img
            src={thumb}
            alt={episode.episodeTitle || episode.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading={priority ? 'eager' : 'lazy'}
            onError={(e) => { e.target.style.display = 'none'; }}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-violet/10 to-cyan/5">
            <Tv size={40} className="text-violet/30" />
          </div>
        )}

        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-cinematic opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Play button */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
          <div className="w-14 h-14 rounded-full bg-violet/90 flex items-center justify-center shadow-glow-violet backdrop-blur-sm transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play size={22} className="text-white fill-white ml-1" />
          </div>
        </div>

        {/* Genre badge top-left */}
        <div className="absolute top-3 left-3">
          <GenreBadge genre={episode.genre} size="xs" />
        </div>

        {/* Time top-right */}
        <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm">
          <Clock size={10} className="text-muted" />
          <span suppressHydrationWarning className="text-[10px] text-muted">{timeAgo(episode.postedAt)}</span>
        </div>

        {/* Episode label */}
        <div className="absolute bottom-3 left-3 right-3">
          {episode.scenes > 0 && (
            <div className="flex items-center gap-1 mb-1">
              <div className="flex gap-0.5">
                {Array.from({ length: Math.min(episode.scenes, 6) }).map((_, i) => (
                  <div key={i} className="w-4 h-0.5 rounded-full bg-violet/60" />
                ))}
              </div>
              <span className="text-[10px] text-muted">{episode.scenes} scenes</span>
            </div>
          )}
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <p className="text-xs text-violet-light font-medium mb-1 truncate">{episode.title}</p>
        <h3 className="font-display font-semibold text-white text-[15px] leading-snug mb-2 line-clamp-2 group-hover:text-violet-light transition-colors duration-200">
          {episode.episodeTitle || 'Untitled Episode'}
        </h3>
        {episode.synopsis && (
          <p className="text-xs text-muted line-clamp-2 leading-relaxed">{episode.synopsis}</p>
        )}

        <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
          <div className="flex items-center gap-1.5">
            {episode.facebookLink && (
              <a
                href={episode.facebookLink}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="text-[11px] text-cyan hover:text-cyan-light underline-offset-2 hover:underline transition-colors"
              >
                Facebook
              </a>
            )}
          </div>
          <span className="text-[11px] font-medium text-violet-light flex items-center gap-1">
            <Play size={10} className="fill-current" />
            {hasId ? 'Watch Now' : 'View'}
          </span>
        </div>
      </div>
    </div>
  );

  if (!href) return <div>{cardContent}</div>;
  return <Link href={href} className="block">{cardContent}</Link>;
}
