import { NextResponse } from 'next/server';

const ALLOWED_HOSTS = new Set([
  'vast.yomeno.xyz',
  'clickadilla.com',
]);

function isAllowedHost(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/\.$/, '');
  if (ALLOWED_HOSTS.has(host)) return true;
  return host.endsWith('.clickadilla.com');
}

function absolutize(raw, base) {
  try { return new URL(String(raw || '').trim(), base).toString(); } catch { return ''; }
}

function rewriteVastUrls(body, baseUrl, requestOrigin) {
  let rewritten = body;

  rewritten = rewritten.replace(
    /(<VASTAdTagURI\b[^>]*>)([\s\S]*?)(<\/VASTAdTagURI>)/gi,
    (full, openTag, rawValue, closeTag) => {
      const value = String(rawValue || '')
        .replace(/^\s*<!\[CDATA\[/i, '')
        .replace(/\]\]>\s*$/i, '')
        .trim();
      const absolute = absolutize(value, baseUrl);
      if (!absolute || !/^https:/i.test(absolute) || !requestOrigin) return full;
      return `${openTag}<![CDATA[/api/ads/vast?url=${encodeURIComponent(absolute)}]]>${closeTag}`;
    },
  );

  // Browser playback is allowed to try the CDN directly first. The player also
  // has a server-proxy fallback for MP4 media when the CDN rejects browser fetches.
  return rewritten;
}

export async function GET(request) {
  try {
    const source = request.nextUrl.searchParams.get('url');
    if (!source) return NextResponse.json({ ok: false, error: 'Missing VAST url' }, { status: 400 });

    let upstream;
    try { upstream = new URL(source); }
    catch { return NextResponse.json({ ok: false, error: 'Invalid VAST url' }, { status: 400 }); }

    if (upstream.protocol !== 'https:' || !isAllowedHost(upstream.hostname)) {
      return NextResponse.json({ ok: false, error: 'VAST host is not allowed' }, { status: 403 });
    }

    const incomingHeaders = request.headers;
    const forwardHeaders = {
      Accept: 'application/xml,text/xml;q=0.9,*/*;q=0.8',
      'User-Agent': incomingHeaders.get('user-agent') || 'StreamVerse-Studio-VAST-Proxy/2.0',
    };
    for (const name of ['referer', 'origin', 'accept-language']) {
      const value = incomingHeaders.get(name);
      if (value) forwardHeaders[name] = value;
    }
    const forwardedFor = incomingHeaders.get('x-forwarded-for');
    if (forwardedFor) forwardHeaders['X-Forwarded-For'] = forwardedFor;

    const response = await fetch(upstream.toString(), {
      method: 'GET',
      headers: forwardHeaders,
      cache: 'no-store',
      redirect: 'follow',
    });

    const body = await response.text();

    if (!response.ok) {
      return new NextResponse(body || `VAST upstream returned ${response.status}`, {
        status: response.status,
        headers: {
          'Content-Type': response.headers.get('content-type') || 'text/plain; charset=utf-8',
          'Cache-Control': 'no-store',
          'Access-Control-Allow-Origin': '*',
        },
      });
    }

    const contentType = /xml/i.test(response.headers.get('content-type') || '')
      ? response.headers.get('content-type')
      : 'application/xml; charset=utf-8';

    const rewrittenBody = rewriteVastUrls(body, response.url || upstream.toString(), request.nextUrl.origin);

    return new NextResponse(rewrittenBody, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Access-Control-Allow-Origin': '*',
        'X-StreamVerse-VAST-Proxy': '2',
      },
    });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error?.message || 'VAST proxy failed' },
      { status: 502, headers: { 'Cache-Control': 'no-store' } },
    );
  }
}
