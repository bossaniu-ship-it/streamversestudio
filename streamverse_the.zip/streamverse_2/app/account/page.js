'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  Bell, Check, Clock3, Film, Heart, History, KeyRound, Loader2, LogOut,
  Mail, PlayCircle, ShieldCheck, Star, User, X
} from 'lucide-react';
import { clientBackend } from '@/lib/api';
import { getToken } from '@/lib/authApi';
import { useAuth } from '@/components/AuthContext';

function fmtDuration(seconds) {
  const n = Math.max(0, Math.round(Number(seconds) || 0));
  if (n < 60) return `${n}s`;
  const m = Math.floor(n / 60); const s = n % 60;
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60); return `${h}h ${m % 60}m`;
}

function EpisodeTile({ item, actionLabel, action }) {
  const pct = item.durationSeconds ? Math.min(100, Math.round((item.progressSeconds / item.durationSeconds) * 100)) : 0;
  return (
    <div className="glass rounded-xl border border-white/10 overflow-hidden group">
      <Link href={`/watch/${item.id}`} className="block relative aspect-video bg-black overflow-hidden">
        {item.thumbnailUrl ? <img src={item.thumbnailUrl} alt="" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" /> : <div className="w-full h-full flex items-center justify-center text-muted"><Film size={28} /></div>}
        {pct > 0 && !item.completed && <div className="absolute left-0 right-0 bottom-0 h-1 bg-white/10"><div className="h-full bg-gradient-to-r from-violet to-cyan" style={{ width: `${pct}%` }} /></div>}
      </Link>
      <div className="p-3.5">
        <p className="text-[10px] uppercase tracking-widest text-violet-light">{item.title}</p>
        <Link href={`/watch/${item.id}`} className="block text-sm font-semibold text-white mt-1 line-clamp-2 hover:text-violet-light transition-colors">{item.episodeTitle}</Link>
        <p className="text-xs text-muted mt-2 line-clamp-2">{item.synopsis || 'Cinematic original episode.'}</p>
        <div className="flex items-center justify-between gap-2 mt-3">
          {item.progressSeconds > 0 ? <span className="text-[11px] text-muted"><Clock3 size={11} className="inline mr-1" />{fmtDuration(item.progressSeconds)} watched</span> : <span />}
          {action && <button onClick={() => action(item)} className="text-[11px] text-muted hover:text-white transition-colors">{actionLabel}</button>}
        </div>
      </div>
    </div>
  );
}

export default function AccountPage() {
  const { user, loading, logout, refresh } = useAuth();
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '' });

  const load = useCallback(async () => {
    const token = getToken();
    if (!token) return;
    const r = await fetch(`${clientBackend()}/api/account/dashboard`, { headers: { Authorization: `Bearer ${token}` }, cache: 'no-store' });
    const d = await r.json();
    if (!r.ok || !d.ok) throw new Error(d?.error || 'Could not load account');
    setData(d);
  }, []);

  useEffect(() => {
    if (!loading && user) {
      setDisplayName(user.displayName || '');
      load().catch(e => setMessage(e.message));
    }
  }, [loading, user, load]);

  const unread = useMemo(() => (data?.announcements || []).filter(a => !a.read_at).length, [data]);
  const favorites = data?.favorites || [];
  const continueWatching = data?.continueWatching || [];
  const history = data?.history || [];
  const stats = data?.stats || {};

  if (loading || !user) return <div className="flex items-center justify-center py-24"><Loader2 size={28} className="text-violet animate-spin" /></div>;

  const saveProfile = async (e) => {
    e.preventDefault(); setBusy(true); setMessage('');
    try {
      const r = await fetch(`${clientBackend()}/api/account/profile`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` }, body: JSON.stringify({ displayName }) });
      const d = await r.json(); if (!r.ok || !d.ok) throw new Error(d.error || 'Could not update profile');
      await refresh(); setMessage('Profile saved.');
    } catch (e) { setMessage(e.message); } finally { setBusy(false); }
  };

  const changePassword = async (e) => {
    e.preventDefault(); setBusy(true); setMessage('');
    try {
      const r = await fetch(`${clientBackend()}/api/account/password`, { method: 'PUT', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${getToken()}` }, body: JSON.stringify(pw) });
      const d = await r.json(); if (!r.ok || !d.ok) throw new Error(d.error || 'Could not change password');
      setPw({ currentPassword: '', newPassword: '' }); setMessage('Password updated.');
    } catch (e) { setMessage(e.message); } finally { setBusy(false); }
  };

  const toggleFavorite = async (item) => {
    const inList = favorites.some(x => x.id === item.id);
    const r = await fetch(`${clientBackend()}/api/account/favorites/${encodeURIComponent(item.id)}`, { method: inList ? 'DELETE' : 'POST', headers: { Authorization: `Bearer ${getToken()}` } });
    const d = await r.json(); if (!r.ok || !d.ok) return;
    await load();
  };

  const markRead = async (id) => {
    await fetch(`${clientBackend()}/api/account/announcements/${encodeURIComponent(id)}/read`, { method: 'POST', headers: { Authorization: `Bearer ${getToken()}` } });
    setData(d => d ? { ...d, announcements: d.announcements.map(a => a.id === id ? { ...a, read_at: new Date().toISOString() } : a) } : d);
  };

  const onSignOut = () => { logout(); window.location.href = '/'; };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <section className="glass rounded-3xl border border-white/10 p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet to-cyan flex items-center justify-center shadow-glow-violet"><User size={27} className="text-white" /></div>
            <div>
              <p className="text-xs uppercase tracking-widest text-violet-light">StreamVerse Member</p>
              <h1 className="font-display text-2xl font-bold text-white">{user.displayName || 'Your account'}</h1>
              <p className="text-sm text-muted mt-1">{user.email}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
            <div className="rounded-xl bg-white/5 border border-white/10 px-4 py-3"><p className="text-[10px] text-muted uppercase">Episodes</p><p className="text-lg font-bold text-white">{stats.uniqueEpisodes || 0}</p></div>
            <div className="rounded-xl bg-white/5 border border-white/10 px-4 py-3"><p className="text-[10px] text-muted uppercase">Watch time</p><p className="text-lg font-bold text-white">{fmtDuration(stats.watchSeconds || 0)}</p></div>
            <div className="rounded-xl bg-white/5 border border-white/10 px-4 py-3"><p className="text-[10px] text-muted uppercase">Completed</p><p className="text-lg font-bold text-white">{stats.completedEpisodes || 0}</p></div>
            <div className="rounded-xl bg-white/5 border border-white/10 px-4 py-3"><p className="text-[10px] text-muted uppercase">Alerts</p><p className="text-lg font-bold text-white">{unread}</p></div>
          </div>
        </div>
      </section>

      {message && <div className="rounded-xl px-4 py-3 bg-violet/10 border border-violet/20 text-sm text-white/80">{message}</div>}

      <section className="space-y-4">
        <div className="flex items-center justify-between"><div><p className="text-xs uppercase tracking-widest text-violet-light">Pick up where you left off</p><h2 className="font-display text-xl font-bold text-white">Continue Watching</h2></div></div>
        {continueWatching.length ? <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">{continueWatching.slice(0,8).map(i => <EpisodeTile key={i.id} item={i} actionLabel={favorites.some(x => x.id === i.id) ? 'Remove List' : 'Add to List'} action={toggleFavorite} />)}</div> : <div className="glass rounded-2xl border border-white/10 p-8 text-center text-sm text-muted">Start an episode and your progress will appear here.</div>}
      </section>

      <section className="space-y-4">
        <div className="flex items-center gap-2"><Heart size={16} className="text-violet-light" /><h2 className="font-display text-xl font-bold text-white">My List</h2></div>
        {favorites.length ? <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">{favorites.map(i => <EpisodeTile key={i.id} item={i} actionLabel="Remove" action={toggleFavorite} />)}</div> : <div className="glass rounded-2xl border border-white/10 p-8 text-center text-sm text-muted">Your saved episodes will live here.</div>}
      </section>

      <section className="space-y-4">
        <div className="flex items-center gap-2"><History size={16} className="text-violet-light" /><h2 className="font-display text-xl font-bold text-white">Watch History</h2></div>
        {history.length ? <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">{history.map(i => <EpisodeTile key={i.id} item={i} />)}</div> : <div className="glass rounded-2xl border border-white/10 p-8 text-center text-sm text-muted">Your viewing history will appear after you watch an episode.</div>}
      </section>

      <section className="grid lg:grid-cols-2 gap-6">
        <div className="glass rounded-2xl border border-white/10 p-6">
          <div className="flex items-center gap-2 mb-4"><Bell size={16} className="text-violet-light" /><h2 className="font-display text-lg font-bold text-white">Announcements</h2></div>
          <div className="space-y-3">
            {(data?.announcements || []).length ? data.announcements.map(a => <div key={a.id} className={`rounded-xl border p-4 ${a.read_at ? 'border-white/10 bg-white/[.02]' : 'border-violet/30 bg-violet/[.06]'}`}>
              <div className="flex items-start justify-between gap-3"><div><p className="text-sm font-semibold text-white">{a.title}</p><p className="text-[11px] text-muted mt-1">{a.published_at ? new Date(a.published_at).toLocaleString() : ''}</p></div>{!a.read_at && <button onClick={() => markRead(a.id)} className="text-[11px] text-violet-light">Mark read</button>}</div>
              <p className="text-sm text-white/70 leading-relaxed mt-3 whitespace-pre-wrap">{a.body}</p>
            </div>) : <p className="text-sm text-muted">No announcements yet.</p>}
          </div>
        </div>

        <div className="glass rounded-2xl border border-white/10 p-6">
          <div className="flex items-center gap-2 mb-5"><ShieldCheck size={16} className="text-violet-light" /><h2 className="font-display text-lg font-bold text-white">Profile & Security</h2></div>
          <form onSubmit={saveProfile} className="space-y-3">
            <label className="block text-xs text-muted">Display name<input value={displayName} onChange={e => setDisplayName(e.target.value)} className="mt-1 w-full rounded-lg bg-black/20 border border-white/10 px-3 py-2.5 text-sm text-white outline-none focus:border-violet/50" /></label>
            <div className="flex items-center gap-2 text-xs text-muted"><Mail size={13} /> {user.email}<span className="inline-flex items-center gap-1 ml-2 text-green-300"><Check size={11} /> {user.emailVerified ? 'Verified' : 'Unverified'}</span></div>
            <button disabled={busy} className="px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm text-white">Save Profile</button>
          </form>
          <form onSubmit={changePassword} className="space-y-3 mt-7 pt-6 border-t border-white/10">
            <div className="flex items-center gap-2 mb-2"><KeyRound size={14} className="text-violet-light" /><p className="text-sm font-semibold text-white">Change password</p></div>
            <input type="password" value={pw.currentPassword} onChange={e => setPw(p => ({...p,currentPassword:e.target.value}))} placeholder="Current password" className="w-full rounded-lg bg-black/20 border border-white/10 px-3 py-2.5 text-sm text-white outline-none" />
            <input type="password" value={pw.newPassword} onChange={e => setPw(p => ({...p,newPassword:e.target.value}))} placeholder="New password (8+ characters)" className="w-full rounded-lg bg-black/20 border border-white/10 px-3 py-2.5 text-sm text-white outline-none" />
            <button disabled={busy} className="px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-sm text-white">Update Password</button>
          </form>
          <button onClick={onSignOut} className="mt-6 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm text-white/80 transition-colors"><LogOut size={14} /> Sign Out</button>
        </div>
      </section>
    </div>
  );
}
