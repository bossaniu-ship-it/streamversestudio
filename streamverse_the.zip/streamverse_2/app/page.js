import { Suspense } from 'react';
import { fetchHistory } from '@/lib/api';
import EpisodeCard from '@/components/EpisodeCard';
import HeroSection from '@/components/HeroSection';
import SkeletonCard from '@/components/SkeletonCard';
import GenreFilter from '@/components/GenreFilter';
import StatsBar from '@/components/StatsBar';
import { Sparkles, Tv2, AlertCircle, Clapperboard } from 'lucide-react';

function showIdentity(episode) {
  const id = episode.showId || episode.show_id || episode.storylineId || episode.storyline_id || null;
  const raw = episode.showTitle || episode.show_title || episode.seriesTitle || episode.series_title || episode.series || episode.title || 'Untitled Show';
  const title = String(raw).trim().replace(/\s+S\d+E\d+(?:\s+.*)?$/i, '').trim() || 'Untitled Show';
  return { id: id ? String(id) : null, title };
}

function groupEpisodes(episodes) {
  const groups = new Map();
  for (const episode of episodes || []) {
    const show = showIdentity(episode);
    // New records group by the real storyline ID. Legacy records that lack
    // that field fall back to the normalized show title.
    const key = show.id ? `id:${show.id}` : `title:${show.title.toLowerCase()}`;
    if (!groups.has(key)) groups.set(key, { title: show.title, episodes: [] });
    groups.get(key).episodes.push(episode);
  }
  return Array.from(groups.values()).map(group => ({
    ...group,
    episodes: group.episodes.sort((a, b) => {
      const sa = Number(a.seasonNumber ?? a.season_number ?? 0);
      const sb = Number(b.seasonNumber ?? b.season_number ?? 0);
      if (sa !== sb) return sa - sb;
      const ea = Number(a.episodeNumber ?? a.episode_number ?? 0);
      const eb = Number(b.episodeNumber ?? b.episode_number ?? 0);
      return ea - eb;
    }),
  }));
}

async function EpisodeGrid() {
  let data = null;
  let error = null;

  try {
    data = await fetchHistory();
  } catch (e) {
    error = e.message;
  }

  if (error || !data?.history?.length) {
    return (
      <div className="col-span-full flex flex-col items-center justify-center py-24 gap-4">
        <div className="w-16 h-16 rounded-2xl glass border border-white/10 flex items-center justify-center">
          {error
            ? <AlertCircle size={28} className="text-danger/70" />
            : <Tv2 size={28} className="text-muted/60" />
          }
        </div>
        <p className="text-sm text-muted text-center max-w-xs">
          {error
            ? `Couldn't reach the backend: ${error}`
            : 'No episodes published yet. Check back soon — new content is generated daily.'
          }
        </p>
      </div>
    );
  }

  const hero = data.history[0];
  const grouped = groupEpisodes(data.history);

  return (
    <>
      <div className="col-span-full">
        <HeroSection episode={hero} />
      </div>

      {data.activeShows?.length > 0 && (
        <div className="col-span-full">
          <StatsBar shows={data.activeShows} totalEpisodes={data.history.length} />
        </div>
      )}

      <div className="col-span-full flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <Sparkles size={16} className="text-violet-light" />
          <h2 className="font-display text-xl font-bold text-white">Episodes by Show</h2>
        </div>
        <GenreFilter />
      </div>

      {grouped.map((group) => (
        <section key={group.title} className="col-span-full space-y-4">
          <div className="flex items-center gap-3">
            <Clapperboard size={15} className="text-violet-light" />
            <h3 className="font-display text-lg font-bold text-white">{group.title}</h3>
            <span className="text-xs text-muted">{group.episodes.length} {group.episodes.length === 1 ? 'episode' : 'episodes'}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {group.episodes.map((ep, i) => (
              <EpisodeCard key={ep.id || `${group.title}-${i}`} episode={ep} priority={i < 2} />
            ))}
          </div>
        </section>
      ))}
    </>
  );
}

function LoadingGrid() {
  return (
    <>
      <div className="col-span-full">
        <div className="relative min-h-[70vh] rounded-3xl overflow-hidden shimmer mb-10" />
      </div>
      {Array.from({ length: 6 }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </>
  );
}

export default function HomePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8 text-center">
        <h1 className="font-display text-5xl sm:text-6xl font-black text-white mb-3 leading-none">
          Stream<span className="gradient-text">Verse</span>
          <span className="block text-2xl sm:text-3xl font-light text-muted mt-1 tracking-widest uppercase">
            Studio
          </span>
        </h1>
        <p className="text-sm text-muted max-w-md mx-auto">
          Cinematic original series. New episodes daily.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 stagger-in">
        <Suspense fallback={<LoadingGrid />}>
          <EpisodeGrid />
        </Suspense>
      </div>
    </div>
  );
}
