const BACKEND = process.env.BACKEND_URL || process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:3001';

const FORWARDED_HEADERS = [
  'authorization', 'user-agent', 'x-forwarded-for', 'x-real-ip', 'cf-connecting-ip',
  'cf-ipcountry', 'cf-ipcountry-name', 'x-vercel-ip-country', 'x-vercel-ip-country-region',
  'x-vercel-ip-city', 'x-vercel-ip-continent', 'x-nf-country', 'x-country-code',
  'x-country', 'x-country-name', 'x-region', 'x-city', 'x-continent', 'x-forwarded-proto',
];

export async function POST(request) {
  try {
    const body = await request.text();
    const headers = new Headers({ 'Content-Type': request.headers.get('content-type') || 'application/json' });
    for (const name of FORWARDED_HEADERS) {
      const value = request.headers.get(name);
      if (value) headers.set(name, value);
    }

    const response = await fetch(`${BACKEND.replace(/\/$/, '')}/api/analytics/track`, {
      method: 'POST',
      headers,
      body,
      cache: 'no-store',
    });

    const text = await response.text();
    return new Response(text, {
      status: response.status,
      headers: { 'Content-Type': response.headers.get('content-type') || 'application/json' },
    });
  } catch (error) {
    console.error('[Next /api/analytics/track]', error?.message || error);
    return Response.json({ ok: false, error: 'Analytics proxy unavailable' }, { status: 502 });
  }
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
