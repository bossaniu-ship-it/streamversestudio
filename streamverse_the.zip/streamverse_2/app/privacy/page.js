import Link from 'next/link';
const CONTACT_EMAIL = process.env.NEXT_PUBLIC_CONTACT_EMAIL || 'contact@streamverse.studio';
export const metadata = { title: 'Privacy Policy — StreamVerse Studio', description: 'How StreamVerse Studio handles information associated with the service.' };
export default function PrivacyPage() { return (
  <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12"><div className="glass rounded-3xl border border-white/10 p-6 sm:p-10">
    <p className="text-xs uppercase tracking-[0.25em] text-violet-light mb-3">Legal</p><h1 className="font-display text-4xl sm:text-5xl font-black text-white">Privacy Policy</h1><p className="text-sm text-muted mt-3">Last updated: August 15, 2026</p>
    <div className="prose prose-invert prose-sm sm:prose-base max-w-none mt-10"><h2>1. Information we receive</h2><p>Depending on how you use StreamVerse, we may process account information such as your email address, authentication information, viewing activity, and technical information needed to secure and operate the service.</p>
    <h2>2. How we use information</h2><p>We use information to create and secure accounts, provide playback, maintain service reliability, prevent abuse, measure service performance, and communicate service-related notices.</p>
    <h2>3. Advertising and analytics</h2><p>Where advertising is enabled, advertising or analytics providers may process limited technical information according to their own policies. The specific vendors used by a deployment may change over time.</p>
    <h2>4. Data retention</h2><p>We retain information for as long as reasonably necessary to provide the service, meet operational needs, resolve disputes, enforce agreements, and comply with applicable legal obligations.</p>
    <h2>5. Security</h2><p>We use reasonable technical and organizational safeguards designed to protect accounts and service data. No internet service can guarantee absolute security.</p>
    <h2>6. Your choices</h2><p>You may contact us about account information, privacy questions, or requests relating to your personal information. We may need to verify a request before acting on it.</p>
    <h2>7. Contact</h2><p>Privacy questions and requests can be sent to <a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>.</p></div>
    <div className="mt-10 pt-6 border-t border-white/5 flex gap-4 text-sm"><Link href="/terms" className="text-violet-light hover:text-white">Terms of Service</Link><Link href="/contact" className="text-violet-light hover:text-white">Contact</Link></div>
  </div></div>
); }
