import Link from 'next/link';
import { Mail, ShieldCheck } from 'lucide-react';
const CONTACT_EMAIL = process.env.NEXT_PUBLIC_CONTACT_EMAIL || 'contact@streamverse.studio';
export const metadata = { title: 'Contact — StreamVerse Studio', description: 'Contact StreamVerse Studio by email.' };
export default function ContactPage() { return (
  <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12"><div className="glass rounded-3xl border border-white/10 p-8 sm:p-12 text-center">
    <div className="mx-auto w-16 h-16 rounded-2xl bg-violet/15 border border-violet/20 flex items-center justify-center"><Mail size={28} className="text-violet-light" /></div>
    <p className="text-xs uppercase tracking-[0.25em] text-violet-light mt-6">Contact StreamVerse</p><h1 className="font-display text-4xl sm:text-5xl font-black text-white mt-2">We’re here to help.</h1>
    <p className="text-sm text-muted max-w-lg mx-auto mt-4 leading-relaxed">For support, copyright concerns, privacy requests, account issues, or general enquiries, contact us by email.</p>
    <a href={`mailto:${CONTACT_EMAIL}`} className="inline-flex items-center gap-2 mt-8 px-6 py-3 rounded-xl bg-gradient-to-r from-violet to-violet-dark text-white font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all"><Mail size={17} />{CONTACT_EMAIL}</a>
    <div className="mt-10 pt-6 border-t border-white/5 flex items-center justify-center gap-2 text-xs text-muted"><ShieldCheck size={14} className="text-violet-light" />For copyright or removal requests, include the relevant title and a clear description of the concern.</div>
    <div className="mt-8 flex justify-center gap-5 text-sm"><Link href="/terms" className="text-violet-light hover:text-white">Terms</Link><Link href="/privacy" className="text-violet-light hover:text-white">Privacy</Link></div>
  </div></div>
); }
