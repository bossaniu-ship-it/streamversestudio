import Link from 'next/link';
const CONTACT_EMAIL = process.env.NEXT_PUBLIC_CONTACT_EMAIL || 'contact@streamverse.studio';
export const metadata = { title: 'Terms of Service — StreamVerse Studio', description: 'Terms governing use of StreamVerse Studio.' };
export default function TermsPage() { return (
  <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12"><div className="glass rounded-3xl border border-white/10 p-6 sm:p-10">
    <p className="text-xs uppercase tracking-[0.25em] text-violet-light mb-3">Legal</p><h1 className="font-display text-4xl sm:text-5xl font-black text-white">Terms of Service</h1><p className="text-sm text-muted mt-3">Last updated: August 15, 2026</p>
    <div className="prose prose-invert prose-sm sm:prose-base max-w-none mt-10"><h2>1. About StreamVerse</h2><p>StreamVerse Studio provides access to original audiovisual entertainment and related website features. Content availability may vary by title, region, account status, or technical availability.</p>
    <h2>2. Accounts</h2><p>You are responsible for maintaining the confidentiality of your account credentials and for activity that occurs through your account. Do not share credentials or attempt to bypass access controls.</p>
    <h2>3. Content and intellectual property</h2><p>Unless otherwise stated, StreamVerse Studio and its licensors retain rights in StreamVerse branding, software, audiovisual works, artwork, text, and other original materials. You receive a limited, personal, non-transferable right to access content through the service for personal viewing.</p>
    <h2>4. Prohibited use</h2><p>You may not copy, redistribute, publicly perform, sell, license, scrape, reverse engineer, circumvent access controls, or use automated means to collect or reproduce StreamVerse content except where applicable law expressly permits it.</p>
    <h2>5. Availability and advertising</h2><p>Some viewing experiences may include advertising. We may change, suspend, or discontinue features or titles where reasonably necessary for operations, security, legal compliance, or licensing.</p>
    <h2>6. Enforcement</h2><p>We may restrict or terminate access when an account is used fraudulently, unlawfully, or in material violation of these terms.</p>
    <h2>7. Contact</h2><p>Questions about these terms can be sent to <a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>.</p></div>
    <div className="mt-10 pt-6 border-t border-white/5 flex gap-4 text-sm"><Link href="/privacy" className="text-violet-light hover:text-white">Privacy Policy</Link><Link href="/contact" className="text-violet-light hover:text-white">Contact</Link></div>
  </div></div>
); }
