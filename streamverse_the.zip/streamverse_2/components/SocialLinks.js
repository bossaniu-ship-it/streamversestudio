import { Facebook, Youtube } from 'lucide-react';

const links = [
  { key: 'youtube', label: 'YouTube', url: process.env.SOCIAL_YOUTUBE_URL, Icon: Youtube },
  { key: 'tiktok', label: 'TikTok', url: process.env.SOCIAL_TIKTOK_URL },
  { key: 'facebook', label: 'Facebook', url: process.env.SOCIAL_FACEBOOK_URL, Icon: Facebook },
].filter(item => item.url);

function TikTokIcon() {
  return <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M15.9 3c.4 2.3 1.7 3.7 4.1 3.9v3.1c-1.8.1-3.4-.5-4.6-1.5v7.2c0 4.2-2.8 6.3-6.2 6.3-3.1 0-5.4-2.1-5.4-5.2 0-3.3 2.6-5.5 5.9-5.5.5 0 .9.1 1.4.2v3.2c-.4-.1-.8-.2-1.2-.2-1.4 0-2.7.9-2.7 2.3 0 1.2.9 2.1 2.1 2.1 1.4 0 2.5-.8 2.5-2.8V3h4.1Z"/></svg>;
}

export default function SocialLinks() {
  if (!links.length) return null;
  return (
    <div className="flex items-center gap-2">
      {links.map(({ key, label, url, Icon }) => (
        <a key={key} href={url} target="_blank" rel="noopener noreferrer" aria-label={label} title={label}
          className="w-9 h-9 rounded-full glass border border-white/10 flex items-center justify-center text-muted hover:text-white hover:border-violet/40 transition-colors">
          {Icon ? <Icon size={15} /> : <TikTokIcon />}
        </a>
      ))}
    </div>
  );
}
