'use client';

import { useState } from 'react';
import { Check, Copy, Share2 } from 'lucide-react';

export default function ShareButton({ episode, className = '', compact = false }) {
  const [copied, setCopied] = useState(false);
  const [sharing, setSharing] = useState(false);

  async function handleShare(event) {
    event.preventDefault();
    event.stopPropagation();

    const url = typeof window !== 'undefined'
      ? `${window.location.origin}/watch/${encodeURIComponent(episode?.id || '')}`
      : '';
    const title = episode?.episodeTitle || episode?.title || 'StreamVerse episode';
    const text = episode?.synopsis || `Watch ${title} on StreamVerse Studio`;

    try {
      setSharing(true);
      if (navigator.share) {
        await navigator.share({ title, text, url });
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1800);
      }
    } catch (error) {
      // AbortError means the user intentionally closed the native share sheet.
      if (error?.name !== 'AbortError' && navigator.clipboard) {
        try {
          await navigator.clipboard.writeText(url);
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1800);
        } catch {}
      }
    } finally {
      setSharing(false);
    }
  }

  return (
    <button
      type="button"
      onClick={handleShare}
      disabled={sharing || !episode?.id}
      className={className || 'inline-flex items-center gap-2 px-5 py-3 rounded-xl glass border border-white/15 text-white/80 hover:text-white hover:border-white/30 text-sm font-medium transition-all duration-200 disabled:opacity-50'}
      title={copied ? 'Link copied' : 'Share episode'}
      aria-label={copied ? 'Episode link copied' : 'Share episode'}
    >
      {copied ? <Check size={16} /> : <Share2 size={16} />}
      {!compact && (copied ? 'Copied' : 'Share')}
    </button>
  );
}
