'use client';

import Link from 'next/link';
import { Play, Sparkles, TrendingUp } from 'lucide-react';
import GenreBadge from './GenreBadge';
import ShareButton from './ShareButton';
import { timeAgo } from '@/lib/api';

function PreviewVideo({ preview, thumb, title }) {
  if (!preview) return null;

  return (
    <video
      key={preview}
      src={preview}
      poster={thumb || undefined}
      className="absolute inset-0 w-full h-full object-cover scale-105"
      autoPlay
      muted
      loop
      playsInline
      preload="auto"
      controls={false}
      aria-label={`${title} first-scene preview`}
      onCanPlay={(event) => {
        const media = event.currentTarget;
        media.play().catch(() => {});
      }}
    />
  );
}

export default function HeroSection({ episode }) {
  if (!episode) return null;

  const thumb = episode.thumbnailUrl || null;
  const preview = episode.previewUrl || episode.firstSceneUrl || episode.firstSceneVideoUrl || null;
  const href = episode.id ? `/watch/${episode.id}` : null;

  return (
    <section className="relative min-h-[70vh] flex items-end overflow-hidden rounded-3xl mb-10 bg-black">
      {preview ? (
        <PreviewVideo
          preview={preview}
          thumb={thumb}
          title={episode.episodeTitle || episode.title || 'Episode'}
        />
      ) : thumb ? (
        <div
          className="absolute inset-0 bg-cover bg-center scale-105"
          style={{ backgroundImage: `url(${thumb})`, filter: 'blur(2px)' }}
        />
      ) : (
        <div className="absolute inset-0 bg-gradient-to-br from-violet/30 via-cosmos to-void" />
      )}

      <div className="absolute inset-0 bg-gradient-to-t from-void via-void/60 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-void/80 via-transparent to-transparent" />

      <div className="absolute top-6 right-6 flex items-center gap-2 px-3 py-1.5 rounded-full glass border border-violet/30">
        <TrendingUp size={12} className="text-violet-light" />
        <span className="text-xs font-semibold text-violet-light">Latest Release</span>
      </div>

      <div className="relative z-10 p-8 md:p-12 max-w-2xl w-full">
        <div className="flex items-center gap-2 mb-4">
          <GenreBadge genre={episode.genre} size="sm" />
          <span className="text-xs text-muted">{episode.title}</span>
          <span className="text-xs text-muted">•</span>
          <span suppressHydrationWarning className="text-xs text-muted">{timeAgo(episode.postedAt)}</span>
        </div>

        <h1 className="font-display text-4xl md:text-5xl font-bold text-white leading-tight mb-4">
          {episode.episodeTitle || 'Untitled Episode'}
        </h1>

        {episode.synopsis && (
          <p className="text-base text-white/70 leading-relaxed mb-6 max-w-lg line-clamp-3">
            {episode.synopsis}
          </p>
        )}

        <div className="flex items-center gap-3 flex-wrap">
          {href ? (
            <Link
              href={href}
              className="btn-glow inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-violet to-violet-dark text-white font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300 group"
            >
              <Play size={18} className="fill-white group-hover:scale-110 transition-transform" />
              Watch Now
            </Link>
          ) : (
            <div className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-violet to-violet-dark text-white font-semibold shadow-glow-violet opacity-80">
              <Play size={18} className="fill-white" />
              Watch Now
            </div>
          )}

          <ShareButton episode={episode} />
        </div>

        {episode.scenes > 0 && (
          <div className="flex items-center gap-1 mt-6">
            <Sparkles size={12} className="text-violet-light/60" />
            <div className="flex gap-1">
              {Array.from({ length: Math.min(episode.scenes, 8) }).map((_, i) => (
                <div key={i} className="w-5 h-0.5 rounded-full bg-violet/50" />
              ))}
            </div>
            <span className="text-xs text-muted ml-1">{episode.scenes} scenes</span>
          </div>
        )}
      </div>
    </section>
  );
}
