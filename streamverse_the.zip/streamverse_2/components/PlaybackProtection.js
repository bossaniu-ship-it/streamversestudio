'use client';

import { useEffect, useState } from 'react';

/**
 * Best-effort browser playback protection.
 * Web pages cannot disable OS/hardware screenshots or screen recording on all
 * devices, so this adds browser-level deterrence and pauses playback when the
 * document is hidden.
 */
export default function PlaybackProtection({ active, userLabel = 'Authorized Viewer', children }) {
  const [hidden, setHidden] = useState(false);
  const [stamp, setStamp] = useState(() => new Date().toLocaleString());

  useEffect(() => {
    if (!active) return undefined;
    const updateHiddenState = () => {
      const isHidden = document.visibilityState !== 'visible';
      setHidden(isHidden);
      if (isHidden) setStamp(new Date().toLocaleString());
    };
    const blockBrowserCaptureShortcuts = (event) => {
      const key = String(event.key || '').toLowerCase();
      const modifier = event.ctrlKey || event.metaKey;
      const blocked =
        key === 'printscreen' ||
        (modifier && ['p', 's'].includes(key)) ||
        (event.ctrlKey && event.shiftKey && key === 's') ||
        (event.metaKey && event.shiftKey && ['3', '4', '5'].includes(key));
      if (blocked) {
        event.preventDefault();
        event.stopPropagation();
      }
    };
    document.addEventListener('visibilitychange', updateHiddenState);
    document.addEventListener('keydown', blockBrowserCaptureShortcuts, true);
    updateHiddenState();
    return () => {
      document.removeEventListener('visibilitychange', updateHiddenState);
      document.removeEventListener('keydown', blockBrowserCaptureShortcuts, true);
    };
  }, [active]);

  useEffect(() => {
    if (!active) return undefined;
    const timer = window.setInterval(() => setStamp(new Date().toLocaleString()), 15000);
    return () => window.clearInterval(timer);
  }, [active]);

  useEffect(() => {
    if (!active || !hidden) return;
    Array.from(document.querySelectorAll('video')).forEach((video) => {
      if (!video.paused) video.pause();
    });
  }, [active, hidden]);

  return (
    <div
      className="relative w-full h-full select-none"
      onContextMenu={(event) => event.preventDefault()}
      onDragStart={(event) => event.preventDefault()}
      onCopy={(event) => event.preventDefault()}
      onCut={(event) => event.preventDefault()}
    >
      {children}
      {active && (
        <div className="pointer-events-none absolute inset-0 z-30" aria-hidden="true">
          <div className="absolute top-4 right-4 rounded-md bg-black/35 px-2 py-1 text-[9px] font-medium tracking-wider text-white/35 backdrop-blur-[2px]">
            {userLabel} · {stamp}
          </div>
        </div>
      )}
      {active && hidden && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black text-center p-6">
          <div className="max-w-sm">
            <div className="text-xs font-semibold uppercase tracking-[0.28em] text-white/60">Playback protected</div>
            <p className="mt-3 text-sm text-white/85">Playback is paused while StreamVerse is not visible.</p>
            <p className="mt-1 text-xs text-white/45">Return to this window to continue watching.</p>
          </div>
        </div>
      )}
    </div>
  );
}
