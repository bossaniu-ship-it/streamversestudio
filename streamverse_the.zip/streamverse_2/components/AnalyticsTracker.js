'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { trackAnalyticsEvent } from '@/lib/analytics';

export default function AnalyticsTracker() {
  const pathname = usePathname();

  useEffect(() => {
    trackAnalyticsEvent('page_view');
  }, [pathname]);

  useEffect(() => {
    const heartbeat = window.setInterval(() => {
      if (document.visibilityState === 'visible') trackAnalyticsEvent('heartbeat');
    }, 15000);

    const onVisibility = () => {
      if (document.visibilityState === 'visible') trackAnalyticsEvent('heartbeat');
    };
    const onUnload = () => trackAnalyticsEvent('session_end', { durationSeconds: 0 }, { beacon: true });

    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('pagehide', onUnload, { once: true });
    return () => {
      window.clearInterval(heartbeat);
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('pagehide', onUnload);
    };
  }, []);

  return null;
}
