# StreamVerse Studio — ClickAdilla Ad Fix Handoff

## What was fixed

1. Pre-roll is now isolated to the authorization gate. The old gate attempted to configure both pre-roll and mid-roll on a temporary player, then destroyed that player before the real episode began; that made the mid-roll unreachable.
2. The real episode player now watches the main content timeline and opens a dedicated Fluid Player ad break at `NEXT_PUBLIC_CLICKADILLA_MIDROLL_SECONDS` (default: 60 seconds).
3. The old `50%` Fluid Player mid-roll timer was removed. Current Fluid Player releases have had timeline-timer changes, and the safer configuration here is an explicit seconds value.
4. VAST requests now go through the Next.js same-origin `/api/ads/vast` proxy. The proxy validates the configured VAST host, forwards the XML response, and returns it with an XML content type and permissive CORS headers.
5. Fluid Player is pinned to `3.60.0` instead of the floating `v3/current` CDN URL.
6. The ad player is muted for autoplay compatibility. If the browser still blocks playback, the UI exposes a `Play Advertisement` button.
7. Mid-roll no-fill/player failure never strands the viewer; the episode resumes.

## Configuration

- `NEXT_PUBLIC_CLICKADILLA_VAST_TAG` — the approved VAST tag URL.
- `NEXT_PUBLIC_CLICKADILLA_MIDROLL_SECONDS` — mid-roll trigger in seconds. Default: `60`.

## Important ClickAdilla note

ClickAdilla's current in-stream documentation explicitly describes pre-roll / embedded-pre-roll inventory and VAST wrapper usage. The code now supports mid-roll playback at the player layer, but whether a particular ClickAdilla VAST tag returns a fill for a mid-roll request depends on the tag, campaign and available traffic. The ClickAdilla account/campaign itself still must be active and approved.

## Verification note

The source files and route were statically checked in this handoff environment. A complete `next build` could not be executed because npm dependency installation timed out in the sandbox network. The project therefore does **not** claim a successful production build from this environment.
