'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader2, Play } from 'lucide-react';
import { completeAd, initStream, logAdEvent } from '@/lib/api';

// The app receives the VAST tag from ClickAdilla/the configured VAST provider.
// The browser uses StreamVerse's same-origin proxy to avoid VAST CORS failures.
const RAW_CLICKADILLA_VAST_TAG = process.env.NEXT_PUBLIC_CLICKADILLA_VAST_TAG || '';
const CLICKADILLA_VAST_TAG = RAW_CLICKADILLA_VAST_TAG
  ? `/api/ads/vast?url=${encodeURIComponent(RAW_CLICKADILLA_VAST_TAG)}`
  : '';
const DUMMY_SRC = '/ad-gate-placeholder.mp4';

export default function ClickadillaVastGate({ episode, onVideoReady }) {
  const [phase, setPhase] = useState('loading');
  const [message, setMessage] = useState('Preparing advertisement…');
  const [playBlocked, setPlayBlocked] = useState(false);
  const videoRef = useRef(null);
  const playerRef = useRef(null);
  const tokenRef = useRef(null);
  const completedRef = useRef(false);
  const mountedRef = useRef(false);

  const episodeId = String(episode?.id || '');

  const finishGate = useCallback(async (reason) => {
    if (completedRef.current || !episodeId) return;
    completedRef.current = true;

    const token = tokenRef.current;
    if (!token) {
      completedRef.current = false;
      setPhase('error');
      setMessage('Playback authorization is unavailable. Please try again.');
      return;
    }

    try {
      logAdEvent('clickadilla_preroll_complete', { episodeId, reason });
      const result = await completeAd(episodeId, token);
      if (!result?.videoUrl) throw new Error('Backend did not return a video URL');
      onVideoReady(result.videoUrl);
    } catch (error) {
      completedRef.current = false;
      logAdEvent('clickadilla_preroll_complete_error', {
        episodeId,
        error: error?.message || 'Authorization failed',
      });
      if (mountedRef.current) {
        setPhase('error');
        setMessage(error?.message || 'Could not authorize the episode.');
      }
    }
  }, [episodeId, onVideoReady]);

  useEffect(() => {
    mountedRef.current = true;
    let cancelled = false;

    async function boot() {
      try {
        if (!episodeId) throw new Error('Missing episode ID.');
        if (!RAW_CLICKADILLA_VAST_TAG) {
          throw new Error('ClickAdilla VAST zone is not configured.');
        }

        const stream = await initStream(episodeId);
        if (cancelled) return;

        tokenRef.current = stream?.token || null;

        if (!stream?.adRequired) {
          await finishGate('not-required');
          return;
        }

        const waitForFluidPlayer = () => new Promise((resolve, reject) => {
          if (typeof window !== 'undefined' && typeof window.fluidPlayer === 'function') {
            resolve(window.fluidPlayer);
            return;
          }

          const timeoutAt = Date.now() + 15000;
          const tick = () => {
            if (typeof window !== 'undefined' && typeof window.fluidPlayer === 'function') {
              resolve(window.fluidPlayer);
              return;
            }
            if (Date.now() >= timeoutAt) {
              reject(new Error('Fluid Player has not loaded.'));
              return;
            }
            window.setTimeout(tick, 100);
          };
          tick();
        });

        const fluidPlayer = await waitForFluidPlayer();
        if (cancelled) return;

        const element = videoRef.current;
        if (!element) throw new Error('Advertisement player element is unavailable.');

        logAdEvent('clickadilla_preroll_request', {
          episodeId,
          transport: 'fluid-player',
        });

        setPhase('player');
        setMessage('Advertisement');

        element.muted = true;
        element.playsInline = true;
        element.controls = false;
        element.preload = 'auto';

        const player = fluidPlayer(element, {
          layoutControls: {
            primaryColor: '#8b5cf6',
            autoPlay: true,
            mute: true,
            playButtonShowing: true,
            allowDownload: false,
            playbackRateEnabled: false,
            controlBar: {
              autoHide: false,
            },
          },
          vastOptions: {
            adList: [
              {
                roll: 'preRoll',
                vastTag: CLICKADILLA_VAST_TAG,
              },
            ],
            vastTimeout: 10000,
            showPlayButton: true,
            maxAllowedVastTagRedirects: 5,
            vastAdvanced: {
              vastLoadedCallback: () => {
                logAdEvent('clickadilla_preroll_vast_loaded', { episodeId });
              },
              noVastVideoCallback: () => {
                logAdEvent('clickadilla_preroll_no_fill', { episodeId });
                void finishGate('no-fill');
              },
              vastVideoSkippedCallback: () => {
                logAdEvent('clickadilla_preroll_skipped', { episodeId });
                void finishGate('skipped');
              },
              vastVideoEndedCallback: () => {
                logAdEvent('clickadilla_preroll_completed', { episodeId });
                void finishGate('completed');
              },
            },
          },
        });

        playerRef.current = player;

        // Let Fluid Player handle its ad lifecycle. The initial ad is muted
        // so browser autoplay policies do not prevent the impression from
        // rendering; users can still use the player audio controls.
        try {
          await Promise.resolve(
            typeof player?.play === 'function' ? player.play() : element.play()
          );
          if (mountedRef.current) setPlayBlocked(false);
        } catch (error) {
          setPlayBlocked(true);
          logAdEvent('clickadilla_preroll_autoplay_blocked', {
            episodeId,
            error: error?.message || 'play() rejected',
          });
        }
      } catch (error) {
        if (cancelled) return;
        logAdEvent('clickadilla_preroll_player_load_error', {
          episodeId,
          error: error?.message || 'VAST load failed',
        });
        setPhase('error');
        setMessage(error?.message || 'Could not load the advertisement.');
      }
    }

    boot();

    return () => {
      cancelled = true;
      mountedRef.current = false;
      try { playerRef.current?.destroy?.(); } catch (_) {}
      playerRef.current = null;
    };
  }, [episodeId, finishGate]);

  return (
    <div className="ad-overlay relative flex items-center justify-center bg-black overflow-hidden">
      <video
        id={`clickadilla-preroll-${episodeId}`}
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline
        muted
        autoPlay
        preload="auto"
        aria-label="Advertisement"
      >
        <source src={DUMMY_SRC} type="video/mp4" />
      </video>

      {phase === 'loading' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center bg-black/75">
          <Loader2 size={32} className="animate-spin text-violet" />
          <p className="text-sm text-muted">{message}</p>
        </div>
      )}

      {phase === 'player' && playBlocked && (
        <button
          type="button"
          onClick={() => {
            const p = playerRef.current;
            const attempt = typeof p?.play === 'function'
              ? p.play()
              : videoRef.current?.play();

            Promise.resolve(attempt)
              .then(() => setPlayBlocked(false))
              .catch(() => {});
          }}
          className="absolute inset-0 m-auto w-fit h-fit px-5 py-3 rounded-full bg-violet text-white font-semibold flex items-center gap-2 shadow-lg"
        >
          <Play size={18} fill="currentColor" />
          Play Advertisement
        </button>
      )}

      {phase === 'error' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center bg-black">
          <AlertCircle size={32} className="text-danger" />
          <p className="text-sm text-white font-medium">Advertisement could not load</p>
          <p className="text-xs text-muted max-w-md">{message}</p>
        </div>
      )}
    </div>
  );
}
