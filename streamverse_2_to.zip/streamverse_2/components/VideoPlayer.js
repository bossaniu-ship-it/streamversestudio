'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Play, Pause, Volume2, VolumeX, Maximize2, Minimize2,
  RotateCcw, AlertCircle, Loader2
} from 'lucide-react';
import ClickadillaVastGate from '@/components/ClickadillaVastGate';
import { useAuth } from '@/components/AuthContext';
import { saveWatchProgress, trackAnalyticsEvent } from '@/lib/analytics';
import PlaybackProtection from '@/components/PlaybackProtection';

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || '';
const RAW_CLICKADILLA_VAST_TAG = process.env.NEXT_PUBLIC_CLICKADILLA_VAST_TAG || '';
const CLICKADILLA_VAST_TAG = RAW_CLICKADILLA_VAST_TAG
  ? `/api/ads/vast?url=${encodeURIComponent(RAW_CLICKADILLA_VAST_TAG)}`
  : '';
const MIDROLL_SECONDS = Math.max(
  30,
  Number(process.env.NEXT_PUBLIC_CLICKADILLA_MIDROLL_SECONDS || 60) || 60
);

// ── Main player ─────────────────────────────────────────────────────────────
export default function VideoPlayer({ episode }) {
  const { user, loading: authLoading } = useAuth();
  const videoRef                  = useRef(null);
  const containerRef              = useRef(null);
  const [videoUrl, setVideoUrl]   = useState(null);
  const [playing, setPlaying]     = useState(false);
  const [muted, setMuted]         = useState(false);
  const [volume, setVolume]       = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration]   = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [buffering, setBuffering] = useState(false);
  const [playbackError, setPlaybackError] = useState(null);
  const [gateKey, setGateKey]     = useState(0);
  const [midrollActive, setMidrollActive] = useState(false);
  const [midrollPlayBlocked, setMidrollPlayBlocked] = useState(false);
  const hideTimer                 = useRef(null);
  const midrollVideoRef           = useRef(null);
  const midrollPlayerRef          = useRef(null);
  const midrollTriggeredRef       = useRef(false);
  const lastVideoTimeRef          = useRef(0);
  const analyticsStartedRef       = useRef(false);
  const analyticsCompleteRef      = useRef(false);
  const analyticsLastSentRef      = useRef(0);
  const analyticsLastTimeRef      = useRef(0);

  const onVideoReady = useCallback((url) => {
    setPlaybackError(null);
    setVideoUrl(url);
  }, []);

  // Playback URL expired or otherwise failed mid-stream — don't crash,
  // show a clean message and let the viewer restart the flow deliberately
  // (no auto-retry loop).
  const handlePlaybackError = useCallback(() => {
    setVideoUrl(null);
    setPlaybackError('Your playback session expired. Restart the episode to keep watching.');
  }, []);

  const handleRestart = useCallback(() => {
    setPlaybackError(null);
    setGateKey(k => k + 1);
  }, []);

  // Auto-hide controls
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    clearTimeout(hideTimer.current);
    if (playing) {
      hideTimer.current = setTimeout(() => setShowControls(false), 3000);
    }
  }, [playing]);

  useEffect(() => {
    resetHideTimer();
    return () => clearTimeout(hideTimer.current);
  }, [playing, resetHideTimer]);

  const finishMidroll = useCallback((reason = 'completed') => {
    if (!midrollTriggeredRef.current) return;

    try { midrollPlayerRef.current?.destroy?.(); } catch (_) {}
    midrollPlayerRef.current = null;
    setMidrollPlayBlocked(false);
    setMidrollActive(false);

    logAdEvent('clickadilla_midroll_complete', {
      episodeId: String(episode?.id || ''),
      reason,
      triggerSeconds: MIDROLL_SECONDS,
    });

    window.setTimeout(() => {
      const v = videoRef.current;
      if (!v) return;
      const attempt = v.play();
      Promise.resolve(attempt).catch(() => {
        // If autoplay/resume is blocked, the normal player controls remain
        // available and the viewer can press Play.
      });
    }, 0);
  }, [episode?.id]);

  // Mount a dedicated Fluid Player only for the mid-roll break. The main
  // content player remains a normal HTML5 video, so the existing playback
  // protection and progress tracking remain intact.
  useEffect(() => {
    if (!midrollActive || !CLICKADILLA_VAST_TAG) return undefined;

    let cancelled = false;

    const waitForFluidPlayer = () => new Promise((resolve, reject) => {
      if (typeof window !== 'undefined' && typeof window.fluidPlayer === 'function') {
        resolve(window.fluidPlayer);
        return;
      }

      const timeoutAt = Date.now() + 15000;
      const tick = () => {
        if (typeof window !== 'undefined' && typeof window.fluidPlayer === 'function') {
          resolve(window.fluidPlayer);
          return;
        }
        if (Date.now() >= timeoutAt) {
          reject(new Error('Fluid Player has not loaded.'));
          return;
        }
        window.setTimeout(tick, 100);
      };
      tick();
    });

    (async () => {
      try {
        const fluidPlayer = await waitForFluidPlayer();
        if (cancelled || !midrollVideoRef.current) return;

        const element = midrollVideoRef.current;
        element.muted = true;
        element.playsInline = true;
        element.controls = false;
        element.preload = 'auto';

        logAdEvent('clickadilla_midroll_request', {
          episodeId: String(episode?.id || ''),
          triggerSeconds: MIDROLL_SECONDS,
        });

        const player = fluidPlayer(element, {
          layoutControls: {
            primaryColor: '#8b5cf6',
            autoPlay: true,
            mute: true,
            playButtonShowing: true,
            allowDownload: false,
            playbackRateEnabled: false,
            controlBar: { autoHide: false },
          },
          vastOptions: {
            adList: [
              {
                roll: 'preRoll',
                vastTag: CLICKADILLA_VAST_TAG,
              },
            ],
            vastTimeout: 10000,
            showPlayButton: true,
            maxAllowedVastTagRedirects: 5,
            vastAdvanced: {
              vastLoadedCallback: () => {
                logAdEvent('clickadilla_midroll_vast_loaded', {
                  episodeId: String(episode?.id || ''),
                });
              },
              noVastVideoCallback: () => {
                logAdEvent('clickadilla_midroll_no_fill', {
                  episodeId: String(episode?.id || ''),
                });
                finishMidroll('no-fill');
              },
              vastVideoSkippedCallback: () => {
                logAdEvent('clickadilla_midroll_skipped', {
                  episodeId: String(episode?.id || ''),
                });
                finishMidroll('skipped');
              },
              vastVideoEndedCallback: () => {
                logAdEvent('clickadilla_midroll_completed', {
                  episodeId: String(episode?.id || ''),
                });
                finishMidroll('completed');
              },
            },
          },
        });

        midrollPlayerRef.current = player;

        try {
          await Promise.resolve(
            typeof player?.play === 'function' ? player.play() : element.play()
          );
          if (!cancelled) setMidrollPlayBlocked(false);
        } catch (error) {
          if (!cancelled) {
            setMidrollPlayBlocked(true);
            logAdEvent('clickadilla_midroll_autoplay_blocked', {
              episodeId: String(episode?.id || ''),
              error: error?.message || 'play() rejected',
            });
          }
        }
      } catch (error) {
        if (!cancelled) {
          logAdEvent('clickadilla_midroll_player_error', {
            episodeId: String(episode?.id || ''),
            error: error?.message || 'Mid-roll player failed',
          });
          // Never strand the viewer because a mid-roll failed.
          finishMidroll('player-error');
        }
      }
    })();

    return () => {
      cancelled = true;
      try { midrollPlayerRef.current?.destroy?.(); } catch (_) {}
      midrollPlayerRef.current = null;
    };
  }, [midrollActive, episode?.id, finishMidroll]);

  useEffect(() => {
    if (!videoRef.current || !videoUrl) return;
    const v = videoRef.current;

    const onTimeUpdate = () => {
      setCurrentTime(v.currentTime);

      const previous = lastVideoTimeRef.current || 0;
      if (
        !midrollTriggeredRef.current &&
        !midrollActive &&
        Number.isFinite(v.currentTime) &&
        previous < MIDROLL_SECONDS &&
        v.currentTime >= MIDROLL_SECONDS &&
        v.duration > MIDROLL_SECONDS + 10
      ) {
        midrollTriggeredRef.current = true;
        logAdEvent('clickadilla_midroll_trigger', {
          episodeId: String(episode?.id || ''),
          currentTime: v.currentTime,
          duration: Number.isFinite(v.duration) ? v.duration : 0,
          triggerSeconds: MIDROLL_SECONDS,
        });
        v.pause();
        setMidrollActive(true);
      }

      lastVideoTimeRef.current = Number.isFinite(v.currentTime) ? v.currentTime : previous;

      if (!analyticsStartedRef.current || !Number.isFinite(v.currentTime)) return;
      if (v.currentTime - analyticsLastSentRef.current >= 10) {
        const delta = Math.max(0, v.currentTime - analyticsLastTimeRef.current);
        analyticsLastSentRef.current = v.currentTime;
        analyticsLastTimeRef.current = v.currentTime;
        saveWatchProgress({
          episodeId: String(episode?.id || ''),
          positionSeconds: v.currentTime,
          durationSeconds: Number.isFinite(v.duration) ? v.duration : 0,
          completed: false,
        });
        trackAnalyticsEvent('video_progress', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
          durationSeconds: Math.min(30, delta),
        });
      }
      if (!analyticsCompleteRef.current && v.duration && v.currentTime >= v.duration - 1) {
        analyticsCompleteRef.current = true;
        saveWatchProgress({ episodeId: String(episode?.id || ''), positionSeconds: v.currentTime, durationSeconds: v.duration, completed: true });
        trackAnalyticsEvent('video_complete', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime,
          videoDuration: v.duration,
        });
      }
    };
    const onDuration   = () => setDuration(v.duration);
    const onPlay       = () => {
      setPlaying(true);
      if (!analyticsStartedRef.current) {
        analyticsStartedRef.current = true;
        analyticsLastSentRef.current = v.currentTime || 0;
        analyticsLastTimeRef.current = v.currentTime || 0;
        trackAnalyticsEvent('video_start', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime || 0,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
        });
      }
    };
    const onPause      = () => {
      setPlaying(false);
      if (analyticsStartedRef.current && !analyticsCompleteRef.current) {
        const delta = Math.max(0, (v.currentTime || 0) - (analyticsLastTimeRef.current || 0));
        if (delta > 0) {
          analyticsLastSentRef.current = v.currentTime || 0;
          analyticsLastTimeRef.current = v.currentTime || 0;
          trackAnalyticsEvent('video_progress', {
            episodeId: String(episode?.id || ''),
            videoSeconds: v.currentTime || 0,
            videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
            durationSeconds: Math.min(30, delta),
          });
        }
        trackAnalyticsEvent('video_pause', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime || 0,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
        });
      }
    };
    const onEnded      = () => {
      if (!analyticsCompleteRef.current) {
        analyticsCompleteRef.current = true;
        saveWatchProgress({ episodeId: String(episode?.id || ''), positionSeconds: Number.isFinite(v.duration) ? v.duration : v.currentTime, durationSeconds: Number.isFinite(v.duration) ? v.duration : 0, completed: true });
        trackAnalyticsEvent('video_complete', {
          episodeId: String(episode?.id || ''),
          videoSeconds: Number.isFinite(v.duration) ? v.duration : v.currentTime,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
        });
      }
      trackAnalyticsEvent('video_end', { episodeId: String(episode?.id || ''), videoSeconds: v.currentTime || 0, videoDuration: v.duration || 0 });
    };
    const onWaiting    = () => setBuffering(true);
    const onCanPlay    = () => setBuffering(false);
    const onError      = () => handlePlaybackError();

    v.addEventListener('timeupdate', onTimeUpdate);
    v.addEventListener('loadedmetadata', onDuration);
    v.addEventListener('play', onPlay);
    v.addEventListener('pause', onPause);
    v.addEventListener('ended', onEnded);
    v.addEventListener('waiting', onWaiting);
    v.addEventListener('canplay', onCanPlay);
    v.addEventListener('error', onError);

    return () => {
      v.removeEventListener('timeupdate', onTimeUpdate);
      v.removeEventListener('loadedmetadata', onDuration);
      v.removeEventListener('play', onPlay);
      v.removeEventListener('pause', onPause);
    v.removeEventListener('ended', onEnded);
      v.removeEventListener('waiting', onWaiting);
      v.removeEventListener('canplay', onCanPlay);
      v.removeEventListener('error', onError);
    };
  }, [videoUrl, handlePlaybackError, midrollActive, episode?.id]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    playing ? v.pause() : v.play();
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !muted;
    setMuted(!muted);
  };

  const onSeek = (e) => {
    const v = videoRef.current;
    if (!v || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct  = (e.clientX - rect.left) / rect.width;
    v.currentTime = pct * duration;
  };

  const toggleFullscreen = () => {
    const el = containerRef.current;
    if (!document.fullscreenElement) {
      el?.requestFullscreen?.();
      setFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setFullscreen(false);
    }
  };

  const formatTime = (s) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    if (videoUrl) {
      midrollTriggeredRef.current = false;
      lastVideoTimeRef.current = 0;
    }
  }, [videoUrl]);

  const progress = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="video-container aspect-video bg-black select-none"
      onMouseMove={resetHideTimer}
      onTouchStart={resetHideTimer}
    >
      {/* Account gate — public discovery stays open, playback requires login. */}
      {!authLoading && !user && !videoUrl && (
        <div className="ad-overlay flex flex-col items-center justify-center gap-4 p-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-violet/15 border border-violet/25 flex items-center justify-center">
            <Play size={24} className="text-violet-light fill-current" />
          </div>
          <div>
            <p className="text-white font-semibold">Sign in to watch this episode</p>
            <p className="text-xs text-muted mt-1 max-w-xs">Browse freely, then create a free account or sign in to start playback.</p>
          </div>
          <div className="flex items-center gap-2">
            <a href={`/register?next=${encodeURIComponent(typeof window !== 'undefined' ? window.location.pathname : '')}`} className="px-4 py-2 rounded-lg bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold">Create Account</a>
            <a href={`/login?next=${encodeURIComponent(typeof window !== 'undefined' ? window.location.pathname : '')}`} className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm font-medium">Sign In</a>
          </div>
        </div>
      )}
      {!authLoading && user && !videoUrl && !playbackError && (
        <ClickadillaVastGate key={gateKey} episode={episode} onVideoReady={onVideoReady} />
      )}

      {/* Expired / failed playback — clean message, manual restart (no auto-retry loop) */}
      {!videoUrl && playbackError && (
        <div className="ad-overlay flex flex-col items-center justify-center gap-3 p-8 text-center">
          <AlertCircle size={32} className="text-danger" />
          <p className="text-sm text-white font-medium">Playback session expired</p>
          <p className="text-xs text-muted max-w-xs">{playbackError}</p>
          <button
            onClick={handleRestart}
            className="btn-glow px-5 py-2 rounded-full bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300"
          >
            Restart Episode
          </button>
        </div>
      )}

      {/* Dedicated mid-roll ad break */}
      {videoUrl && midrollActive && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black">
          <video
            ref={midrollVideoRef}
            id={`clickadilla-midroll-${episode?.id || 'episode'}`}
            className="w-full h-full object-contain"
            playsInline
            muted
            autoPlay
            preload="auto"
            aria-label="Advertisement"
          />
          {midrollPlayBlocked && (
            <button
              type="button"
              onClick={() => {
                const p = midrollPlayerRef.current;
                const attempt = typeof p?.play === 'function'
                  ? p.play()
                  : midrollVideoRef.current?.play();

                Promise.resolve(attempt)
                  .then(() => setMidrollPlayBlocked(false))
                  .catch(() => {});
              }}
              className="absolute inset-0 m-auto w-fit h-fit px-5 py-3 rounded-full bg-violet text-white font-semibold flex items-center gap-2 shadow-lg"
            >
              <Play size={18} fill="currentColor" />
              Play Advertisement
            </button>
          )}
        </div>
      )}

      {/* Video element */}
      {videoUrl && (
        <PlaybackProtection
          active={Boolean(videoUrl)}
          userLabel={user?.email || user?.name || 'Authorized Viewer'}
        >
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-full object-contain"
            playsInline
            preload="metadata"
            autoPlay
            controlsList="nodownload noplaybackrate"
            disablePictureInPicture
            onContextMenu={(e) => e.preventDefault()}
            onDragStart={(e) => e.preventDefault()}
            onClick={togglePlay}
          />

          {/* Buffering spinner */}
          {buffering && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <Loader2 size={40} className="text-violet animate-spin" />
            </div>
          )}

          {/* Controls overlay */}
          <div
            className={`absolute inset-0 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
          >
            {/* Top gradient */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-black/70 to-transparent" />

            {/* Bottom controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              {/* Progress bar */}
              <div
                className="w-full h-1 mb-3 rounded-full bg-white/20 cursor-pointer group relative"
                onClick={onSeek}
              >
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet to-cyan transition-all"
                  style={{ width: `${progress}%` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white opacity-0 group-hover:opacity-100 transition-opacity shadow-glow-violet"
                  style={{ left: `${progress}%`, transform: 'translate(-50%, -50%)' }}
                />
              </div>

              {/* Button row */}
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <button onClick={togglePlay} className="text-white hover:text-violet-light transition-colors">
                    {playing
                      ? <Pause size={20} className="fill-current" />
                      : <Play  size={20} className="fill-current ml-0.5" />
                    }
                  </button>
                  <button onClick={toggleMute} className="text-white hover:text-violet-light transition-colors">
                    {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                  </button>
                  <span className="text-xs text-white/70 tabular-nums">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={toggleFullscreen} className="text-white hover:text-violet-light transition-colors">
                    {fullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </PlaybackProtection>
      )}
    </div>
  );
}
