import { NextResponse } from 'next/server';

const ALLOWED_HOSTS = new Set([
  'vast.yomeno.xyz',
  'clickadilla.com',
]);

function isAllowedHost(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/\.$/, '');
  if (ALLOWED_HOSTS.has(host)) return true;
  return host.endsWith('.clickadilla.com');
}

export async function GET(request) {
  try {
    const source = request.nextUrl.searchParams.get('url');
    if (!source) {
      return NextResponse.json({ ok: false, error: 'Missing VAST url' }, { status: 400 });
    }

    let upstream;
    try {
      upstream = new URL(source);
    } catch {
      return NextResponse.json({ ok: false, error: 'Invalid VAST url' }, { status: 400 });
    }

    if (upstream.protocol !== 'https:' || !isAllowedHost(upstream.hostname)) {
      return NextResponse.json({ ok: false, error: 'VAST host is not allowed' }, { status: 403 });
    }

    const response = await fetch(upstream.toString(), {
      method: 'GET',
      headers: {
        Accept: 'application/xml,text/xml;q=0.9,*/*;q=0.8',
        'User-Agent': 'StreamVerse-Studio-VAST-Proxy/1.0',
      },
      cache: 'no-store',
      redirect: 'follow',
    });

    const body = await response.text();

    if (!response.ok) {
      return new NextResponse(body || `VAST upstream returned ${response.status}`, {
        status: response.status,
        headers: {
          'Content-Type': response.headers.get('content-type') || 'text/plain; charset=utf-8',
          'Cache-Control': 'no-store',
          'Access-Control-Allow-Origin': '*',
        },
      });
    }

    // Fluid Player expects an XML response. Preserve XML/text content type
    // even when the upstream host sends a generic response content type.
    const contentType = /xml/i.test(response.headers.get('content-type') || '')
      ? response.headers.get('content-type')
      : 'application/xml; charset=utf-8';

    return new NextResponse(body, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Access-Control-Allow-Origin': '*',
        'X-StreamVerse-VAST-Proxy': '1',
      },
    });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error?.message || 'VAST proxy failed' },
      { status: 502, headers: { 'Cache-Control': 'no-store' } }
    );
  }
}
