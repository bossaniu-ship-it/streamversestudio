'use client';

import Link from 'next/link';
import { Play, Clock, Tv } from 'lucide-react';
import GenreBadge from './GenreBadge';
import { timeAgo } from '@/lib/api';
import ShareButton from './ShareButton';
import PreviewVideo from './PreviewVideo';

export default function EpisodeCard({ episode, priority = false }) {
  const thumb = episode.thumbnailUrl || null;
  const preview = episode.previewUrl || null;
  const hasId = !!episode.id;
  const href = hasId ? `/watch/${episode.id}` : null;

  const content = (
    <div className="group glass rounded-2xl overflow-hidden card-lift cursor-pointer border border-white/5 hover:border-violet/30 transition-colors duration-300">
      <div className="relative aspect-video bg-gradient-to-br from-surface to-nebula overflow-hidden">
        {preview ? (
          <PreviewVideo
            src={preview}
            poster={thumb}
            title={episode.episodeTitle || episode.title}
            priority={priority}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : thumb ? (
          <img src={thumb} alt={episode.episodeTitle || episode.title} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading={priority ? 'eager' : 'lazy'} />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-violet/10 to-cyan/5">
            <Tv size={40} className="text-violet/30" />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
        <div className="absolute top-3 left-3"><GenreBadge genre={episode.genre} size="xs" /></div>
        <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-sm">
          <Clock size={10} className="text-muted" />
          <span suppressHydrationWarning className="text-[10px] text-muted">{timeAgo(episode.postedAt)}</span>
        </div>
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none">
          <div className="w-14 h-14 rounded-full bg-violet/90 flex items-center justify-center shadow-glow-violet backdrop-blur-sm transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play size={22} className="text-white fill-white ml-1" />
          </div>
        </div>
        <div className="absolute bottom-3 left-3 right-3">
          <span className="inline-flex px-2 py-1 rounded-md bg-black/55 backdrop-blur text-[10px] text-white/80">
            S{episode.seasonNumber || 1} · E{episode.episodeNumber || 1}
          </span>
        </div>
      </div>

      <div className="p-4">
        <p className="text-xs text-violet-light font-medium mb-1 truncate">{episode.title}</p>
        <h3 className="font-display font-semibold text-white text-[15px] leading-snug mb-2 line-clamp-2 group-hover:text-violet-light transition-colors duration-200">
          {episode.episodeTitle || 'Untitled Episode'}
        </h3>
        {episode.synopsis && <p className="text-xs text-muted line-clamp-2 leading-relaxed">{episode.synopsis}</p>}
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
          <ShareButton episode={episode} compact className="p-1.5 rounded-lg text-muted hover:text-white hover:bg-white/5 transition-colors" />
          <span className="text-[11px] font-medium text-violet-light flex items-center gap-1"><Play size={10} className="fill-current" />{hasId ? 'Watch Now' : 'View'}</span>
        </div>
      </div>
    </div>
  );

  return href ? <Link href={href} className="block">{content}</Link> : <div>{content}</div>;
}
