'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AlertCircle, Loader2, Volume2, VolumeX } from 'lucide-react';

const DEFAULT_VAST_PROXY = '/api/ads/vast';
const DEFAULT_MEDIA_PROXY = '/api/ads/media';
const MAX_VAST_DEPTH = 8;
const MEDIA_WATCHDOG_MS = 15000;

function textOf(node) {
  if (typeof node === 'string') return node.trim();
  return String(node?.textContent ?? node?.url ?? '').trim();
}

function attrOf(node, name, fallback = '') {
  if (node && typeof node.getAttribute === 'function') {
    return node.getAttribute(name) ?? fallback;
  }
  if (node && typeof node === 'object' && Object.prototype.hasOwnProperty.call(node, name)) {
    return node[name] ?? fallback;
  }
  return fallback;
}

function firstText(parent, tagName) {
  return textOf(parent?.querySelector(tagName));
}

function allTexts(parent, tagName) {
  return Array.from(parent?.querySelectorAll(tagName) || [])
    .map(textOf)
    .filter(Boolean);
}

function parseDuration(value) {
  const m = String(value || '').trim().match(/^(?:(\d+):)?(\d+):(\d+)(?:\.(\d+))?$/);
  if (!m) return 0;
  const hours = Number(m[1] || 0);
  const minutes = Number(m[2] || 0);
  const seconds = Number(m[3] || 0);
  const fraction = m[4] ? Number(`0.${m[4]}`) : 0;
  return hours * 3600 + minutes * 60 + seconds + fraction;
}

function parseOffset(value, duration) {
  const raw = String(value || '').trim();
  if (!raw) return 0;
  if (raw.endsWith('%')) {
    const pct = Number(raw.slice(0, -1));
    return Number.isFinite(pct) && duration > 0 ? duration * pct / 100 : 0;
  }
  return parseDuration(raw);
}

function replaceMacros(url, { cachebuster, timestamp, errorCode = '204' } = {}) {
  return String(url || '')
    .replace(/\[CACHEBUSTING\]|\[CACHEBUSTER\]|\[CACHE_BUSTING\]|%%CACHEBUSTING%%/gi, cachebuster)
    .replace(/\[TIMESTAMP\]|%%TIMESTAMP%%/gi, timestamp)
    .replace(/\[ERRORCODE\]|%%ERRORCODE%%/gi, errorCode);
}

function fireTracking(urls, context = {}) {
  const cachebuster = String(Math.floor(Math.random() * 1e9));
  const timestamp = new Date().toISOString();
  for (const raw of urls || []) {
    const url = replaceMacros(raw, { cachebuster, timestamp, ...context });
    if (!url) continue;
    try {
      const image = new Image();
      image.referrerPolicy = 'no-referrer-when-downgrade';
      image.src = url;
    } catch (_) {}
  }
}

function absolutizeUrl(value, baseUrl) {
  try {
    return new URL(String(value || '').trim(), baseUrl).toString();
  } catch {
    return '';
  }
}

function buildProxyUrl(url, origin = '') {
  if (!url) return '';
  if (!origin) return url;
  try {
    const parsed = new URL(url, origin);
    if (parsed.origin === origin) return parsed.toString();
    return `${DEFAULT_VAST_PROXY}?url=${encodeURIComponent(parsed.toString())}`;
  } catch {
    return '';
  }
}

function buildMediaProxyUrl(url, origin = '') {
  if (!url || !origin) return url;
  try {
    const parsed = new URL(url, origin);
    if (parsed.origin === origin) return parsed.toString();
    return `${DEFAULT_MEDIA_PROXY}?url=${encodeURIComponent(parsed.toString())}`;
  } catch {
    return url;
  }
}

function normalizeMediaFiles(files) {
  return Array.from(files || [])
    .map((node) => {
      const type = String(attrOf(node, 'type') || '').trim().toLowerCase();
      const apiFramework = String(attrOf(node, 'apiFramework') || '').trim().toLowerCase();
      const delivery = String(attrOf(node, 'delivery') || '').trim().toLowerCase();
      const raw = textOf(node);
      return {
        url: raw,
        type,
        apiFramework,
        delivery,
        width: Number(attrOf(node, 'width') || 0),
        height: Number(attrOf(node, 'height') || 0),
        bitrate: Number(attrOf(node, 'bitrate') || 0),
        scalable: attrOf(node, 'scalable') !== 'false',
        maintainAspectRatio: attrOf(node, 'maintainAspectRatio') !== 'false',
      };
    })
    .filter((file) => file.url)
    // ClickAdilla's current in-stream requirements are MP4/H.264/AAC.
    // Never try JavaScript/VPAID media as native <video> sources.
    .filter((file) => !['vpaid', 'vpaidjs', 'application/javascript', 'text/javascript'].includes(file.apiFramework) && !/javascript/i.test(file.type));
}

function mediaScore(file, element) {
  const type = file.type || 'video/mp4';
  let score = 0;
  try {
    const support = element?.canPlayType?.(type) || '';
    if (support === 'probably') score += 5000;
    else if (support === 'maybe') score += 2500;
  } catch (_) {}
  if (type === 'video/mp4') score += 2000;
  if (/h264|avc/i.test(type)) score += 300;
  if (file.delivery === 'progressive') score += 120;
  score += Math.min(300, Math.max(0, file.bitrate / 100));
  if (file.width > 0 && file.height > 0) score += Math.min(200, (file.width * file.height) / 10000);
  return score;
}

function rankMediaFiles(files, element) {
  return Array.from(files || [])
    .filter((file) => file && file.url)
    .map((file, index) => ({ ...file, originalIndex: index }))
    .sort((a, b) => mediaScore(b, element) - mediaScore(a, element));
}

async function fetchVastDocument(url, { maxDepth = MAX_VAST_DEPTH, signal } = {}) {
  let currentUrl = url;
  const wrapperImpressions = [];
  const wrapperTracking = [];
  const wrapperClicks = [];
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const visited = new Set();

  for (let depth = 0; depth <= maxDepth; depth += 1) {
    const requestUrl = buildProxyUrl(currentUrl, origin);
    if (!requestUrl || visited.has(requestUrl)) throw new Error('The VAST wrapper chain looped or became invalid.');
    visited.add(requestUrl);

    const response = await fetch(requestUrl, {
      method: 'GET',
      cache: 'no-store',
      signal,
      headers: { Accept: 'application/xml,text/xml;q=0.9,*/*;q=0.8' },
    });
    const body = await response.text();

    if (response.status === 204 || response.status === 404 || response.status === 410) {
      const error = new Error('No advertisement is currently available.');
      error.code = 'NO_FILL';
      throw error;
    }
    if (!response.ok) throw new Error(`VAST request failed (${response.status})`);
    if (!body || !/<VAST[\s>]/i.test(body)) throw new Error('The ad server returned an invalid VAST response.');

    const document = new DOMParser().parseFromString(body, 'text/xml');
    if (document.querySelector('parsererror')) throw new Error('The ad server returned malformed VAST XML.');

    const ads = Array.from(document.querySelectorAll(':scope > Ad, Ad'));
    if (!ads.length) { const error = new Error('No advertisement is currently available.'); error.code = 'NO_FILL'; throw error; }

    let fallbackNonLinear = null;
    let nextWrapper = null;

    for (const ad of ads) {
      const inline = ad.querySelector(':scope > InLine') || ad.querySelector('InLine');
      const wrapper = ad.querySelector(':scope > Wrapper') || ad.querySelector('Wrapper');

      if (wrapper && !inline) {
        const next = firstText(wrapper, 'VASTAdTagURI');
        if (!next) continue;
        if (!nextWrapper) nextWrapper = { wrapper, next };
        continue;
      }

      if (!inline) {
        const nonLinear = ad.querySelector('NonLinear');
        if (nonLinear) fallbackNonLinear = nonLinear;
        continue;
      }

      const linear = inline.querySelector('Linear');
      if (!linear) continue;

      const mediaFiles = normalizeMediaFiles(linear.querySelectorAll('MediaFiles MediaFile'));
      if (!mediaFiles.length) continue;

      const duration = parseDuration(firstText(linear, 'Duration'));
      const clickThrough = firstText(linear, 'VideoClicks ClickThrough');
      const clickTracking = allTexts(linear, 'VideoClicks ClickTracking');
      const skipoffset = attrOf(linear, 'skipoffset') || '';
      const tracking = Array.from(linear.querySelectorAll('TrackingEvents Tracking'))
        .map((node) => ({
          event: String(attrOf(node, 'event') || '').toLowerCase(),
          offset: String(attrOf(node, 'offset') || ''),
          url: textOf(node),
        }))
        .filter((item) => item.url);

      return {
        adId: String(attrOf(ad, 'id') || ''),
        duration,
        mediaFiles,
        clickThrough,
        clickTracking: [...wrapperClicks, ...clickTracking],
        impressions: [...wrapperImpressions, ...allTexts(inline, 'Impression')],
        tracking: [...wrapperTracking, ...tracking],
        skipSeconds: parseOffset(skipoffset, duration),
        errorUrls: [...wrapperTracking.filter((x) => x.event === 'error').map((x) => x.url), ...allTexts(inline, 'Error')],
      };
    }

    if (nextWrapper) {
      wrapperImpressions.push(...allTexts(nextWrapper.wrapper, 'Impression'));
      wrapperTracking.push(...Array.from(nextWrapper.wrapper.querySelectorAll('Tracking'))
        .map((node) => ({
          event: String(attrOf(node, 'event') || '').toLowerCase(),
          offset: String(attrOf(node, 'offset') || ''),
          url: textOf(node),
        }))
        .filter((item) => item.url));
      wrapperClicks.push(...allTexts(nextWrapper.wrapper, 'ClickTracking'));
      const nextUrl = absolutizeUrl(nextWrapper.next, currentUrl);
      if (!nextUrl) throw new Error('The VAST wrapper URL is invalid.');
      currentUrl = nextUrl;
      continue;
    }

    const error = new Error('The VAST response contains no playable linear video advertisement.');
    error.code = 'NO_FILL';
    throw error;
  }

  throw new Error('Too many VAST wrappers.');
}

export default function ClickadillaVastAd({
  vastUrl,
  onComplete,
  onError,
  className = '',
  autoPlay = true,
  label = 'Advertisement',
}) {
  const videoRef = useRef(null);
  const dataRef = useRef(null);
  const rankedMediaRef = useRef([]);
  const mediaAttemptRef = useRef(0);
  const mediaProxyModeRef = useRef(false);
  const mediaWatchdogRef = useRef(null);
  const firedRef = useRef(new Set());
  const completeRef = useRef(false);
  const startedRef = useRef(false);
  const [phase, setPhase] = useState('loading');
  const [message, setMessage] = useState('Loading advertisement…');
  const [muted, setMuted] = useState(true);
  const [skipReady, setSkipReady] = useState(false);
  const [adPlayBlocked, setAdPlayBlocked] = useState(false);
  const [clickThrough, setClickThrough] = useState('');

  const safeComplete = useCallback((reason = 'completed') => {
    if (completeRef.current) return;
    completeRef.current = true;
    clearMediaWatchdog();
    onComplete?.(reason);
  }, [clearMediaWatchdog, onComplete]);

  const logClientAdError = useCallback((error, extra = {}) => {
    try {
      window.dispatchEvent(new CustomEvent('streamverse-ad-diagnostic', {
        detail: {
          error: String(error?.message || error || 'unknown'),
          ...extra,
        },
      }));
    } catch (_) {}
  }, []);

  const reportError = useCallback((error, context = {}) => {
    logClientAdError(error, context);
    onError?.(error);
  }, [logClientAdError, onError]);

  const clearMediaWatchdog = useCallback(() => {
    if (mediaWatchdogRef.current) {
      clearTimeout(mediaWatchdogRef.current);
      mediaWatchdogRef.current = null;
    }
  }, []);

  const startMediaAttempt = useCallback((index, { viaProxy = false } = {}) => {
    const video = videoRef.current;
    const data = dataRef.current;
    const ranked = rankedMediaRef.current;
    if (!video || !data || !ranked.length) {
      reportError(new Error('No playable advertisement media was returned.'), { stage: 'media-selection' });
      return;
    }

    clearMediaWatchdog();
    mediaAttemptRef.current = index;
    mediaProxyModeRef.current = viaProxy;

    const media = ranked[index];
    if (!media) {
      if (!mediaProxyModeRef.current) {
        startMediaAttempt(0, { viaProxy: true });
        return;
      }
      logClientAdError('All advertisement media sources failed.', { attempts: ranked.length });
      reportError(new Error('The advertisement video could not be played after trying all available creatives.'), { stage: 'media-exhausted', attempts: ranked.length });
      return;
    }

    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const source = viaProxy ? buildMediaProxyUrl(media.url, origin) : media.url;
    setPhase('loading');
    setMessage(viaProxy ? 'Loading advertisement…' : 'Preparing advertisement…');
    setAdPlayBlocked(false);
    startedRef.current = false;

    video.pause();
    video.removeAttribute('src');
    video.load();
    video.muted = true;
    video.playsInline = true;
    video.preload = 'auto';
    video.setAttribute('aria-label', label);
    video.src = source;
    video.load();

    mediaWatchdogRef.current = window.setTimeout(() => {
      mediaWatchdogRef.current = null;
      try { video.pause(); } catch (_) {}
      if (index + 1 < ranked.length) {
        startMediaAttempt(index + 1, { viaProxy });
      } else if (!viaProxy) {
        startMediaAttempt(0, { viaProxy: true });
      } else {
        reportError(new Error('The advertisement video timed out while loading.'), { stage: 'media-timeout', attempt: index });
      }
    }, MEDIA_WATCHDOG_MS);
  }, [clearMediaWatchdog, label, safeComplete]);

  useEffect(() => {
    const controller = new AbortController();
    let disposed = false;

    if (!vastUrl) {
      setPhase('unavailable');
      setMessage('No advertisement tag is configured.');
      return () => controller.abort();
    }

    setPhase('loading');
    setMessage('Preparing advertisement…');
    setSkipReady(false);
    setAdPlayBlocked(false);
    completeRef.current = false;
    startedRef.current = false;
    mediaAttemptRef.current = 0;
    mediaProxyModeRef.current = false;
    dataRef.current = null;
    rankedMediaRef.current = [];
    firedRef.current = new Set();
    clearMediaWatchdog();

    (async () => {
      try {
        const data = await fetchVastDocument(vastUrl, { signal: controller.signal });
        if (disposed) return;

        const ranked = rankMediaFiles(data.mediaFiles, videoRef.current);
        if (!ranked.length) throw new Error('No supported MPEG-4 video creative was returned.');

        dataRef.current = data;
        rankedMediaRef.current = ranked;
        setClickThrough(data.clickThrough || '');
        setPhase('loading');
        setMessage('Loading advertisement…');
        startMediaAttempt(0, { viaProxy: false });
      } catch (error) {
        if (disposed || error?.name === 'AbortError') return;
        const noFill = error?.code === 'NO_FILL';
        if (noFill) {
          safeComplete('no-fill');
          return;
        }
        reportError(error, { stage: 'vast-fetch' });
        setPhase('error');
        setMessage(error?.message || 'The advertisement could not be loaded.');
      }
    })();

    return () => {
      disposed = true;
      controller.abort();
      clearMediaWatchdog();
    };
  }, [vastUrl, safeComplete, clearMediaWatchdog, startMediaAttempt, reportError]);

  useEffect(() => {
    if (phase !== 'loading' || !autoPlay) return undefined;
    const video = videoRef.current;
    if (!video) return undefined;

    const playNow = () => {
      Promise.resolve(video.play())
        .then(() => setAdPlayBlocked(false))
        .catch(() => setAdPlayBlocked(true));
    };

    if (video.readyState >= 2) playNow();
    else video.addEventListener('canplay', playNow, { once: true });
    return () => video.removeEventListener('canplay', playNow);
  }, [phase, autoPlay, mediaAttemptRef.current]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return undefined;

    const fireOnce = (key, urls, context = {}) => {
      if (!urls?.length || firedRef.current.has(key)) return;
      firedRef.current.add(key);
      fireTracking(urls, context);
    };

    const onLoadedMetadata = () => {
      clearMediaWatchdog();
      setPhase('ready');
      setMessage('Advertisement');
      if (autoPlay) {
        Promise.resolve(video.play()).then(() => setAdPlayBlocked(false)).catch(() => setAdPlayBlocked(true));
      }
    };

    const onPlay = () => {
      if (startedRef.current) return;
      startedRef.current = true;
      clearMediaWatchdog();
      const data = dataRef.current;
      fireOnce('impression', data?.impressions);
      fireOnce('start', data?.tracking?.filter((item) => item.event === 'start').map((item) => item.url));
      setAdPlayBlocked(false);
      setPhase('playing');
      setMessage('Advertisement');
    };

    const onTimeUpdate = () => {
      const data = dataRef.current;
      const current = Number(video.currentTime) || 0;
      const total = Number(video.duration) || Number(data?.duration) || 0;
      if (!data || !total) return;

      if (data.skipSeconds > 0 && current >= data.skipSeconds) setSkipReady(true);

      const quartiles = [
        ['firstquartile', 0.25],
        ['midpoint', 0.5],
        ['thirdquartile', 0.75],
      ];
      for (const [event, ratio] of quartiles) {
        if (current / total >= ratio) {
          fireOnce(event, data.tracking?.filter((item) => item.event === event).map((item) => item.url));
        }
      }

      for (const item of data.tracking || []) {
        if (item.event !== 'progress' || !item.offset) continue;
        const offset = parseOffset(item.offset, total);
        if (offset > 0 && current >= offset) fireOnce(`progress:${item.offset}:${item.url}`, [item.url]);
      }
    };

    const onEnded = () => {
      clearMediaWatchdog();
      const data = dataRef.current;
      fireOnce('complete', data?.tracking?.filter((item) => item.event === 'complete').map((item) => item.url));
      safeComplete('completed');
    };

    const onError = () => {
      clearMediaWatchdog();
      const current = mediaAttemptRef.current;
      const ranked = rankedMediaRef.current;
      logClientAdError(video.error, {
        stage: 'media',
        code: video.error?.code,
        sourceType: ranked[current]?.type || '',
        proxied: mediaProxyModeRef.current,
      });

      if (current + 1 < ranked.length) {
        startMediaAttempt(current + 1, { viaProxy: mediaProxyModeRef.current });
      } else if (!mediaProxyModeRef.current) {
        startMediaAttempt(0, { viaProxy: true });
      } else {
        reportError(new Error('The advertisement video could not be played after trying all available creatives.'), { stage: 'media-error', attempts: ranked.length });
      }
    };

    video.addEventListener('loadedmetadata', onLoadedMetadata);
    video.addEventListener('play', onPlay);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('ended', onEnded);
    video.addEventListener('error', onError);
    return () => {
      video.removeEventListener('loadedmetadata', onLoadedMetadata);
      video.removeEventListener('play', onPlay);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('ended', onEnded);
      video.removeEventListener('error', onError);
    };
  }, [autoPlay, clearMediaWatchdog, reportError, safeComplete, startMediaAttempt]);

  const toggleMuted = () => {
    const video = videoRef.current;
    if (!video) return;
    const next = !video.muted;
    video.muted = next;
    setMuted(next);
  };

  const handleAdClick = () => {
    const data = dataRef.current;
    fireTracking(data?.clickTracking);
    if (!clickThrough) return;
    try { window.open(clickThrough, '_blank', 'noopener,noreferrer'); } catch (_) { window.location.href = clickThrough; }
  };

  const statusText = useMemo(() => message, [message]);

  return (
    <div className={`absolute inset-0 z-50 flex items-center justify-center bg-black overflow-hidden ${className}`}>
      <video
        ref={videoRef}
        className="w-full h-full object-contain bg-black"
        playsInline
        muted
        preload="metadata"
        onClick={handleAdClick}
      />

      {(phase === 'loading' || phase === 'ready') && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="rounded-xl bg-black/65 backdrop-blur-sm px-4 py-3 text-center">
            <Loader2 size={24} className="mx-auto mb-2 text-violet animate-spin" />
            <p className="text-xs text-white/80">{statusText}</p>
            {phase === 'ready' && <p className="text-[10px] text-white/45 mt-1">Click the ad to learn more</p>}
          </div>
        </div>
      )}

      {phase === 'ready' && adPlayBlocked && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            type="button"
            onClick={(event) => {
              event.stopPropagation();
              const video = videoRef.current;
              if (!video) return;
              Promise.resolve(video.play())
                .then(() => setAdPlayBlocked(false))
                .catch(() => {});
            }}
            className="pointer-events-auto inline-flex items-center gap-2 px-5 py-3 rounded-full bg-violet text-white text-sm font-semibold shadow-glow-violet border border-white/10"
          >
            Play Advertisement
          </button>
        </div>
      )}

      {(phase === 'playing' || phase === 'ready') && (
        <div className="absolute left-3 right-3 bottom-3 flex items-end justify-between gap-3 pointer-events-none">
          <div className="rounded-md bg-black/55 px-2.5 py-1.5 text-[10px] text-white/70 backdrop-blur-sm">{label}</div>
          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={toggleMuted}
              aria-label={muted ? 'Unmute advertisement' : 'Mute advertisement'}
              className="w-8 h-8 rounded-full bg-black/60 border border-white/15 text-white flex items-center justify-center backdrop-blur-sm"
            >
              {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            {skipReady && (
              <button
                type="button"
                onClick={() => {
                  fireTracking(dataRef.current?.tracking?.filter((item) => item.event === 'skip').map((item) => item.url));
                  safeComplete('skipped');
                }}
                className="px-3 py-2 rounded-md bg-black/70 border border-white/20 text-xs text-white font-semibold backdrop-blur-sm"
              >
                Skip Ad
              </button>
            )}
          </div>
        </div>
      )}

      {phase === 'error' && !completeRef.current && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center bg-black">
          <AlertCircle size={28} className="text-danger" />
          <p className="text-sm text-white font-medium">Advertisement unavailable</p>
          <p className="text-xs text-muted max-w-md">{message}</p>
        </div>
      )}
    </div>
  );
}
