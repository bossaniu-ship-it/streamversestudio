# StreamVerse — ClickAdilla repeat-play diagnostics

## What the player now distinguishes

The player records each VAST acquisition attempt and the deployed Next.js server writes structured lines prefixed with `[STREAMVERSE_AD]` to stdout. Render captures these lines in the service logs.

Useful events:

- `vast_proxy_request` — a browser request reached `/api/ads/vast`.
- `vast_upstream_response` — the upstream VAST server response, including HTTP status, content type, body classification, byte count, final host, and a sanitized preview.
- `client_ad_event` — browser/player lifecycle events forwarded to the deployed logging route.
- `clickadilla_preroll_no_fill` — the player received an explicit no-fill/empty/non-VAST result and intentionally allowed playback to continue.
- `clickadilla_preroll_vast_error` — a technical VAST error that was not classified as no-fill.

Each session has an `adSessionId`. Proxy requests additionally have a `requestId`, and `/api/ads/vast` returns it as `X-StreamVerse-Ad-Request-Id` so client and server logs can be correlated.

## ClickAdilla repeat views

ClickAdilla's current In-Stream documentation states that the `Uniques` checkbox prevents an ad from being shown once it has already been seen by the site visitor. Therefore, a first playback that receives a creative followed by later playbacks that receive no creative can be legitimate ad-server behavior when `Uniques` is enabled.

The player no longer presents a generic “invalid VAST response” for ordinary no-fill/non-VAST responses. It records the upstream response and treats those conditions as no-fill, allowing the movie authorization flow to continue.

## Important deployment check

After deployment, search Render logs for `[STREAMVERSE_AD]`. A healthy request sequence should show `vast_proxy_request` followed by `vast_upstream_response`. If the upstream response is `204`, empty, `no-fill`, HTML, JSON, or another non-VAST body on the second playback, the log will make that visible without exposing the full ad URL or ad tracking URLs.

If the second request is `200` with a real `<VAST ...>` response but the media cannot play, inspect the media-stage events next; that indicates a player/media problem rather than ClickAdilla no-fill.

## How to interpret the repeat-play case

If playback 1 shows `bodyClass=vast` and playback 2 shows `bodyClass=no-fill`, `html`, `json`, or `non-vast`, the second response came from the ad-serving path rather than the HTML5 media player. ClickAdilla explicitly documents its `Uniques` control as preventing another showing after the visitor has seen the ad.

If playback 2 shows repeated `fetch_error` entries with CORS/DNS/network messages for the direct request but a successful `vast_upstream_response` for the proxy request, the browser's cross-origin path is the problem and the proxy is doing its job.

If playback 2 shows the proxy receiving HTTP 200 with `bodyClass=vast` but the client later emits media-stage errors, the VAST itself is valid and the investigation should move to the selected media URL/CDN.
