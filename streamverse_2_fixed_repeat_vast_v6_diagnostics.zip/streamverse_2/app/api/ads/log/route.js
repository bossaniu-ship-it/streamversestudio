export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const BACKEND = process.env.BACKEND_URL || process.env.NEXT_PUBLIC_BACKEND_URL || '';

function sanitize(value) {
  if (value === null || value === undefined) return value;
  if (typeof value !== 'object') return String(value).slice(0, 1000);
  if (Array.isArray(value)) return value.slice(0, 20).map(sanitize);
  const out = {};
  for (const [key, val] of Object.entries(value).slice(0, 40)) {
    if (/url|token|cookie|authorization|password|secret|signature|vast/i.test(key)) continue;
    out[key] = sanitize(val);
  }
  return out;
}

function logServerAd(event, details = {}) {
  try {
    console.info(`[STREAMVERSE_AD] ${JSON.stringify({ event, ts: new Date().toISOString(), ...details })}`);
  } catch (_) {
    console.info(`[STREAMVERSE_AD] ${event}`);
  }
}

export async function POST(request) {
  let body = {};
  try {
    body = sanitize(await request.json());
  } catch {
    body = { event: 'invalid_payload' };
  }

  const requestId = request.headers.get('x-streamverse-ad-request-id') || body?.serverRequestId || body?.adSessionId || null;
  logServerAd('client_ad_event', {
    requestId,
    event: body?.event || 'unknown',
    details: body,
    origin: request.headers.get('origin') || null,
    refererPresent: Boolean(request.headers.get('referer')),
    userAgentPresent: Boolean(request.headers.get('user-agent')),
  });

  // Keep the browser-facing logging endpoint available even when the optional
  // backend ad-log route is not deployed. Do not expose ad URLs or secrets.
  if (BACKEND) {
    try {
      const response = await fetch(`${BACKEND.replace(/\/$/, '')}/api/ads/log`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        cache: 'no-store',
      });
      if (response.ok) {
        return new Response(null, { status: 204 });
      }
    } catch {}
  }

  return new Response(null, { status: 204 });
}

export async function OPTIONS() {
  return new Response(null, { status: 204 });
}
