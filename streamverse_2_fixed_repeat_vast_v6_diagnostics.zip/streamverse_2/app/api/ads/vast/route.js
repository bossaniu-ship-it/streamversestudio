import { NextResponse } from 'next/server';
import { randomUUID } from 'crypto';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED_HOSTS = new Set([
  'vast.yomeno.xyz',
  'clickadilla.com',
]);

function isAllowedHost(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/\.$/, '');
  if (ALLOWED_HOSTS.has(host)) return true;
  return host.endsWith('.clickadilla.com');
}

function absolutize(raw, base) {
  try { return new URL(String(raw || '').trim(), base).toString(); } catch { return ''; }
}

function sanitizePreview(body) {
  return String(body || '')
    .replace(/https?:\/\/[^\s<>"']+/gi, '[url]')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 500);
}

function classifyBody(body, contentType = '', status = 200) {
  const trimmed = String(body || '').trim();
  const type = String(contentType || '').toLowerCase();
  if (!trimmed || status === 204 || status === 404 || status === 410) return 'no-fill';
  if (/<VAST(?:\s|>)/i.test(trimmed)) return 'vast';
  if (/no (?:ad|fill|inventory)|no advertisement|no content|empty response|ad unavailable/i.test(trimmed)) return 'no-fill';
  if (type.includes('text/html')) return 'html';
  if (type.includes('application/json')) return 'json';
  return 'non-vast';
}

function logServerAd(event, details = {}) {
  try {
    console.info(`[STREAMVERSE_AD] ${JSON.stringify({ event, ts: new Date().toISOString(), ...details })}`);
  } catch (_) {
    console.info(`[STREAMVERSE_AD] ${event}`);
  }
}

function addUpstreamCachebuster(rawUrl, nonce = '') {
  try {
    const parsed = new URL(String(rawUrl || '').trim());
    const value = String(nonce || '').trim() || `${Date.now()}-${Math.floor(Math.random() * 1e9)}`;
    parsed.searchParams.set('sv_cb', value);
    return parsed.toString();
  } catch {
    return rawUrl;
  }
}

function rewriteVastUrls(body, baseUrl, requestOrigin) {
  let rewritten = body;

  rewritten = rewritten.replace(
    /(<VASTAdTagURI\b[^>]*>)([\s\S]*?)(<\/VASTAdTagURI>)/gi,
    (full, openTag, rawValue, closeTag) => {
      const value = String(rawValue || '')
        .replace(/^\s*<!\[CDATA\[/i, '')
        .replace(/\]\]>\s*$/i, '')
        .trim();
      const absolute = absolutize(value, baseUrl);
      if (!absolute || !/^https:/i.test(absolute) || !requestOrigin) return full;
      return `${openTag}<![CDATA[/api/ads/vast?url=${encodeURIComponent(absolute)}]]>${closeTag}`;
    },
  );

  // Browser playback is allowed to try the CDN directly first. The player also
  // has a server-proxy fallback for MP4 media when the CDN rejects browser fetches.
  return rewritten;
}

export async function GET(request) {
  try {
    const source = request.nextUrl.searchParams.get('url');
    if (!source) return NextResponse.json({ ok: false, error: 'Missing VAST url' }, { status: 400 });

    let upstream;
    try { upstream = new URL(source); }
    catch { return NextResponse.json({ ok: false, error: 'Invalid VAST url' }, { status: 400 }); }

    if (upstream.protocol !== 'https:' || !isAllowedHost(upstream.hostname)) {
      logServerAd('vast_proxy_rejected_host', { host: upstream.hostname });
      return NextResponse.json({ ok: false, error: 'VAST host is not allowed' }, { status: 403 });
    }

    const requestId = randomUUID();
    logServerAd('vast_proxy_request', {
      requestId,
      upstreamHost: upstream.hostname,
      upstreamPath: upstream.pathname,
      origin: request.headers.get('origin') || null,
      refererPresent: Boolean(request.headers.get('referer')),
      userAgentPresent: Boolean(request.headers.get('user-agent')),
    });

    const incomingHeaders = request.headers;
    const forwardHeaders = {
      Accept: 'application/xml,text/xml;q=0.9,*/*;q=0.8',
      'User-Agent': incomingHeaders.get('user-agent') || 'StreamVerse-Studio-VAST-Proxy/2.0',
    };
    for (const name of ['referer', 'origin', 'accept-language']) {
      const value = incomingHeaders.get(name);
      if (value) forwardHeaders[name] = value;
    }
    const forwardedFor = incomingHeaders.get('x-forwarded-for');
    if (forwardedFor) forwardHeaders['X-Forwarded-For'] = forwardedFor;

    const upstreamNonce = request.nextUrl.searchParams.get('sv_cb') || '';
    const upstreamUrl = addUpstreamCachebuster(upstream.toString(), upstreamNonce);

    const response = await fetch(upstreamUrl, {
      method: 'GET',
      headers: forwardHeaders,
      cache: 'no-store',
      redirect: 'follow',
    });

    const body = await response.text();
    const contentType = response.headers.get('content-type') || '';
    const bodyClass = classifyBody(body, contentType, response.status);

    logServerAd('vast_upstream_response', {
      requestId,
      upstreamHost: upstream.hostname,
      upstreamPath: upstream.pathname,
      status: response.status,
      contentType: contentType.split(';')[0],
      bodyClass,
      bytes: body.length,
      finalHost: (() => { try { return new URL(response.url || upstream.toString()).hostname; } catch { return upstream.hostname; } })(),
      preview: sanitizePreview(body),
    });

    if (!response.ok) {
      return new NextResponse(body || `VAST upstream returned ${response.status}`, {
        status: response.status,
        headers: {
          'Content-Type': response.headers.get('content-type') || 'text/plain; charset=utf-8',
          'Cache-Control': 'no-store',
          'Access-Control-Allow-Origin': '*',
          'X-StreamVerse-Ad-Request-Id': requestId,
        },
      });
    }

    const outputContentType = /xml/i.test(contentType)
      ? contentType
      : 'application/xml; charset=utf-8';

    const rewrittenBody = rewriteVastUrls(body, response.url || upstream.toString(), request.nextUrl.origin);

    return new NextResponse(rewrittenBody, {
      status: 200,
      headers: {
        'Content-Type': outputContentType,
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Access-Control-Allow-Origin': '*',
        'X-StreamVerse-VAST-Proxy': '3',
        'X-StreamVerse-Ad-Request-Id': requestId,
      },
    });
  } catch (error) {
    logServerAd('vast_proxy_error', { error: error?.message || 'VAST proxy failed' });
    return NextResponse.json(
      { ok: false, error: error?.message || 'VAST proxy failed' },
      { status: 502, headers: { 'Cache-Control': 'no-store' } },
    );
  }
}
