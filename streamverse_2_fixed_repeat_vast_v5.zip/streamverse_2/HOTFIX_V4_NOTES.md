# StreamVerse Studio v4 hotfix

- Fixed the production client crash caused by `safeComplete` referencing
  `clearMediaWatchdog` before the `const` binding was initialized.
  Production minification renamed that binding, producing the observed
  `Cannot access 'O' before initialization` exception.
- Removed the ref object's `.current` value from a React effect dependency.
- Added the missing `/api/ads/log` POST/OPTIONS route so client ad diagnostics
  no longer generate a 404 when the optional backend logging route is absent.
- Existing stream payloads, ad VAST configuration, fullscreen implementation,
  standalone-movie UI, and Anti-AdBlock loader are preserved.
