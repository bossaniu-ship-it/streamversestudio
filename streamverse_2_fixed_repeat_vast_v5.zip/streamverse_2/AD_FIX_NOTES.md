# StreamVerse Studio — Ad + Standalone Movie Handoff

## What was fixed

1. **Fullscreen control** — the movie player now synchronizes its state with the browser fullscreen events, handles request/exit failures, supports standard fullscreen plus WebKit fallbacks, and no longer flips the icon before the browser actually enters fullscreen.
2. **ClickAdilla VAST playback** — the frontend no longer depends on Fluid Player for the ad creative. It fetches VAST through the same-origin `/api/ads/vast` route, follows VAST wrappers through that route, selects a browser-compatible media file, and plays the creative with native HTML5 video.
3. **VAST wrapper/CORS path** — nested `VASTAdTagURI` values are rewritten back through the same-origin proxy so wrapper XML does not depend on browser cross-origin XHR. Native video playback is used for the returned creative, avoiding the Fluid Player media pre-check failure mode documented in its current issue tracker.
4. **Ad autoplay fallback** — ads start muted for autoplay compatibility. When a browser still rejects autoplay, a direct **Play Advertisement** control appears without turning the ad click target into a misleading play action.
5. **Ad failure handling** — a no-fill, malformed VAST, unsupported creative, or media error no longer leaves the movie permanently stuck at the ad gate; the existing authorization completion path is still called so the backend can decide whether playback may proceed.
6. **Mid-roll** — the movie timeline still triggers the configured `NEXT_PUBLIC_CLICKADILLA_MIDROLL_SECONDS` value, but the temporary Fluid Player implementation has been replaced by the same native VAST renderer.
7. **Standalone-movie UI** — visible Season/Episode/SxEx/Airing terminology was removed from the presentation. The library now presents **Movies**, **Collections**, **Latest release**, and **Standalone movies**. Internal backend keys, function names, IDs, routes, and payload fields remain unchanged for compatibility.

## Payload compatibility

The following application contracts were intentionally preserved:

- `episodeId` request fields and `/api/episodes/:id/stream` / `/api/episodes/:id/ad-complete` endpoints.
- `initStream(episodeId)` and `completeAd(episodeId, token)` behavior and returned `videoUrl`.
- History/search payload arrays such as `history`, `episodes`, and `shows`.
- Existing normalized fields including `episodeTitle`, `seasonNumber`, `episodeNumber`, `episode_count`, and `posted_episode_count`.
- Analytics/watch-progress fields such as `episodeId`, `positionSeconds`, `durationSeconds`, and `completed`.

These fields remain internal data contracts; they are not exposed as Season/Episode UI labels.

## ClickAdilla configuration

- `NEXT_PUBLIC_CLICKADILLA_VAST_TAG` — approved VAST tag URL.
- `NEXT_PUBLIC_CLICKADILLA_MIDROLL_SECONDS` — mid-roll trigger in seconds; the project default remains 60 seconds unless the environment overrides it.

The ClickAdilla account/campaign/tag still needs to be active and approved and must actually return a VAST video creative. ClickAdilla's current in-stream documentation describes VAST-based video inventory and notes that campaign/tag availability affects fill.

## Verification

- All JavaScript/JSX/TS/TSX source files were parsed successfully with the TypeScript parser.
- The VAST route passes `node --check`.
- Contract files `lib/api.js`, `lib/analytics.js`, `lib/catalog.js`, and `components/AuthContext.js` were diff-checked; no payload/schema changes were introduced.
- A complete production `next build` could not be executed in the sandbox because the npm dependency tree was not installed and the sandbox could not retrieve packages.
- The configured live VAST endpoint was also not directly reachable from the sandbox, so live ad fill was not falsely claimed as verified.


## Second-pass ad rendering hardening

- A technical VAST fetch/media failure no longer calls the movie `ad-complete` endpoint. Only a real ad completion/skip, or an explicit no-fill response, advances the pre-roll gate.
- Pre-roll VAST parsing now searches the returned ad set for a linear video creative, follows wrapper chains up to eight levels, filters JavaScript/VPAID media from native playback, ranks compatible MP4 sources, and tries alternate creatives when a source errors or stalls.
- When direct browser media playback fails, the player retries the ad through `/api/ads/media`, a Range-aware same-origin streaming proxy. This is specifically designed to handle ad CDNs that reject browser-origin requests while preserving byte ranges for video playback.
- VAST requests forward the browser `Referer`, `Origin`, `User-Agent`, `Accept-Language`, and available forwarding IP metadata to the ad server so targeting/referrer-dependent tags have the browser context that the previous server fetch discarded.
- Pre-roll technical errors remain visible with a retry action instead of silently passing to the movie. Mid-roll technical errors dismiss the failed ad and resume the movie so the main playback timeline cannot deadlock.
- The supplied Anti-AdBlock manager is loaded before the application via `next/script` using `data-cfasync="false"`, `data-admpid="453694"`, and the `https://js.wpadmngr.com/static/adManager.js` endpoint used by the supplied loader.

ClickAdilla's current public in-stream requirements specify MPEG-4 / H.264 / AAC video for VAST in-stream creatives and note that VPAID requires additional approval; its in-stream docs also describe the VAST-tag URL as the input for wrapper-with-video campaigns.


### v3 hotfix — `getAttribute` regression
- Fixed the exact `e.getAttribute('type') is undefined` crash caused by passing already-normalized `MediaFile` objects back through the XML-node normalizer during ranking.
- `rankMediaFiles()` now consumes the normalized media objects directly; attribute reads are defensive for XML nodes and plain objects.
- Added the supplied ClickAdilla Anti-AdBlock loader at `public/clickadilla-anti-adblock.js` and load it from `<head>` with `data-cfasync="false"`, `data-admpid="453694"`, and `beforeInteractive`.
- Normal ad completion no longer emits VAST `Error` trackers.

### v5 repeat-play VAST fix
- Every VAST request now receives a fresh `sv_cb` cachebuster generated per attempt.
- The `/api/ads/vast` proxy preserves that cachebuster and appends it to the actual upstream VAST URL instead of stripping it at the proxy boundary.
- VAST acquisition now prefers a browser-direct CORS request so the ad server can observe the actual viewer request context; the same-origin proxy remains the fallback for VAST endpoints that do not expose CORS.
- Each VAST request gets up to three fresh attempts before the player reports a technical VAST failure.
- Existing wrapper traversal, media failover, Range-aware media proxy, payload contracts, and standalone-movie UI are preserved.
- ClickAdilla's documented `Uniques` setting can intentionally prevent an ad from being shown again to a visitor after it has already been seen; that campaign/account setting must be disabled when one ad impression is required on every playback.
