'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader2, Play } from 'lucide-react';
import ClickadillaVastAd from '@/components/ClickadillaVastAd';
import { completeAd, initStream, logAdEvent } from '@/lib/api';

const RAW_CLICKADILLA_VAST_TAG = process.env.NEXT_PUBLIC_CLICKADILLA_VAST_TAG || '';
const CLICKADILLA_VAST_TAG = RAW_CLICKADILLA_VAST_TAG;

export default function ClickadillaVastGate({ episode, onVideoReady }) {
  const [phase, setPhase] = useState('loading');
  const [message, setMessage] = useState('Preparing advertisement…');
  const [adAttempt, setAdAttempt] = useState(0);
  const tokenRef = useRef(null);
  const completedRef = useRef(false);
  const mountedRef = useRef(false);

  const episodeId = String(episode?.id || '');

  const finishGate = useCallback(async (reason) => {
    if (completedRef.current || !episodeId) return;
    completedRef.current = true;

    const token = tokenRef.current;
    if (!token) {
      completedRef.current = false;
      if (mountedRef.current) {
        setPhase('error');
        setMessage('Playback authorization is unavailable. Please try again.');
      }
      return;
    }

    try {
      logAdEvent('clickadilla_preroll_complete', { episodeId, reason });
      const result = await completeAd(episodeId, token);
      if (!result?.videoUrl) throw new Error('Backend did not return a video URL');
      onVideoReady(result.videoUrl);
    } catch (error) {
      completedRef.current = false;
      logAdEvent('clickadilla_preroll_complete_error', {
        episodeId,
        error: error?.message || 'Authorization failed',
      });
      if (mountedRef.current) {
        setPhase('error');
        setMessage(error?.message || 'Could not authorize the movie.');
      }
    }
  }, [episodeId, onVideoReady]);

  const handleAdError = useCallback((error) => {
    const detail = String(error?.message || error || 'The advertisement could not be rendered.');
    logAdEvent('clickadilla_preroll_render_error', { episodeId, error: detail });
    setPhase('error');
    setMessage(detail);
  }, [episodeId]);

  const retryAd = useCallback(() => {
    completedRef.current = false;
    setMessage('Preparing advertisement…');
    setPhase('player');
    setAdAttempt((value) => value + 1);
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    let cancelled = false;

    async function boot() {
      try {
        if (!episodeId) throw new Error('Missing movie ID.');
        if (!RAW_CLICKADILLA_VAST_TAG) {
          throw new Error('ClickAdilla VAST zone is not configured.');
        }

        const stream = await initStream(episodeId);
        if (cancelled) return;

        tokenRef.current = stream?.token || null;

        if (!stream?.adRequired) {
          await finishGate('not-required');
          return;
        }

        logAdEvent('clickadilla_preroll_request', {
          episodeId,
          transport: 'native-vast',
        });
        setPhase('player');
        setMessage('Advertisement');
      } catch (error) {
        if (cancelled) return;
        logAdEvent('clickadilla_preroll_player_load_error', {
          episodeId,
          error: error?.message || 'VAST load failed',
        });
        // An unavailable ad must never brick playback.
        void finishGate('gate-error');
      }
    }

    boot();
    return () => {
      cancelled = true;
      mountedRef.current = false;
    };
  }, [episodeId, finishGate]);

  if (phase === 'player' && CLICKADILLA_VAST_TAG) {
    return (
      <ClickadillaVastAd
        key={adAttempt}
        vastUrl={CLICKADILLA_VAST_TAG}
        onComplete={(reason) => {
          logAdEvent(`clickadilla_preroll_${reason}`, { episodeId });
          void finishGate(reason);
        }}
        onError={handleAdError}
        label="Advertisement"
      />
    );
  }

  return (
    <div className="ad-overlay flex flex-col items-center justify-center gap-4 p-8 text-center">
      {phase === 'loading' && <Loader2 size={30} className="animate-spin text-violet" />}
      {phase === 'error' && <AlertCircle size={30} className="text-danger" />}
      {phase === 'player' && <Play size={28} className="text-violet-light" />}
      <p className="text-sm text-white font-medium">{message}</p>
      {phase === 'error' && (
        <button
          type="button"
          onClick={() => {
            completedRef.current = false;
            retryAd();
          }}
          className="px-5 py-2.5 rounded-full bg-violet text-white font-semibold shadow-lg"
        >
          Try Again
        </button>
      )}
    </div>
  );
}
