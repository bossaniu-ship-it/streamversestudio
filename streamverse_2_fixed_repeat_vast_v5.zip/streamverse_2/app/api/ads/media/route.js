import { NextResponse } from 'next/server';

function isBlockedHost(hostname) {
  const host = String(hostname || '').toLowerCase().replace(/\.$/, '');
  if (!host || host === 'localhost' || host === 'ip6-localhost') return true;
  if (host.endsWith('.localhost') || host.endsWith('.local')) return true;
  if (/^(127\.|10\.|192\.168\.|169\.254\.)/.test(host)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) return true;
  if (host === '::1' || host.startsWith('fc') || host.startsWith('fd')) return true;
  return false;
}

function allowedUrl(raw) {
  try {
    const u = new URL(String(raw || '').trim());
    if (u.protocol !== 'https:') return null;
    if (isBlockedHost(u.hostname)) return null;
    return u;
  } catch {
    return null;
  }
}

export async function GET(request) {
  try {
    const source = request.nextUrl.searchParams.get('url');
    const upstream = allowedUrl(source);
    if (!upstream) return NextResponse.json({ ok: false, error: 'Invalid ad media URL' }, { status: 400 });

    const headers = {
      'User-Agent': request.headers.get('user-agent') || 'StreamVerse-Studio-Ad-Media-Proxy/1.0',
      Accept: request.headers.get('accept') || 'video/mp4,video/*;q=0.9,*/*;q=0.5',
    };
    for (const name of ['range', 'referer', 'accept-language']) {
      const value = request.headers.get(name);
      if (value) headers[name] = value;
    }

    const response = await fetch(upstream.toString(), {
      method: 'GET',
      headers,
      cache: 'no-store',
      redirect: 'follow',
    });

    if (!response.ok && response.status !== 206) {
      return new NextResponse(`Ad media upstream returned ${response.status}`, {
        status: response.status,
        headers: { 'Cache-Control': 'no-store' },
      });
    }

    const outputHeaders = new Headers();
    const pass = [
      'content-type', 'content-length', 'content-range', 'accept-ranges',
      'etag', 'last-modified', 'cache-control',
    ];
    for (const name of pass) {
      const value = response.headers.get(name);
      if (value) outputHeaders.set(name, value);
    }
    if (!outputHeaders.has('content-type')) outputHeaders.set('content-type', 'video/mp4');
    outputHeaders.set('Cache-Control', 'no-store');
    outputHeaders.set('Access-Control-Allow-Origin', '*');
    outputHeaders.set('Cross-Origin-Resource-Policy', 'cross-origin');

    return new NextResponse(response.body, {
      status: response.status,
      headers: outputHeaders,
    });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error?.message || 'Ad media proxy failed' },
      { status: 502, headers: { 'Cache-Control': 'no-store' } },
    );
  }
}
