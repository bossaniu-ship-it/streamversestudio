'use client';

import { useEffect } from 'react';
import { logAdEvent } from '@/lib/api';

const SCRIPT_URL = process.env.NEXT_PUBLIC_EXOCLICK_VIDEO_SLIDER_SCRIPT_URL || '';
const ZONE_ID = process.env.NEXT_PUBLIC_EXOCLICK_VIDEO_SLIDER_ZONE_ID || '';
const TAGS = process.env.NEXT_PUBLIC_EXOCLICK_VIDEO_SLIDER_TAGS || '';
const FREQUENCY_PERIOD = Number(process.env.NEXT_PUBLIC_EXOCLICK_VIDEO_SLIDER_FREQUENCY || 15);

export default function ExoclickVideoSlider() {
  useEffect(() => {
    if (!SCRIPT_URL || !ZONE_ID || typeof window === 'undefined') {
      return undefined;
    }

    let disposed = false;
    let script = document.querySelector(`script[data-streamverse-exoclick-slider="${ZONE_ID}"]`);

    const init = () => {
      if (disposed || !window.ExoVideoSlider?.init) return;
      try {
        window.ExoVideoSlider.init({
          idzone: Number(ZONE_ID),
          frequency_period: Number.isFinite(FREQUENCY_PERIOD) ? FREQUENCY_PERIOD : 15,
          close_after: 0,
          sound_enabled: 0,
          on_complete: 'repeat',
          branding_enabled: 1,
          ...(TAGS ? { tags: TAGS } : {}),
        });
        logAdEvent('exoclick_slider_init', { zoneId: ZONE_ID });
      } catch (error) {
        logAdEvent('exoclick_slider_error', { zoneId: ZONE_ID, error: error?.message || String(error) });
      }
    };

    if (!script) {
      script = document.createElement('script');
      script.src = SCRIPT_URL;
      script.async = true;
      script.dataset.streamverseExoclickSlider = ZONE_ID;
      script.addEventListener('load', init, { once: true });
      script.addEventListener('error', () => logAdEvent('exoclick_slider_script_error', { zoneId: ZONE_ID } ), { once: true });
      document.body.appendChild(script);
    } else {
      init();
    }

    return () => { disposed = true; };
  }, []);

  return null;
}
