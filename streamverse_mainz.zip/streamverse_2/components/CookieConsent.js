'use client';

import { useEffect, useState } from 'react';
import { BarChart3, Check, X } from 'lucide-react';
import { acceptAnalyticsConsent, getConsentState, rejectAnalyticsConsent, trackAnalyticsEvent } from '@/lib/analytics';

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => { setVisible(!getConsentState()); }, []);
  if (!visible) return null;

  const accept = () => {
    acceptAnalyticsConsent();
    setVisible(false);
    trackAnalyticsEvent('consent', { metadata: { analytics: true } });
  };

  const reject = () => {
    rejectAnalyticsConsent();
    setVisible(false);
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 z-[90] mx-auto max-w-4xl glass-strong border border-white/10 rounded-2xl p-4 sm:p-5 shadow-2xl">
      <div className="flex flex-col sm:flex-row gap-4 sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-violet/15 border border-violet/25 flex items-center justify-center shrink-0">
            <BarChart3 size={18} className="text-violet-light" />
          </div>
          <div>
            <p className="text-sm font-semibold text-white">Help us improve StreamVerse</p>
            <p className="text-xs text-muted leading-relaxed mt-1 max-w-2xl">
              With analytics enabled, we record anonymous visit activity such as pages viewed, viewing time, videos watched, device information and approximate geography. You can decline and still use the site.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 sm:shrink-0">
          <button onClick={reject} className="px-3.5 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-muted hover:text-white transition-colors flex items-center gap-1.5">
            <X size={13} /> Decline
          </button>
          <button onClick={accept} className="px-3.5 py-2 rounded-lg bg-gradient-to-r from-violet to-violet-dark text-xs text-white font-semibold shadow-glow-violet flex items-center gap-1.5">
            <Check size={13} /> Accept Analytics
          </button>
        </div>
      </div>
    </div>
  );
}
