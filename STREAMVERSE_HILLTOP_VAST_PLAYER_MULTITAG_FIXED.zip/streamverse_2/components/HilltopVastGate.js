'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader2, Play, Volume2, VolumeX } from 'lucide-react';
import { completeAd, initStream, logAdEvent } from '@/lib/api';

const HILLTOP_VAST_URL = process.env.NEXT_PUBLIC_HILLTOPADS_VAST_URL || '';
const VAST_CLIENT_URL = 'https://esm.unpkg.com/@dailymotion/vast-client@6.4.5?bundle';

function pickLinear(parsed) {
  for (const ad of parsed?.ads || []) {
    const creatives = Array.isArray(ad?.creatives) ? ad.creatives : [];
    for (const creative of creatives) {
      if (creative?.type !== 'LINEAR' && !creative?.mediaFiles) continue;
      const files = Array.isArray(creative.mediaFiles) ? creative.mediaFiles : [];
      const video = document.createElement('video');
      const playable = files.find((file) => {
        const type = String(file?.mimeType || file?.type || '').toLowerCase();
        return file?.fileURL && (!type || video.canPlayType(type));
      }) || files.find((file) => file?.fileURL);
      if (playable?.fileURL) return { ad, creative, mediaFile: playable };
    }
  }
  return null;
}

export default function HilltopVastGate({ episode, onVideoReady }) {
  const [phase, setPhase] = useState('loading');
  const [message, setMessage] = useState('Preparing advertisement…');
  const [adMeta, setAdMeta] = useState(null);
  const [muted, setMuted] = useState(true);
  const [skipIn, setSkipIn] = useState(null);
  const [playBlocked, setPlayBlocked] = useState(false);
  const videoRef = useRef(null);
  const trackerRef = useRef(null);
  const tokenRef = useRef(null);
  const completedRef = useRef(false);
  const startedRef = useRef(false);

  const finishGate = useCallback(async (reason) => {
    if (completedRef.current) return;
    completedRef.current = true;
    const token = tokenRef.current;
    if (!token) {
      setPhase('error');
      setMessage('Playback authorization is unavailable. Please try again.');
      return;
    }
    try {
      logAdEvent('vast_gate_complete', { episodeId: String(episode?.id || ''), reason });
      const result = await completeAd(String(episode.id), token);
      if (!result?.videoUrl) throw new Error('Backend did not return a video URL');
      onVideoReady(result.videoUrl);
    } catch (error) {
      completedRef.current = false;
      logAdEvent('vast_gate_complete_error', { episodeId: String(episode?.id || ''), error: error?.message || 'Authorization failed' });
      setPhase('error');
      setMessage(error?.message || 'Could not authorize the episode.');
    }
  }, [episode?.id, onVideoReady]);

  useEffect(() => {
    let cancelled = false;
    async function boot() {
      try {
        if (!HILLTOP_VAST_URL) throw new Error('Hilltop VAST zone is not configured.');
        const stream = await initStream(String(episode?.id || ''));
        if (cancelled) return;
        tokenRef.current = stream?.token || null;
        if (!stream?.adRequired) {
          await finishGate('not-required');
          return;
        }
        logAdEvent('vast_player_request', { episodeId: String(episode.id), transport: 'browser-player' });
        const mod = await Function('url', 'return import(url)')(VAST_CLIENT_URL);
        if (cancelled) return;
        const VASTClient = mod?.VASTClient || mod?.default?.VASTClient;
        const VASTTracker = mod?.VASTTracker || mod?.default?.VASTTracker;
        if (!VASTClient || !VASTTracker) throw new Error('VAST client library failed to load.');
        const client = new VASTClient();
        const parsed = await client.get(HILLTOP_VAST_URL, { allowMultipleAds: true, resolveAll: true });
        if (cancelled) return;
        const candidate = pickLinear(parsed);
        if (!candidate) {
          if (!(parsed?.ads?.length)) {
            logAdEvent('vast_player_no_fill', { episodeId: String(episode.id), transport: 'browser-player', ads: 0 });
            await finishGate('no-fill');
            return;
          }
          throw new Error('Hilltop returned an ad response without a playable linear creative.');
        }
        const tracker = new VASTTracker(client, candidate.ad, candidate.creative, null, true);
        trackerRef.current = tracker;
        tracker.on?.('creativeView', () => logAdEvent('vast_tracking', { episodeId: String(episode.id), eventName: 'creativeView' }));
        tracker.on?.('start', () => logAdEvent('vast_tracking', { episodeId: String(episode.id), eventName: 'start' }));
        tracker.on?.('error', (e) => logAdEvent('vast_tracker_error', { episodeId: String(episode.id), error: e?.message || String(e || '') }));
        const skipDelay = candidate.creative?.skipDelay;
        setAdMeta({
          client,
          ad: candidate.ad,
          creative: candidate.creative,
          tracker,
          src: candidate.mediaFile.fileURL,
          mime: candidate.mediaFile.mimeType || candidate.mediaFile.type || '',
          skipDelay: Number.isFinite(Number(skipDelay)) ? Number(skipDelay) : null,
        });
        setPhase('ad');
        setMessage('Advertisement');
        logAdEvent('vast_player_loaded', {
          episodeId: String(episode.id),
          transport: 'browser-player',
          mimeType: candidate.mediaFile.mimeType || candidate.mediaFile.type || null,
          skipDelay: Number.isFinite(Number(skipDelay)) ? Number(skipDelay) : null,
        });
      } catch (error) {
        if (cancelled) return;
        logAdEvent('vast_player_load_error', { episodeId: String(episode?.id || ''), error: error?.message || 'VAST load failed' });
        setPhase('error');
        setMessage(error?.message || 'Could not load the advertisement.');
      }
    }
    boot();
    return () => { cancelled = true; };
  }, [episode?.id, finishGate]);

  const startAd = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.play().then(() => setPlayBlocked(false)).catch((error) => {
      setPlayBlocked(true);
      logAdEvent('vast_autoplay_blocked', { episodeId: String(episode?.id || ''), error: error?.message || 'play() rejected' });
    });
  }, [episode?.id]);

  const onPlay = useCallback(() => {
    if (!startedRef.current) {
      startedRef.current = true;
      logAdEvent('vast_player_ad_start', { episodeId: String(episode?.id || ''), mediaType: adMeta?.mime || null });
      try { trackerRef.current?.trackImpression(); } catch (e) { logAdEvent('vast_tracking_error', { episodeId: String(episode?.id || ''), eventName: 'impression', error: e?.message || String(e) }); }
    }
    try { trackerRef.current?.setPaused(false); } catch (_) {}
  }, [adMeta?.mime, episode?.id]);

  const onPause = useCallback(() => {
    if (!completedRef.current) {
      try { trackerRef.current?.setPaused(true); } catch (_) {}
    }
  }, []);

  const onTimeUpdate = useCallback(() => {
    const video = videoRef.current;
    const tracker = trackerRef.current;
    if (!video || !tracker || !Number.isFinite(video.currentTime)) return;
    try { tracker.setProgress(video.currentTime); } catch (error) {
      logAdEvent('vast_tracking_error', { episodeId: String(episode?.id || ''), eventName: 'progress', error: error?.message || String(error) });
    }
    if (adMeta?.skipDelay != null) setSkipIn(Math.max(0, Math.ceil(adMeta.skipDelay - video.currentTime)));
  }, [adMeta?.skipDelay, episode?.id]);

  const onEnded = useCallback(() => {
    try { trackerRef.current?.complete(); } catch (error) { logAdEvent('vast_tracking_error', { episodeId: String(episode?.id || ''), eventName: 'complete', error: error?.message || String(error) }); }
    logAdEvent('vast_player_ad_complete', { episodeId: String(episode?.id || '') });
    finishGate('complete');
  }, [episode?.id, finishGate]);

  const onSkip = useCallback(() => {
    try { trackerRef.current?.skip(); } catch (error) { logAdEvent('vast_tracking_error', { episodeId: String(episode?.id || ''), eventName: 'skip', error: error?.message || String(error) }); }
    logAdEvent('vast_player_ad_skip', { episodeId: String(episode?.id || '') });
    finishGate('skip');
  }, [episode?.id, finishGate]);

  if (phase === 'loading') return <div className="ad-overlay flex flex-col items-center justify-center gap-3 p-6 text-center"><Loader2 size={32} className="animate-spin text-violet" /><p className="text-sm text-muted">{message}</p></div>;
  if (phase === 'error') return <div className="ad-overlay flex flex-col items-center justify-center gap-3 p-6 text-center"><AlertCircle size={32} className="text-danger" /><p className="text-sm text-white font-medium">Advertisement could not load</p><p className="text-xs text-muted max-w-md">{message}</p></div>;

  return (
    <div className="ad-overlay relative flex items-center justify-center bg-black overflow-hidden">
      <video
        ref={videoRef}
        src={adMeta.src}
        className="w-full h-full object-contain"
        playsInline
        muted={muted}
        autoPlay
        preload="auto"
        onPlay={onPlay}
        onPause={onPause}
        onTimeUpdate={onTimeUpdate}
        onEnded={onEnded}
        onCanPlay={startAd}
        onError={() => {
          logAdEvent('vast_player_error', { episodeId: String(episode?.id || ''), error: 'Advertisement media failed' });
          setPhase('error');
          setMessage('The advertisement media could not be played.');
        }}
      />
      <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-black/60 text-[10px] font-semibold tracking-widest uppercase text-white/80">Advertisement</div>
      <div className="absolute bottom-3 left-3 flex items-center gap-2">
        <button type="button" onClick={() => { const v=videoRef.current; if(!v) return; v.muted=!v.muted; setMuted(v.muted); try{trackerRef.current?.setMuted(v.muted);}catch(_){ } }} className="px-3 py-1.5 rounded-full bg-black/60 border border-white/10 text-xs text-white/80 hover:text-white" aria-label={muted ? 'Unmute advertisement' : 'Mute advertisement'}>{muted ? <VolumeX size={14}/> : <Volume2 size={14}/>}</button>
      </div>
      <div className="absolute bottom-3 right-3 flex items-center gap-2">
        {adMeta.skipDelay != null && skipIn === 0 ? <button type="button" onClick={onSkip} className="px-4 py-2 rounded-full bg-violet text-white text-xs font-semibold">Skip Ad →</button> : adMeta.skipDelay != null ? <div className="px-3 py-1.5 rounded-full bg-black/60 border border-white/10 text-xs text-white/70">Skip in {skipIn ?? Math.ceil(adMeta.skipDelay)}s</div> : <div className="px-3 py-1.5 rounded-full bg-black/60 border border-white/10 text-xs text-white/70">Advertisement</div>}
      </div>
      {playBlocked && <button type="button" onClick={startAd} className="absolute inset-0 m-auto w-fit h-fit px-5 py-3 rounded-full bg-violet text-white font-semibold flex items-center gap-2"><Play size={18} fill="currentColor"/>Play Advertisement</button>}
    </div>
  );
}
