import './globals.css';
import Image from 'next/image';
import Script from 'next/script';
import Header from '@/components/Header';
import { AuthProvider } from '@/components/AuthContext';
import AnalyticsTracker from '@/components/AnalyticsTracker';
import CookieConsent from '@/components/CookieConsent';
import SocialLinks from '@/components/SocialLinks';
import logo from '@/components/Logo/logo-icon.png';

export const metadata = {
  title: 'StreamVerse Studio — Watch Free Original Series',
  description: 'StreamVerse Studio: cinematic drama, sci-fi, thriller and rom-com short-form series. New episodes daily. Watch free with ads.',
  keywords: 'StreamVerse, original series, short-form video, drama, sci-fi, thriller, romcom, streaming',
  openGraph: {
    title: 'StreamVerse Studio',
    description: 'Cinematic original series. Watch free.',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="dark">
      <head>
        <meta name="theme-color" content="#030307" />
        <link rel="stylesheet" href="https://cdn.fluidplayer.com/v3/current/fluidplayer.min.css" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen antialiased">
        {/* Cosmic background */}
        <div className="stars-bg" aria-hidden="true" />

        <AuthProvider>
          <AnalyticsTracker />
          <CookieConsent />
          {/* Header */}
          <Header />

          {/* Main content */}
          <main className="relative z-10 pt-16">
            {children}
          </main>

          {/* Footer */}
          <footer className="relative z-10 border-t border-white/5 mt-20 py-10 px-6">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="relative w-6 h-6 rounded-md overflow-hidden flex-shrink-0">
                  <Image src={logo} alt="" fill sizes="24px" className="object-cover scale-125" />
                </div>
                <span className="font-display font-bold text-white">
                  Stream<span className="gradient-text">Verse</span>
                </span>
                <span className="text-muted text-xs">Studio</span>
              </div>
              <div className="flex flex-col items-center sm:items-end gap-2">
                <p className="text-xs text-muted text-center">
                  Cinematic original series. Free to watch, powered by ads.
                </p>
                <nav className="flex items-center gap-4 text-xs">
                  <a href="/terms" className="text-muted hover:text-white transition-colors">Terms</a>
                  <a href="/privacy" className="text-muted hover:text-white transition-colors">Privacy</a>
                  <a href="/contact" className="text-muted hover:text-white transition-colors">Contact</a>
                </nav>
              </div>
              <div className="flex flex-col items-center gap-2">
                <SocialLinks />
                <p className="text-xs text-muted">© 2026 StreamVerse Studio</p>
              </div>
            </div>
          </footer>

          <Script id="fluid-player-core" src="https://cdn.fluidplayer.com/v3/current/fluidplayer.min.js" strategy="beforeInteractive" />
        </AuthProvider>
      </body>
    </html>
  );
}
