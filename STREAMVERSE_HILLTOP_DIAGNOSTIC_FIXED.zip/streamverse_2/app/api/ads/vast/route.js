import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

function normalizeUrl(value) {
  try {
    return new URL(String(value || '').trim());
  } catch {
    return null;
  }
}

export async function GET(request) {
  try {
    const target = normalizeUrl(request.nextUrl.searchParams.get('url'));
    const configured = normalizeUrl(process.env.NEXT_PUBLIC_HILLTOPADS_VAST_URL);

    if (!target || !configured) {
      return NextResponse.json({ ok: false, error: 'VAST ad zone is not configured' }, { status: 503 });
    }

    // Never turn this into a general-purpose proxy. The only upstream that the
    // frontend fallback may fetch is the exact Hilltop VAST zone configured for
    // this deployment.
    if (target.origin !== configured.origin || target.pathname !== configured.pathname) {
      console.warn('[HilltopAd] rejected VAST target', { host: target.host, path: target.pathname });
      return NextResponse.json({ ok: false, error: 'Invalid VAST target' }, { status: 400 });
    }

    console.info('[HilltopAd] Render VAST proxy request', { host: target.host, path: target.pathname });
    const res = await fetch(target.toString(), {
      cache: 'no-store',
      headers: {
        Accept: 'application/xml,text/xml;q=0.9,*/*;q=0.8',
        Referer: process.env.NEXT_PUBLIC_SITE_URL || request.nextUrl.origin,
      },
    });

    const body = await res.text();
    const emptyVast = /<VAST\b[^>]*\/\s*>/i.test(body.trim());
    const adCount = (body.match(/<Ad\b/gi) || []).length;
    const mediaCount = (body.match(/<MediaFile\b/gi) || []).length;
    console.info('[HilltopAd] Render VAST proxy response', { status: res.status, contentType: res.headers.get('content-type') || '', bytes: body.length, emptyVast, adCount, mediaCount });
    return new NextResponse(body, {
      status: res.status,
      headers: {
        'Content-Type': res.headers.get('content-type') || 'application/xml; charset=utf-8',
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0',
        Pragma: 'no-cache',
      },
    });
  } catch (error) {
    console.error('[HilltopAd] Render VAST proxy error:', error?.message || error);
    return NextResponse.json({ ok: false, error: error?.message || 'Unable to load VAST' }, { status: 502 });
  }
}
