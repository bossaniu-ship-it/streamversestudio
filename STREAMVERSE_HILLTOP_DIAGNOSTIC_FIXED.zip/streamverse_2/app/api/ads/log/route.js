import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const MAX_EVENT = 80;
const MAX_EPISODE = 120;
const ALLOWED_EVENTS = new Set([
  'stream_init_request', 'stream_init_result', 'stream_init_error',
  'vast_request', 'vast_response', 'vast_direct_error', 'vast_no_fill',
  'vast_wrapper', 'vast_wrapper_error', 'vast_parse_error', 'vast_creative_error',
  'vast_parsed', 'vast_play', 'vast_error', 'vast_tracking', 'vast_tracking_error',
  'ad_gate_error', 'ad_skip', 'ad_complete_request', 'ad_complete_result', 'ad_complete_error',
]);

function clean(value, max = 300) {
  return String(value ?? '').replace(/[\r\n]+/g, ' ').slice(0, max);
}

export async function POST(request) {
  try {
    const body = await request.json().catch(() => ({}));
    const event = clean(body?.event, MAX_EVENT);
    if (!ALLOWED_EVENTS.has(event)) {
      return NextResponse.json({ ok: false, error: 'Unsupported event' }, { status: 400 });
    }

    const safe = {
      source: 'streamverse-render',
      event,
      ts: clean(body?.ts, 40),
      episodeId: clean(body?.episodeId, MAX_EPISODE),
      transport: clean(body?.transport, 30),
      host: clean(body?.host, 180),
      path: clean(body?.path, 300),
      status: Number.isFinite(Number(body?.status)) ? Number(body.status) : undefined,
      ok: typeof body?.ok === 'boolean' ? body.ok : undefined,
      adRequired: typeof body?.adRequired === 'boolean' ? body.adRequired : undefined,
      adProvider: clean(body?.adProvider, 80) || undefined,
      contentType: clean(body?.contentType, 100) || undefined,
      bytes: Number.isFinite(Number(body?.bytes)) ? Number(body.bytes) : undefined,
      emptyVast: typeof body?.emptyVast === 'boolean' ? body.emptyVast : undefined,
      ads: Number.isFinite(Number(body?.ads)) ? Number(body.ads) : undefined,
      wrappers: Number.isFinite(Number(body?.wrappers)) ? Number(body.wrappers) : undefined,
      linearCreatives: Number.isFinite(Number(body?.linearCreatives)) ? Number(body.linearCreatives) : undefined,
      mediaFiles: Number.isFinite(Number(body?.mediaFiles)) ? Number(body.mediaFiles) : undefined,
      selectedType: clean(body?.selectedType, 80) || undefined,
      selectedDelivery: clean(body?.selectedDelivery, 40) || undefined,
      impressions: Number.isFinite(Number(body?.impressions)) ? Number(body.impressions) : undefined,
      trackingEvents: Array.isArray(body?.trackingEvents) ? body.trackingEvents.map(x => clean(x, 40)).slice(0, 30) : undefined,
      skipOffset: body?.skipOffset && typeof body.skipOffset === 'object' ? body.skipOffset : undefined,
      hasClickThrough: typeof body?.hasClickThrough === 'boolean' ? body.hasClickThrough : undefined,
      error: clean(body?.error, 300) || undefined,
      message: clean(body?.message, 300) || undefined,
    };

    Object.keys(safe).forEach((key) => safe[key] === undefined && delete safe[key]);
    console.info('[HilltopAd]', JSON.stringify(safe));
    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error('[HilltopAd] log endpoint error:', error?.message || error);
    return new NextResponse(null, { status: 204 });
  }
}
