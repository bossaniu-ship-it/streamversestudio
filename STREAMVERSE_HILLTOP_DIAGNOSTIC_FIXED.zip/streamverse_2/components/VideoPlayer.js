'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Play, Pause, Volume2, VolumeX, Maximize2, Minimize2,
  RotateCcw, AlertCircle, Loader2
} from 'lucide-react';
import { initStream, completeAd, fetchVast, fireTracking, logAdEvent } from '@/lib/api';
import { useAuth } from '@/components/AuthContext';
import { saveWatchProgress, trackAnalyticsEvent } from '@/lib/analytics';
import PlaybackProtection from '@/components/PlaybackProtection';

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || '';
const HILLTOP_VAST_URL = process.env.NEXT_PUBLIC_HILLTOPADS_VAST_URL || '';

// ── VAST pre-roll + ad-gated stream init ────────────────────────────────────
function AdGate({ episode, onVideoReady }) {
  // loading | ad | skipReady | completing | error
  const [phase, setPhase]     = useState('loading');
  const [error, setError]     = useState(null);
  const [ad, setAd]           = useState(null);   // { mediaFileUrl, skipOffset, trackingEvents, impressions }
  const tokenRef           = useRef(null);
  const [skipIn, setSkipIn]   = useState(null);

  const adVideoRef   = useRef(null);
  const firedRef      = useRef(new Set()); // dedupe tracking pings
  const [adMuted, setAdMuted] = useState(true);

  const fire = useCallback((event) => {
    if (!ad || firedRef.current.has(event)) return;
    firedRef.current.add(event);
    fireTracking(ad.trackingEvents?.[event]);
  }, [ad]);

  const finishAd = useCallback((adToken) => {
    if (!adToken) return;
    setPhase('completing');
    completeAd(String(episode.id), adToken)
      .then(data => onVideoReady(data.videoUrl))
      .catch(err => {
        setError(err.message);
        setPhase('error');
      });
  }, [episode?.id, onVideoReady]);

  // A real ad failure must never unlock protected episode video. A valid
  // no-fill response is handled separately in loadStream because there was
  // no ad available to watch. Only natural completion or an allowed skip
  // reaches completeAd().
  const handleAdFailure = useCallback((message) => {
    console.warn('[StreamVerse] Hilltop ad gate failed:', message);
    logAdEvent('ad_gate_error', { episodeId: String(episode?.id ?? ''), error: message || 'Ad could not load' });
    setError(message || 'Ad could not load');
    setPhase('error');
  }, []);

  const loadStream = useCallback(() => {
    const episodeId = String(episode?.id ?? '').trim();
    if (!episodeId) {
      setError('Missing episode ID');
      setPhase('error');
      return;
    }
    setPhase('loading');
    setError(null);
    initStream(episodeId)
      .then(async (data) => {
        tokenRef.current = data.token || null;
        if (!data.adRequired) {
          // Backend explicitly says no ad gate applies — go straight to entitlement.
          return finishAd(data.token);
        }
        if (!HILLTOP_VAST_URL) {
          return handleAdFailure('Hilltop VAST ad zone is not configured on the frontend');
        }
        try {
          const parsed = await fetchVast(HILLTOP_VAST_URL);
          if (parsed?.noFill) {
            logAdEvent('vast_no_fill', { episodeId });
            return finishAd(data.token);
          }
          if (!parsed?.hasAd || !parsed?.mediaFileUrl) {
            return handleAdFailure('Hilltop returned no playable ad creative');
          }
          setAd(parsed);
          setSkipIn(parsed.skipOffset?.seconds ?? null);
          setPhase('ad');
        } catch (err) {
          handleAdFailure(err?.message || 'Ad could not load');
        }
      })
      .catch(err => {
        setError(err.message);
        setPhase('error');
      });
  }, [episode?.id, finishAd, handleAdFailure]);

  useEffect(() => { loadStream(); }, [loadStream]);

  // Fire impression pixels once the ad creative is actually playing.
  // VAST pre-rolls must be able to start without a second user gesture, so the
  // ad starts muted. The viewer can unmute it after playback begins.
  const handleAdPlay = useCallback(() => {
    logAdEvent('vast_play', { episodeId: String(episode?.id ?? ''), mediaType: ad?.mediaFileType || null });
    fire('start');
    if (ad?.impressions?.length) fireTracking(ad.impressions, 'impression');
  }, [ad, fire]);

  useEffect(() => {
    if (phase !== 'ad' || !adVideoRef.current) return undefined;
    const video = adVideoRef.current;
    video.muted = true;
    setAdMuted(true);

    const attemptPlay = () => {
      const promise = video.play();
      if (promise?.catch) {
        promise.catch((error) => {
          logAdEvent('vast_error', {
            episodeId: String(episode?.id ?? ''),
            error: `Ad autoplay blocked: ${error?.message || 'play() rejected'}`,
          });
          // A blocked autoplay is not a no-fill. Keep the ad gate active and
          // let the visible play button below give the user a gesture.
        });
      }
    };

    if (video.readyState >= 2) attemptPlay();
    else video.addEventListener('canplay', attemptPlay, { once: true });

    return () => video.removeEventListener('canplay', attemptPlay);
  }, [phase, ad?.mediaFileUrl, episode?.id]);

  const handleAdTimeUpdate = useCallback(() => {
    const v = adVideoRef.current;
    if (!v || !v.duration) return;
    const pct = v.currentTime / v.duration;
    if (pct >= 0.25) fire('firstQuartile');
    if (pct >= 0.5)  fire('midpoint');
    if (pct >= 0.75) fire('thirdQuartile');
    if (ad?.skipOffset?.seconds != null) {
      const remaining = Math.max(0, Math.ceil(ad.skipOffset.seconds - v.currentTime));
      setSkipIn(remaining);
    } else if (ad?.skipOffset?.pct != null) {
      const remaining = Math.max(0, Math.ceil(((ad.skipOffset.pct / 100) * v.duration) - v.currentTime));
      setSkipIn(remaining);
    }
  }, [ad, fire]);

  const handleAdEnded = useCallback(() => {
    fire('complete');
    logAdEvent('ad_skip', { episodeId: String(episode?.id ?? ''), kind: 'natural-complete' });
    finishAd(tokenRef.current);
  }, [fire, finishAd]);

  const handleSkip = () => {
    fire('skip');
    logAdEvent('ad_skip', { episodeId: String(episode?.id ?? ''), kind: 'skip-button' });
    finishAd(tokenRef.current);
  };

  const handleRetry = () => {
    firedRef.current = new Set();
    setAd(null);
    loadStream();
  };

  const skippable = ad?.skipOffset != null;

  return (
    <div className="ad-overlay flex flex-col items-center justify-center gap-4 p-4 text-center">
      {(phase === 'loading' || phase === 'completing') && (
        <div className="flex flex-col items-center gap-3">
          <Loader2 size={32} className="text-violet animate-spin" />
          <p className="text-sm text-muted">
            {phase === 'completing' ? 'Loading your episode…' : 'Preparing your episode…'}
          </p>
        </div>
      )}

      {phase === 'ad' && ad && (
        <div className="relative w-full h-full flex flex-col items-center justify-center">
          <video
            ref={adVideoRef}
            src={ad.mediaFileUrl}
            className="w-full h-full object-contain"
            autoPlay
            muted={adMuted}
            playsInline
            preload="auto"
            onClick={() => {
              const video = adVideoRef.current;
              if (video?.paused) video.play().catch(() => {});
            }}
            onPlay={handleAdPlay}
            onTimeUpdate={handleAdTimeUpdate}
            onEnded={handleAdEnded}
            onError={() => {
              fireTracking(ad?.errorTracking, 'error');
              logAdEvent('vast_error', { episodeId: String(episode?.id ?? ''), error: 'Ad media playback failed' });
              handleAdFailure('Ad playback failed');
            }}
          />
          <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-black/60 text-[10px] font-semibold tracking-widest uppercase text-white/80">
            Advertisement
          </div>
          <div className="absolute bottom-3 left-3 flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                const video = adVideoRef.current;
                if (!video) return;
                video.muted = !video.muted;
                setAdMuted(video.muted);
                if (video.paused) video.play().catch(() => {});
              }}
              className="px-3 py-1.5 rounded-full bg-black/60 border border-white/10 text-xs text-white/80 hover:text-white"
              aria-label={adMuted ? 'Unmute advertisement' : 'Mute advertisement'}
            >
              {adMuted ? 'Unmute' : 'Mute'}
            </button>
          </div>
          <div className="absolute bottom-3 right-3">
            {skippable && skipIn <= 0 ? (
              <button
                onClick={handleSkip}
                className="btn-glow px-4 py-2 rounded-full bg-gradient-to-r from-violet to-violet-dark text-white text-xs font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300"
              >
                Skip Ad →
              </button>
            ) : skippable ? (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 border border-white/10">
                <span className="text-xs text-white/70">Skip in {skipIn}s</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/60 border border-white/10">
                <span className="text-xs text-white/70">Ad</span>
              </div>
            )}
          </div>
        </div>
      )}

      {phase === 'error' && (
        <div className="flex flex-col items-center gap-3 max-w-xs">
          <AlertCircle size={32} className="text-danger" />
          <p className="text-sm text-white font-medium">Couldn't load stream</p>
          <p className="text-xs text-muted">{error || 'Something went wrong. Please try again.'}</p>
          <button
            onClick={handleRetry}
            className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-sm text-muted transition-colors"
          >
            Retry
          </button>
        </div>
      )}
    </div>
  );
}

// ── Main player ─────────────────────────────────────────────────────────────
export default function VideoPlayer({ episode }) {
  const { user, loading: authLoading } = useAuth();
  const videoRef                  = useRef(null);
  const containerRef              = useRef(null);
  const [videoUrl, setVideoUrl]   = useState(null);
  const [playing, setPlaying]     = useState(false);
  const [muted, setMuted]         = useState(false);
  const [volume, setVolume]       = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration]   = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [buffering, setBuffering] = useState(false);
  const [playbackError, setPlaybackError] = useState(null);
  const [gateKey, setGateKey]     = useState(0); // bump to remount AdGate + re-init stream
  const hideTimer                 = useRef(null);
  const analyticsStartedRef       = useRef(false);
  const analyticsCompleteRef      = useRef(false);
  const analyticsLastSentRef      = useRef(0);
  const analyticsLastTimeRef      = useRef(0);

  const onVideoReady = useCallback((url) => {
    setPlaybackError(null);
    setVideoUrl(url);
  }, []);

  // Playback URL expired or otherwise failed mid-stream — don't crash,
  // show a clean message and let the viewer restart the flow deliberately
  // (no auto-retry loop).
  const handlePlaybackError = useCallback(() => {
    setVideoUrl(null);
    setPlaybackError('Your playback session expired. Restart the episode to keep watching.');
  }, []);

  const handleRestart = useCallback(() => {
    setPlaybackError(null);
    setGateKey(k => k + 1);
  }, []);

  // Auto-hide controls
  const resetHideTimer = useCallback(() => {
    setShowControls(true);
    clearTimeout(hideTimer.current);
    if (playing) {
      hideTimer.current = setTimeout(() => setShowControls(false), 3000);
    }
  }, [playing]);

  useEffect(() => {
    resetHideTimer();
    return () => clearTimeout(hideTimer.current);
  }, [playing, resetHideTimer]);

  useEffect(() => {
    if (!videoRef.current || !videoUrl) return;
    const v = videoRef.current;

    const onTimeUpdate = () => {
      setCurrentTime(v.currentTime);
      if (!analyticsStartedRef.current || !Number.isFinite(v.currentTime)) return;
      if (v.currentTime - analyticsLastSentRef.current >= 10) {
        const delta = Math.max(0, v.currentTime - analyticsLastTimeRef.current);
        analyticsLastSentRef.current = v.currentTime;
        analyticsLastTimeRef.current = v.currentTime;
        saveWatchProgress({
          episodeId: String(episode?.id || ''),
          positionSeconds: v.currentTime,
          durationSeconds: Number.isFinite(v.duration) ? v.duration : 0,
          completed: false,
        });
        trackAnalyticsEvent('video_progress', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
          durationSeconds: Math.min(30, delta),
        });
      }
      if (!analyticsCompleteRef.current && v.duration && v.currentTime >= v.duration - 1) {
        analyticsCompleteRef.current = true;
        saveWatchProgress({ episodeId: String(episode?.id || ''), positionSeconds: v.currentTime, durationSeconds: v.duration, completed: true });
        trackAnalyticsEvent('video_complete', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime,
          videoDuration: v.duration,
        });
      }
    };
    const onDuration   = () => setDuration(v.duration);
    const onPlay       = () => {
      setPlaying(true);
      if (!analyticsStartedRef.current) {
        analyticsStartedRef.current = true;
        analyticsLastSentRef.current = v.currentTime || 0;
        analyticsLastTimeRef.current = v.currentTime || 0;
        trackAnalyticsEvent('video_start', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime || 0,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
        });
      }
    };
    const onPause      = () => {
      setPlaying(false);
      if (analyticsStartedRef.current && !analyticsCompleteRef.current) {
        const delta = Math.max(0, (v.currentTime || 0) - (analyticsLastTimeRef.current || 0));
        if (delta > 0) {
          analyticsLastSentRef.current = v.currentTime || 0;
          analyticsLastTimeRef.current = v.currentTime || 0;
          trackAnalyticsEvent('video_progress', {
            episodeId: String(episode?.id || ''),
            videoSeconds: v.currentTime || 0,
            videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
            durationSeconds: Math.min(30, delta),
          });
        }
        trackAnalyticsEvent('video_pause', {
          episodeId: String(episode?.id || ''),
          videoSeconds: v.currentTime || 0,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
        });
      }
    };
    const onEnded      = () => {
      if (!analyticsCompleteRef.current) {
        analyticsCompleteRef.current = true;
        saveWatchProgress({ episodeId: String(episode?.id || ''), positionSeconds: Number.isFinite(v.duration) ? v.duration : v.currentTime, durationSeconds: Number.isFinite(v.duration) ? v.duration : 0, completed: true });
        trackAnalyticsEvent('video_complete', {
          episodeId: String(episode?.id || ''),
          videoSeconds: Number.isFinite(v.duration) ? v.duration : v.currentTime,
          videoDuration: Number.isFinite(v.duration) ? v.duration : 0,
        });
      }
      trackAnalyticsEvent('video_end', { episodeId: String(episode?.id || ''), videoSeconds: v.currentTime || 0, videoDuration: v.duration || 0 });
    };
    const onWaiting    = () => setBuffering(true);
    const onCanPlay    = () => setBuffering(false);
    const onError      = () => handlePlaybackError();

    v.addEventListener('timeupdate', onTimeUpdate);
    v.addEventListener('loadedmetadata', onDuration);
    v.addEventListener('play', onPlay);
    v.addEventListener('pause', onPause);
    v.addEventListener('ended', onEnded);
    v.addEventListener('waiting', onWaiting);
    v.addEventListener('canplay', onCanPlay);
    v.addEventListener('error', onError);

    return () => {
      v.removeEventListener('timeupdate', onTimeUpdate);
      v.removeEventListener('loadedmetadata', onDuration);
      v.removeEventListener('play', onPlay);
      v.removeEventListener('pause', onPause);
    v.removeEventListener('ended', onEnded);
      v.removeEventListener('waiting', onWaiting);
      v.removeEventListener('canplay', onCanPlay);
      v.removeEventListener('error', onError);
    };
  }, [videoUrl, handlePlaybackError]);

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    playing ? v.pause() : v.play();
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !muted;
    setMuted(!muted);
  };

  const onSeek = (e) => {
    const v = videoRef.current;
    if (!v || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct  = (e.clientX - rect.left) / rect.width;
    v.currentTime = pct * duration;
  };

  const toggleFullscreen = () => {
    const el = containerRef.current;
    if (!document.fullscreenElement) {
      el?.requestFullscreen?.();
      setFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setFullscreen(false);
    }
  };

  const formatTime = (s) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const progress = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="video-container aspect-video bg-black select-none"
      onMouseMove={resetHideTimer}
      onTouchStart={resetHideTimer}
    >
      {/* Account gate — public discovery stays open, playback requires login. */}
      {!authLoading && !user && !videoUrl && (
        <div className="ad-overlay flex flex-col items-center justify-center gap-4 p-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-violet/15 border border-violet/25 flex items-center justify-center">
            <Play size={24} className="text-violet-light fill-current" />
          </div>
          <div>
            <p className="text-white font-semibold">Sign in to watch this episode</p>
            <p className="text-xs text-muted mt-1 max-w-xs">Browse freely, then create a free account or sign in to start playback.</p>
          </div>
          <div className="flex items-center gap-2">
            <a href={`/register?next=${encodeURIComponent(typeof window !== 'undefined' ? window.location.pathname : '')}`} className="px-4 py-2 rounded-lg bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold">Create Account</a>
            <a href={`/login?next=${encodeURIComponent(typeof window !== 'undefined' ? window.location.pathname : '')}`} className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm font-medium">Sign In</a>
          </div>
        </div>
      )}
      {!authLoading && user && !videoUrl && !playbackError && (
        <AdGate key={gateKey} episode={episode} onVideoReady={onVideoReady} />
      )}

      {/* Expired / failed playback — clean message, manual restart (no auto-retry loop) */}
      {!videoUrl && playbackError && (
        <div className="ad-overlay flex flex-col items-center justify-center gap-3 p-8 text-center">
          <AlertCircle size={32} className="text-danger" />
          <p className="text-sm text-white font-medium">Playback session expired</p>
          <p className="text-xs text-muted max-w-xs">{playbackError}</p>
          <button
            onClick={handleRestart}
            className="btn-glow px-5 py-2 rounded-full bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300"
          >
            Restart Episode
          </button>
        </div>
      )}

      {/* Video element */}
      {videoUrl && (
        <PlaybackProtection
          active={Boolean(videoUrl)}
          userLabel={user?.email || user?.name || 'Authorized Viewer'}
        >
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-full object-contain"
            playsInline
            preload="metadata"
            autoPlay
            controlsList="nodownload noplaybackrate"
            disablePictureInPicture
            onContextMenu={(e) => e.preventDefault()}
            onDragStart={(e) => e.preventDefault()}
            onClick={togglePlay}
          />

          {/* Buffering spinner */}
          {buffering && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <Loader2 size={40} className="text-violet animate-spin" />
            </div>
          )}

          {/* Controls overlay */}
          <div
            className={`absolute inset-0 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
          >
            {/* Top gradient */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-black/70 to-transparent" />

            {/* Bottom controls */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              {/* Progress bar */}
              <div
                className="w-full h-1 mb-3 rounded-full bg-white/20 cursor-pointer group relative"
                onClick={onSeek}
              >
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet to-cyan transition-all"
                  style={{ width: `${progress}%` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white opacity-0 group-hover:opacity-100 transition-opacity shadow-glow-violet"
                  style={{ left: `${progress}%`, transform: 'translate(-50%, -50%)' }}
                />
              </div>

              {/* Button row */}
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <button onClick={togglePlay} className="text-white hover:text-violet-light transition-colors">
                    {playing
                      ? <Pause size={20} className="fill-current" />
                      : <Play  size={20} className="fill-current ml-0.5" />
                    }
                  </button>
                  <button onClick={toggleMute} className="text-white hover:text-violet-light transition-colors">
                    {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                  </button>
                  <span className="text-xs text-white/70 tabular-nums">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={toggleFullscreen} className="text-white hover:text-violet-light transition-colors">
                    {fullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </PlaybackProtection>
      )}
    </div>
  );
}
