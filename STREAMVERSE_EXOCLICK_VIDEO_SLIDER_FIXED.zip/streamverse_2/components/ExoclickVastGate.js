'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader2, Play } from 'lucide-react';
import { completeAd, initStream, logAdEvent } from '@/lib/api';

const EXOCLICK_VAST_TAG = process.env.NEXT_PUBLIC_EXOCLICK_VAST_TAG || '';
const EXOCLICK_VAST_TAGS = process.env.NEXT_PUBLIC_EXOCLICK_VAST_TAGS || '';
const DUMMY_SRC = '/ad-gate-placeholder.mp4';

function tagWithKeywords(url) {
  if (!EXOCLICK_VAST_TAGS || !url || /(?:[?&])tags=/i.test(url)) return url;
  return `${url}${url.includes('?') ? '&' : '?'}tags=${encodeURIComponent(EXOCLICK_VAST_TAGS)}`;
}

export default function ExoclickVastGate({ episode, onVideoReady }) {
  const [phase, setPhase] = useState('loading');
  const [message, setMessage] = useState('Preparing advertisement…');
  const [playBlocked, setPlayBlocked] = useState(false);
  const videoRef = useRef(null);
  const playerRef = useRef(null);
  const tokenRef = useRef(null);
  const completedRef = useRef(false);

  const finishGate = useCallback(async (reason) => {
    if (completedRef.current) return;
    completedRef.current = true;
    const token = tokenRef.current;
    if (!token) {
      setPhase('error');
      setMessage('Playback authorization is unavailable. Please try again.');
      return;
    }
    try {
      logAdEvent('exoclick_gate_complete', { episodeId: String(episode?.id || ''), reason });
      const result = await completeAd(String(episode.id), token);
      if (!result?.videoUrl) throw new Error('Backend did not return a video URL');
      onVideoReady(result.videoUrl);
    } catch (error) {
      completedRef.current = false;
      logAdEvent('exoclick_gate_complete_error', { episodeId: String(episode?.id || ''), error: error?.message || 'Authorization failed' });
      setPhase('error');
      setMessage(error?.message || 'Could not authorize the episode.');
    }
  }, [episode?.id, onVideoReady]);

  useEffect(() => {
    let cancelled = false;

    async function boot() {
      try {
        if (!EXOCLICK_VAST_TAG) throw new Error('ExoClick In-Stream VAST zone is not configured.');
        const stream = await initStream(String(episode?.id || ''));
        if (cancelled) return;
        tokenRef.current = stream?.token || null;
        if (!stream?.adRequired) {
          await finishGate('not-required');
          return;
        }

        const waitForFluidPlayer = () => new Promise((resolve, reject) => {
          if (window.fluidPlayer) return resolve(window.fluidPlayer);
          const timeoutAt = Date.now() + 10000;
          const tick = () => {
            if (window.fluidPlayer) return resolve(window.fluidPlayer);
            if (Date.now() >= timeoutAt) return reject(new Error('Fluid Player has not loaded.'));
            window.setTimeout(tick, 100);
          };
          tick();
        });
        const fluidPlayer = await waitForFluidPlayer();
        logAdEvent('exoclick_vast_player_request', { episodeId: String(episode?.id || ''), transport: 'fluid-player' });
        setPhase('player');
        setMessage('Advertisement');

        const element = videoRef.current;
        if (!element) throw new Error('Advertisement player is unavailable.');
        element.muted = true;
        element.playsInline = true;
        element.controls = true;

        const player = fluidPlayer(element.id, {
          layoutControls: {
            primaryColor: '#8b5cf6',
            autoPlay: true,
            playButtonShowing: true,
            controlBar: { autoHide: false },
          },
          vastOptions: {
            adList: [
              {
                roll: 'preRoll',
                vastTag: tagWithKeywords(EXOCLICK_VAST_TAG),
              },
            ],
          },
        });
        playerRef.current = player;

        const onPlay = () => {
          logAdEvent('exoclick_vast_player_play', { episodeId: String(episode?.id || '') });
        };
        const onError = () => {
          logAdEvent('exoclick_vast_player_error', { episodeId: String(episode?.id || ''), error: 'Fluid Player error' });
        };
        element.addEventListener('play', onPlay);
        element.addEventListener('error', onError);

        // Fluid Player runs the configured VAST pre-roll before the content source.
        // The tiny local placeholder acts only as the post-ad content sentinel; the real episode URL
        // is not requested until the VAST gate has completed.
        element.addEventListener('ended', () => finishGate('content-sentinel-ended'), { once: true });

        try {
          await element.play();
          setPlayBlocked(false);
        } catch (error) {
          setPlayBlocked(true);
          logAdEvent('exoclick_vast_autoplay_blocked', { episodeId: String(episode?.id || ''), error: error?.message || 'play() rejected' });
        }

        return () => {
          element.removeEventListener('play', onPlay);
          element.removeEventListener('error', onError);
        };
      } catch (error) {
        if (cancelled) return;
        logAdEvent('exoclick_vast_player_load_error', { episodeId: String(episode?.id || ''), error: error?.message || 'VAST load failed' });
        setPhase('error');
        setMessage(error?.message || 'Could not load the advertisement.');
      }
    }

    boot();
    return () => {
      cancelled = true;
      try { playerRef.current?.destroy?.(); } catch (_) {}
      playerRef.current = null;
    };
  }, [episode?.id, finishGate]);

  if (phase === 'loading') return <div className="ad-overlay flex flex-col items-center justify-center gap-3 p-6 text-center"><Loader2 size={32} className="animate-spin text-violet" /><p className="text-sm text-muted">{message}</p></div>;
  if (phase === 'error') return <div className="ad-overlay flex flex-col items-center justify-center gap-3 p-6 text-center"><AlertCircle size={32} className="text-danger" /><p className="text-sm text-white font-medium">Advertisement could not load</p><p className="text-xs text-muted max-w-md">{message}</p></div>;

  return (
    <div className="ad-overlay relative flex items-center justify-center bg-black overflow-hidden">
      <video id={`exoclick-ad-gate-${episode?.id}`} ref={videoRef} className="w-full h-full object-contain" playsInline muted autoPlay preload="auto">
        <source src={DUMMY_SRC} type="video/mp4" />
      </video>
      {playBlocked && <button type="button" onClick={() => videoRef.current?.play().then(() => setPlayBlocked(false)).catch(() => {})} className="absolute inset-0 m-auto w-fit h-fit px-5 py-3 rounded-full bg-violet text-white font-semibold flex items-center gap-2"><Play size={18} fill="currentColor"/>Play Advertisement</button>}
    </div>
  );
}
