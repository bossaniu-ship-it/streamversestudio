'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader2, Play } from 'lucide-react';
import { completeAd, initStream, logAdEvent } from '@/lib/api';

const EXOCLICK_VAST_TAG = process.env.NEXT_PUBLIC_EXOCLICK_VAST_TAG || '';
const EXOCLICK_VAST_TAGS = process.env.NEXT_PUBLIC_EXOCLICK_VAST_TAGS || '';
const DUMMY_SRC = '/ad-gate-placeholder.mp4';

function tagWithKeywords(url) {
  if (!EXOCLICK_VAST_TAGS || !url || /(?:[?&])tags=/i.test(url)) return url;
  return `${url}${url.includes('?') ? '&' : '?'}tags=${encodeURIComponent(EXOCLICK_VAST_TAGS)}`;
}

export default function ExoclickVastGate({ episode, onVideoReady }) {
  const [phase, setPhase] = useState('loading');
  const [message, setMessage] = useState('Preparing advertisement…');
  const [playBlocked, setPlayBlocked] = useState(false);
  const videoRef = useRef(null);
  const playerRef = useRef(null);
  const tokenRef = useRef(null);
  const completedRef = useRef(false);
  const mountedRef = useRef(false);

  const episodeId = String(episode?.id || '');

  const finishGate = useCallback(async (reason) => {
    if (completedRef.current || !episodeId) return;
    completedRef.current = true;

    const token = tokenRef.current;
    if (!token) {
      completedRef.current = false;
      setPhase('error');
      setMessage('Playback authorization is unavailable. Please try again.');
      return;
    }

    try {
      logAdEvent('exoclick_gate_complete', { episodeId, reason });
      const result = await completeAd(episodeId, token);
      if (!result?.videoUrl) throw new Error('Backend did not return a video URL');
      onVideoReady(result.videoUrl);
    } catch (error) {
      completedRef.current = false;
      logAdEvent('exoclick_gate_complete_error', {
        episodeId,
        error: error?.message || 'Authorization failed',
      });
      if (mountedRef.current) {
        setPhase('error');
        setMessage(error?.message || 'Could not authorize the episode.');
      }
    }
  }, [episodeId, onVideoReady]);

  useEffect(() => {
    mountedRef.current = true;
    let cancelled = false;

    async function boot() {
      try {
        if (!EXOCLICK_VAST_TAG) throw new Error('ExoClick In-Stream VAST zone is not configured.');

        const stream = await initStream(episodeId);
        if (cancelled) return;

        tokenRef.current = stream?.token || null;

        if (!stream?.adRequired) {
          await finishGate('not-required');
          return;
        }

        const waitForFluidPlayer = () => new Promise((resolve, reject) => {
          if (typeof window !== 'undefined' && typeof window.fluidPlayer === 'function') {
            return resolve(window.fluidPlayer);
          }
          const timeoutAt = Date.now() + 15000;
          const tick = () => {
            if (typeof window !== 'undefined' && typeof window.fluidPlayer === 'function') {
              resolve(window.fluidPlayer);
              return;
            }
            if (Date.now() >= timeoutAt) {
              reject(new Error('Fluid Player has not loaded.'));
              return;
            }
            window.setTimeout(tick, 100);
          };
          tick();
        });

        const fluidPlayer = await waitForFluidPlayer();
        if (cancelled) return;

        // The video element is rendered from the first render, so it exists by
        // the time this async initialization resumes. The previous implementation
        // switched phase to "player" before reading the ref, causing a guaranteed
        // null ref and the "Advertisement player is unavailable" screen.
        const element = videoRef.current;
        if (!element) throw new Error('Advertisement player element is unavailable.');
        if (!element.id) element.id = `exoclick-ad-gate-${episodeId}`;

        logAdEvent('exoclick_vast_player_request', {
          episodeId,
          transport: 'fluid-player',
        });

        setPhase('player');
        setMessage('Advertisement');

        element.muted = true;
        element.playsInline = true;
        element.controls = false;
        element.preload = 'auto';

        const player = fluidPlayer(element.id, {
          layoutControls: {
            primaryColor: '#8b5cf6',
            autoPlay: true,
            mute: true,
            playButtonShowing: true,
            allowDownload: false,
            controlBar: { autoHide: false },
          },
          vastOptions: {
            adList: [
              {
                roll: 'preRoll',
                vastTag: tagWithKeywords(EXOCLICK_VAST_TAG),
              },
            ],
            showPlayButton: true,
            maxAllowedVastTagRedirects: 5,
            vastAdvanced: {
              vastLoadedCallback: () => {
                logAdEvent('exoclick_vast_loaded', { episodeId });
              },
              noVastVideoCallback: () => {
                logAdEvent('exoclick_vast_no_fill', { episodeId, transport: 'fluid-player' });
                void finishGate('no-fill');
              },
              vastVideoSkippedCallback: () => {
                logAdEvent('exoclick_vast_skipped', { episodeId });
                void finishGate('skipped');
              },
              vastVideoEndedCallback: () => {
                logAdEvent('exoclick_vast_completed', { episodeId });
                void finishGate('completed');
              },
            },
          },
        });

        playerRef.current = player;

        // Fluid Player 3.x exposes its own event API. Keep browser-level events
        // as diagnostics only; ad completion is handled by vastAdvanced callbacks
        // above so we never confuse the ad's ended event with the sentinel video.
        if (player?.on) {
          try {
            player.on('play', (_event, info) => {
              logAdEvent('exoclick_vast_play', {
                episodeId,
                source: info?.mediaSourceType || 'unknown',
              });
            });
            player.on('playing', (_event, info) => {
              logAdEvent('exoclick_vast_playing', {
                episodeId,
                source: info?.mediaSourceType || 'unknown',
              });
            });
          } catch (_) {
            // Event API is optional across Fluid Player builds; VAST callbacks remain authoritative.
          }
        }

        try {
          if (typeof player?.play === 'function') {
            await Promise.resolve(player.play());
          } else {
            await element.play();
          }
          if (mountedRef.current) setPlayBlocked(false);
        } catch (error) {
          setPlayBlocked(true);
          logAdEvent('exoclick_vast_autoplay_blocked', {
            episodeId,
            error: error?.message || 'play() rejected',
          });
        }
      } catch (error) {
        if (cancelled) return;
        logAdEvent('exoclick_vast_player_load_error', {
          episodeId,
          error: error?.message || 'VAST load failed',
        });
        setPhase('error');
        setMessage(error?.message || 'Could not load the advertisement.');
      }
    }

    boot();

    return () => {
      cancelled = true;
      mountedRef.current = false;
      try { playerRef.current?.destroy?.(); } catch (_) {}
      playerRef.current = null;
    };
  }, [episodeId, finishGate]);

  return (
    <div className="ad-overlay relative flex items-center justify-center bg-black overflow-hidden">
      <video
        id={`exoclick-ad-gate-${episodeId}`}
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline
        muted
        autoPlay
        preload="auto"
        aria-label="Advertisement"
      >
        <source src={DUMMY_SRC} type="video/mp4" />
      </video>

      {phase === 'loading' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center bg-black/75">
          <Loader2 size={32} className="animate-spin text-violet" />
          <p className="text-sm text-muted">{message}</p>
        </div>
      )}

      {phase === 'player' && playBlocked && (
        <button
          type="button"
          onClick={() => {
            const p = playerRef.current;
            const attempt = typeof p?.play === 'function' ? p.play() : videoRef.current?.play();
            Promise.resolve(attempt)
              .then(() => setPlayBlocked(false))
              .catch(() => {});
          }}
          className="absolute inset-0 m-auto w-fit h-fit px-5 py-3 rounded-full bg-violet text-white font-semibold flex items-center gap-2 shadow-lg"
        >
          <Play size={18} fill="currentColor" />
          Play Advertisement
        </button>
      )}

      {phase === 'error' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center bg-black">
          <AlertCircle size={32} className="text-danger" />
          <p className="text-sm text-white font-medium">Advertisement could not load</p>
          <p className="text-xs text-muted max-w-md">{message}</p>
        </div>
      )}
    </div>
  );
}
