'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AlertCircle, Loader2, Volume2, VolumeX } from 'lucide-react';

const DEFAULT_VAST_PROXY = '/api/ads/vast';

function textOf(node) {
  return String(node?.textContent || '').trim();
}

function firstText(parent, tagName) {
  return textOf(parent?.querySelector(tagName));
}

function allTexts(parent, tagName) {
  return Array.from(parent?.querySelectorAll(tagName) || [])
    .map(textOf)
    .filter(Boolean);
}

function parseDuration(value) {
  const m = String(value || '').trim().match(/^(?:(\d+):)?(\d+):(\d+)(?:\.(\d+))?$/);
  if (!m) return 0;
  const hours = Number(m[1] || 0);
  const minutes = Number(m[2] || 0);
  const seconds = Number(m[3] || 0);
  const fraction = m[4] ? Number(`0.${m[4]}`) : 0;
  return hours * 3600 + minutes * 60 + seconds + fraction;
}

function parseOffset(value, duration) {
  const raw = String(value || '').trim();
  if (!raw) return 0;
  if (raw.endsWith('%')) {
    const pct = Number(raw.slice(0, -1));
    return Number.isFinite(pct) && duration > 0 ? duration * pct / 100 : 0;
  }
  return parseDuration(raw);
}

function replaceMacros(url, { cachebuster, timestamp, errorCode = '204' } = {}) {
  return String(url || '')
    .replace(/\[CACHEBUSTING\]|\[CACHEBUSTER\]|\[CACHE_BUSTING\]|%%CACHEBUSTING%%/gi, cachebuster)
    .replace(/\[TIMESTAMP\]|%%TIMESTAMP%%/gi, timestamp)
    .replace(/\[ERRORCODE\]|%%ERRORCODE%%/gi, errorCode);
}

function fireTracking(urls, context = {}) {
  const cachebuster = String(Math.floor(Math.random() * 1e9));
  const timestamp = new Date().toISOString();
  for (const raw of urls || []) {
    const url = replaceMacros(raw, { cachebuster, timestamp, ...context });
    if (!url) continue;
    try {
      const image = new Image();
      image.referrerPolicy = 'no-referrer-when-downgrade';
      image.src = url;
    } catch (_) {}
  }
}

function absolutizeUrl(value, baseUrl) {
  try {
    return new URL(String(value || '').trim(), baseUrl).toString();
  } catch {
    return '';
  }
}

function buildProxyUrl(url, origin = '') {
  if (!url) return '';
  // Wrapper URLs are re-requested through the same-origin proxy, which lets the
  // server rewrite subsequent VASTAdTagURI entries without browser CORS failures.
  if (!origin) return url;
  try {
    const parsed = new URL(url, origin);
    if (parsed.origin === origin) return parsed.toString();
    return `${DEFAULT_VAST_PROXY}?url=${encodeURIComponent(parsed.toString())}`;
  } catch {
    return '';
  }
}

function chooseMediaFile(files, element) {
  const candidates = Array.from(files || [])
    .map((node) => ({
      url: textOf(node),
      type: String(node.getAttribute('type') || '').toLowerCase(),
      delivery: String(node.getAttribute('delivery') || '').toLowerCase(),
      width: Number(node.getAttribute('width') || 0),
      bitrate: Number(node.getAttribute('bitrate') || 0),
    }))
    .filter((file) => file.url);

  const playable = candidates.filter((file) => {
    try {
      const mime = file.type || 'video/mp4';
      const support = element?.canPlayType?.(mime);
      return support === 'probably' || support === 'maybe';
    } catch {
      return false;
    }
  });

  const pool = playable.length ? playable : candidates;
  const score = (file) => {
    let value = 0;
    if (file.type === 'video/mp4') value += 1000;
    if (file.type === 'video/webm') value += 700;
    if (file.type === 'application/vnd.apple.mpegurl' || file.type === 'application/x-mpegurl') value += 450;
    if (file.delivery === 'progressive') value += 60;
    value += Math.min(180, Math.max(0, file.bitrate / 100));
    return value;
  };
  return pool.sort((a, b) => score(b) - score(a))[0] || null;
}

async function fetchVastDocument(url, { maxDepth = 5, signal } = {}) {
  let currentUrl = url;
  const wrapperImpressions = [];
  const wrapperTracking = [];
  const wrapperClicks = [];
  const origin = typeof window !== 'undefined' ? window.location.origin : '';

  for (let depth = 0; depth <= maxDepth; depth += 1) {
    const response = await fetch(buildProxyUrl(currentUrl, origin), {
      method: 'GET',
      cache: 'no-store',
      signal,
      headers: { Accept: 'application/xml,text/xml;q=0.9,*/*;q=0.8' },
    });
    const body = await response.text();
    if (!response.ok) throw new Error(`VAST request failed (${response.status})`);
    if (!body || !/<VAST[\s>]/i.test(body)) throw new Error('The ad server returned an invalid VAST response.');

    const document = new DOMParser().parseFromString(body, 'text/xml');
    if (document.querySelector('parsererror')) throw new Error('The ad server returned malformed VAST XML.');

    const ad = document.querySelector('Ad');
    if (!ad) throw new Error('No ad was available in the VAST response.');

    const inline = ad.querySelector('InLine');
    const wrapper = ad.querySelector('Wrapper');

    if (wrapper && !inline) {
      wrapperImpressions.push(...allTexts(wrapper, 'Impression'));
      wrapperTracking.push(...Array.from(wrapper.querySelectorAll('Tracking')).map((node) => ({
        event: String(node.getAttribute('event') || '').toLowerCase(),
        offset: String(node.getAttribute('offset') || ''),
        url: textOf(node),
      })).filter((item) => item.url));
      wrapperClicks.push(...allTexts(wrapper, 'ClickTracking'));

      const next = firstText(wrapper, 'VASTAdTagURI');
      if (!next) throw new Error('The VAST wrapper did not contain a follow-up ad tag.');
      currentUrl = absolutizeUrl(next, currentUrl);
      if (!currentUrl) throw new Error('The VAST wrapper URL is invalid.');
      continue;
    }

    if (!inline) throw new Error('The VAST response did not contain an inline video ad.');

    const linear = inline.querySelector('Linear');
    if (!linear) throw new Error('The VAST response did not contain a linear video ad.');

    const duration = parseDuration(firstText(linear, 'Duration'));
    const mediaFiles = Array.from(linear.querySelectorAll('MediaFiles MediaFile'));
    const clickThrough = firstText(linear, 'VideoClicks ClickThrough');
    const clickTracking = allTexts(linear, 'VideoClicks ClickTracking');
    const skipoffset = linear.getAttribute('skipoffset') || '';

    const tracking = Array.from(linear.querySelectorAll('TrackingEvents Tracking'))
      .map((node) => ({
        event: String(node.getAttribute('event') || '').toLowerCase(),
        offset: String(node.getAttribute('offset') || ''),
        url: textOf(node),
      }))
      .filter((item) => item.url);

    return {
      adId: String(ad.getAttribute('id') || ''),
      duration,
      mediaFiles,
      clickThrough,
      clickTracking: [...wrapperClicks, ...clickTracking],
      impressions: [...wrapperImpressions, ...allTexts(inline, 'Impression')],
      tracking: [...wrapperTracking, ...tracking],
      skipSeconds: parseOffset(skipoffset, duration),
      errorUrls: allTexts(inline, 'Error'),
    };
  }

  throw new Error('Too many VAST wrappers.');
}

export default function ClickadillaVastAd({
  vastUrl,
  onComplete,
  className = '',
  autoPlay = true,
  label = 'Advertisement',
}) {
  const videoRef = useRef(null);
  const dataRef = useRef(null);
  const firedRef = useRef(new Set());
  const completeRef = useRef(false);
  const startedRef = useRef(false);
  const [phase, setPhase] = useState('loading');
  const [message, setMessage] = useState('Loading advertisement…');
  const [muted, setMuted] = useState(true);
  const [skipReady, setSkipReady] = useState(false);
  const [adPlayBlocked, setAdPlayBlocked] = useState(false);
  const [clickThrough, setClickThrough] = useState('');

  const safeComplete = useCallback((reason = 'completed', errorCode = '204') => {
    if (completeRef.current) return;
    completeRef.current = true;
    const data = dataRef.current;
    if (data?.errorUrls?.length) fireTracking(data.errorUrls, { errorCode });
    onComplete?.(reason);
  }, [onComplete]);

  useEffect(() => {
    const controller = new AbortController();
    let disposed = false;

    if (!vastUrl) {
      setPhase('unavailable');
      setMessage('No advertisement tag is configured.');
      return () => controller.abort();
    }

    setPhase('loading');
    setMessage('Loading advertisement…');
    setSkipReady(false);
    setAdPlayBlocked(false);
    completeRef.current = false;
    startedRef.current = false;
    firedRef.current = new Set();

    (async () => {
      try {
        const data = await fetchVastDocument(vastUrl, { signal: controller.signal });
        if (disposed) return;

        const element = videoRef.current;
        const media = chooseMediaFile(data.mediaFiles, element);
        if (!media) throw new Error('No browser-compatible video creative was returned.');

        dataRef.current = data;
        setClickThrough(data.clickThrough || '');
        element.muted = true;
        element.playsInline = true;
        element.preload = 'auto';
        element.setAttribute('aria-label', label);
        element.src = media.url;
        element.load();
        setPhase('ready');
        setMessage('Advertisement');
      } catch (error) {
        if (disposed || error?.name === 'AbortError') return;
        setPhase('error');
        setMessage(error?.message || 'The advertisement could not be loaded.');
        safeComplete('load-error', '303');
      }
    })();

    return () => {
      disposed = true;
      controller.abort();
    };
  }, [vastUrl, safeComplete, label]);

  useEffect(() => {
    if (phase !== 'ready' || !autoPlay) return undefined;
    const video = videoRef.current;
    if (!video) return undefined;

    const playNow = () => {
      Promise.resolve(video.play())
        .then(() => setAdPlayBlocked(false))
        .catch(() => setAdPlayBlocked(true));
    };
    if (video.readyState >= 2) playNow();
    else video.addEventListener('canplay', playNow, { once: true });
    return () => video.removeEventListener('canplay', playNow);
  }, [phase, autoPlay]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return undefined;

    const fireOnce = (key, urls, context = {}) => {
      if (!urls?.length || firedRef.current.has(key)) return;
      firedRef.current.add(key);
      fireTracking(urls, context);
    };

    const onPlay = () => {
      if (startedRef.current) return;
      startedRef.current = true;
      const data = dataRef.current;
      fireOnce('impression', data?.impressions);
      fireOnce('start', data?.tracking?.filter((item) => item.event === 'start').map((item) => item.url));
      setAdPlayBlocked(false);
      setPhase('playing');
    };

    const onTimeUpdate = () => {
      const data = dataRef.current;
      const current = Number(video.currentTime) || 0;
      const total = Number(video.duration) || Number(data?.duration) || 0;
      if (!data || !total) return;

      if (data.skipSeconds > 0 && current >= data.skipSeconds) setSkipReady(true);

      const quartiles = [
        ['firstquartile', 0.25],
        ['midpoint', 0.5],
        ['thirdquartile', 0.75],
      ];
      for (const [event, ratio] of quartiles) {
        if (current / total >= ratio) {
          fireOnce(event, data.tracking?.filter((item) => item.event === event).map((item) => item.url));
        }
      }

      for (const item of data.tracking || []) {
        if (item.event !== 'progress' || !item.offset) continue;
        const offset = parseOffset(item.offset, total);
        if (offset > 0 && current >= offset) {
          fireOnce(`progress:${item.offset}:${item.url}`, [item.url]);
        }
      }
    };

    const onEnded = () => {
      const data = dataRef.current;
      fireOnce('complete', data?.tracking?.filter((item) => item.event === 'complete').map((item) => item.url));
      safeComplete('completed');
    };

    const onError = () => safeComplete('media-error', '405');

    video.addEventListener('play', onPlay);
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('ended', onEnded);
    video.addEventListener('error', onError);
    return () => {
      video.removeEventListener('play', onPlay);
      video.removeEventListener('timeupdate', onTimeUpdate);
      video.removeEventListener('ended', onEnded);
      video.removeEventListener('error', onError);
    };
  }, [safeComplete]);

  const toggleMuted = () => {
    const video = videoRef.current;
    if (!video) return;
    const next = !video.muted;
    video.muted = next;
    setMuted(next);
  };

  const handleAdClick = () => {
    const data = dataRef.current;
    fireTracking(data?.clickTracking);
    if (!clickThrough) return;
    try { window.open(clickThrough, '_blank', 'noopener,noreferrer'); } catch (_) { window.location.href = clickThrough; }
  };

  const statusText = useMemo(() => {
    if (phase === 'error' || phase === 'unavailable') return message;
    return message;
  }, [phase, message]);

  return (
    <div className={`absolute inset-0 z-50 flex items-center justify-center bg-black overflow-hidden ${className}`}>
      <video
        ref={videoRef}
        className="w-full h-full object-contain bg-black"
        playsInline
        muted
        preload="metadata"
        onClick={handleAdClick}
      />

      {(phase === 'loading' || phase === 'ready') && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="rounded-xl bg-black/65 backdrop-blur-sm px-4 py-3 text-center">
            {phase === 'loading' && <Loader2 size={24} className="mx-auto mb-2 text-violet animate-spin" />}
            <p className="text-xs text-white/80">{statusText}</p>
            {phase === 'ready' && <p className="text-[10px] text-white/45 mt-1">Click the ad to learn more</p>}
          </div>
        </div>
      )}

      {phase === 'ready' && adPlayBlocked && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button
            type="button"
            onClick={(event) => {
              event.stopPropagation();
              const video = videoRef.current;
              if (!video) return;
              Promise.resolve(video.play())
                .then(() => setAdPlayBlocked(false))
                .catch(() => {});
            }}
            className="pointer-events-auto inline-flex items-center gap-2 px-5 py-3 rounded-full bg-violet text-white text-sm font-semibold shadow-glow-violet border border-white/10"
          >
            Play Advertisement
          </button>
        </div>
      )}

      {(phase === 'playing' || phase === 'ready') && (
        <div className="absolute left-3 right-3 bottom-3 flex items-end justify-between gap-3 pointer-events-none">
          <div className="rounded-md bg-black/55 px-2.5 py-1.5 text-[10px] text-white/70 backdrop-blur-sm">{label}</div>
          <div className="flex items-center gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={toggleMuted}
              aria-label={muted ? 'Unmute advertisement' : 'Mute advertisement'}
              className="w-8 h-8 rounded-full bg-black/60 border border-white/15 text-white flex items-center justify-center backdrop-blur-sm"
            >
              {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            {skipReady && (
              <button
                type="button"
                onClick={() => {
                  fireTracking(dataRef.current?.tracking?.filter((item) => item.event === 'skip').map((item) => item.url));
                  safeComplete('skipped');
                }}
                className="px-3 py-2 rounded-md bg-black/70 border border-white/20 text-xs text-white font-semibold backdrop-blur-sm"
              >
                Skip Ad
              </button>
            )}
          </div>
        </div>
      )}

      {phase === 'error' && !completeRef.current && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center bg-black">
          <AlertCircle size={28} className="text-danger" />
          <p className="text-sm text-white font-medium">Advertisement unavailable</p>
          <p className="text-xs text-muted max-w-md">{message}</p>
        </div>
      )}
    </div>
  );
}
