# StreamVerse Studio — Ad + Standalone Movie Handoff

## What was fixed

1. **Fullscreen control** — the movie player now synchronizes its state with the browser fullscreen events, handles request/exit failures, supports standard fullscreen plus WebKit fallbacks, and no longer flips the icon before the browser actually enters fullscreen.
2. **ClickAdilla VAST playback** — the frontend no longer depends on Fluid Player for the ad creative. It fetches VAST through the same-origin `/api/ads/vast` route, follows VAST wrappers through that route, selects a browser-compatible media file, and plays the creative with native HTML5 video.
3. **VAST wrapper/CORS path** — nested `VASTAdTagURI` values are rewritten back through the same-origin proxy so wrapper XML does not depend on browser cross-origin XHR. Native video playback is used for the returned creative, avoiding the Fluid Player media pre-check failure mode documented in its current issue tracker.
4. **Ad autoplay fallback** — ads start muted for autoplay compatibility. When a browser still rejects autoplay, a direct **Play Advertisement** control appears without turning the ad click target into a misleading play action.
5. **Ad failure handling** — a no-fill, malformed VAST, unsupported creative, or media error no longer leaves the movie permanently stuck at the ad gate; the existing authorization completion path is still called so the backend can decide whether playback may proceed.
6. **Mid-roll** — the movie timeline still triggers the configured `NEXT_PUBLIC_CLICKADILLA_MIDROLL_SECONDS` value, but the temporary Fluid Player implementation has been replaced by the same native VAST renderer.
7. **Standalone-movie UI** — visible Season/Episode/SxEx/Airing terminology was removed from the presentation. The library now presents **Movies**, **Collections**, **Latest release**, and **Standalone movies**. Internal backend keys, function names, IDs, routes, and payload fields remain unchanged for compatibility.

## Payload compatibility

The following application contracts were intentionally preserved:

- `episodeId` request fields and `/api/episodes/:id/stream` / `/api/episodes/:id/ad-complete` endpoints.
- `initStream(episodeId)` and `completeAd(episodeId, token)` behavior and returned `videoUrl`.
- History/search payload arrays such as `history`, `episodes`, and `shows`.
- Existing normalized fields including `episodeTitle`, `seasonNumber`, `episodeNumber`, `episode_count`, and `posted_episode_count`.
- Analytics/watch-progress fields such as `episodeId`, `positionSeconds`, `durationSeconds`, and `completed`.

These fields remain internal data contracts; they are not exposed as Season/Episode UI labels.

## ClickAdilla configuration

- `NEXT_PUBLIC_CLICKADILLA_VAST_TAG` — approved VAST tag URL.
- `NEXT_PUBLIC_CLICKADILLA_MIDROLL_SECONDS` — mid-roll trigger in seconds; the project default remains 60 seconds unless the environment overrides it.

The ClickAdilla account/campaign/tag still needs to be active and approved and must actually return a VAST video creative. ClickAdilla's current in-stream documentation describes VAST-based video inventory and notes that campaign/tag availability affects fill.

## Verification

- All JavaScript/JSX/TS/TSX source files were parsed successfully with the TypeScript parser.
- The VAST route passes `node --check`.
- Contract files `lib/api.js`, `lib/analytics.js`, `lib/catalog.js`, and `components/AuthContext.js` were diff-checked; no payload/schema changes were introduced.
- A complete production `next build` could not be executed in the sandbox because the npm dependency tree was not installed and the sandbox could not retrieve packages.
- The configured live VAST endpoint was also not directly reachable from the sandbox, so live ad fill was not falsely claimed as verified.
