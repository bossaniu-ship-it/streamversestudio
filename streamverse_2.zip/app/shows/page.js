import { fetchHistory } from '@/lib/api';
import ShowCard from '@/components/ShowCard';
import { Clapperboard, AlertCircle } from 'lucide-react';

export const metadata = {
  title: 'Shows — StreamVerse Studio',
  description: 'Browse all original series on StreamVerse Studio',
};

export default async function ShowsPage() {
  let shows = [];
  let error = null;

  try {
    const data = await fetchHistory();
    shows = data?.activeShows || [];
  } catch (e) {
    error = e.message;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center gap-2 mb-2">
          <Clapperboard size={18} className="text-violet-light" />
          <span className="text-xs text-muted tracking-widest uppercase font-semibold">All Series</span>
        </div>
        <h1 className="font-display text-4xl font-black text-white">
          Active <span className="gradient-text">Shows</span>
        </h1>
        <p className="text-sm text-muted mt-2">
          Original series in production. New episodes publish daily.
        </p>
      </div>

      {/* Grid */}
      {error ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <AlertCircle size={32} className="text-danger/60" />
          <p className="text-sm text-muted">{error}</p>
        </div>
      ) : shows.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <Clapperboard size={40} className="text-muted/30" />
          <p className="text-sm text-muted">No shows yet — check back soon.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 stagger-in">
          {shows.map((show, i) => (
            <ShowCard key={show.id || i} show={show} />
          ))}
        </div>
      )}
    </div>
  );
}
