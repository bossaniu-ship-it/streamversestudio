const BACKEND = process.env.BACKEND_URL || '';

export async function GET() {
  try {
    const res = await fetch(`${BACKEND}/api/status`, {
      next: { revalidate: 30 },
    });
    const data = await res.json();
    return Response.json({ ok: true, status: data.status });
  } catch {
    return Response.json({ ok: false, status: 'Offline' }, { status: 200 });
  }
}
