'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { User, Mail, ShieldCheck, LogOut, Loader2 } from 'lucide-react';
import { useAuth } from '@/components/AuthContext';

export default function AccountPage() {
  const router = useRouter();
  const { user, loading, logout } = useAuth();

  useEffect(() => {
    if (!loading && !user) router.replace('/login');
  }, [loading, user, router]);

  if (loading || !user) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 size={28} className="text-violet animate-spin" />
      </div>
    );
  }

  const onSignOut = () => {
    logout();
    router.push('/');
  };

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-16">
      <div className="glass rounded-2xl border border-white/10 p-8">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet to-cyan flex items-center justify-center mb-4 shadow-glow-violet">
          <User size={24} className="text-white" />
        </div>
        <h1 className="font-display text-xl font-bold text-white mb-1">
          {user.displayName || 'Your account'}
        </h1>
        <p className="text-sm text-muted mb-6">Manage your StreamVerse Studio account.</p>

        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10">
            <Mail size={15} className="text-violet-light flex-shrink-0" />
            <span className="text-sm text-white/90 truncate">{user.email}</span>
          </div>
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10">
            <ShieldCheck size={15} className={user.emailVerified ? 'text-green-400' : 'text-muted'} />
            <span className="text-sm text-white/90">
              {user.emailVerified ? 'Email verified' : 'Email not verified'}
            </span>
          </div>
        </div>

        <button
          onClick={onSignOut}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm text-white/80 transition-colors"
        >
          <LogOut size={14} />
          Sign Out
        </button>
      </div>
    </div>
  );
}
