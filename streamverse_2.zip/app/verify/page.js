'use client';

import { Suspense, useEffect, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { verifyEmail } from '@/lib/authApi';

function VerifyContent() {
  const params = useSearchParams();
  const token  = params.get('token');

  const [status, setStatus] = useState('loading'); // loading | ok | error
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!token) {
      setStatus('error');
      setMessage('Missing verification token.');
      return;
    }
    verifyEmail(token)
      .then(data => {
        setStatus('ok');
        setMessage(data.message || 'Email verified — you can now sign in.');
      })
      .catch(err => {
        setStatus('error');
        setMessage(err.message);
      });
  }, [token]);

  return (
    <div className="max-w-md mx-auto px-4 sm:px-6 py-20">
      <div className="glass rounded-2xl border border-white/10 p-8 text-center">
        {status === 'loading' && (
          <>
            <Loader2 size={32} className="text-violet animate-spin mx-auto mb-4" />
            <p className="text-sm text-muted">Verifying your email…</p>
          </>
        )}
        {status === 'ok' && (
          <>
            <CheckCircle2 size={32} className="text-green-400 mx-auto mb-4" />
            <h1 className="font-display text-xl font-bold text-white mb-2">You're verified</h1>
            <p className="text-sm text-muted mb-6">{message}</p>
            <Link
              href="/login"
              className="inline-block px-6 py-2.5 rounded-full bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300"
            >
              Sign In
            </Link>
          </>
        )}
        {status === 'error' && (
          <>
            <AlertCircle size={32} className="text-danger mx-auto mb-4" />
            <h1 className="font-display text-xl font-bold text-white mb-2">Verification failed</h1>
            <p className="text-sm text-muted mb-6">{message}</p>
            <Link href="/register" className="text-sm text-violet-light hover:underline">Back to sign up</Link>
          </>
        )}
      </div>
    </div>
  );
}

export default function VerifyPage() {
  return (
    <Suspense fallback={null}>
      <VerifyContent />
    </Suspense>
  );
}
