import { fetchHistory } from '@/lib/api';
import VideoPlayer from '@/components/VideoPlayer';
import EpisodeCard from '@/components/EpisodeCard';
import GenreBadge from '@/components/GenreBadge';
import { ArrowLeft, Share2, ExternalLink, Sparkles } from 'lucide-react';
import Link from 'next/link';
import { timeAgo } from '@/lib/api';
import WatchClientWrapper from '@/components/WatchClientWrapper';

// Build static params from known episode IDs
export async function generateStaticParams() {
  try {
    const data = await fetchHistory();
    return (data?.history || [])
      .filter(e => e.id)
      .map(e => ({ id: e.id }));
  } catch {
    return [];
  }
}

export async function generateMetadata({ params }) {
  try {
    const data = await fetchHistory();
    const ep   = data?.history?.find(e => e.id === params.id);
    if (ep) {
      return {
        title: `${ep.episodeTitle || ep.title} — StreamVerse Studio`,
        description: ep.synopsis || `Watch ${ep.title} on StreamVerse Studio`,
      };
    }
  } catch {}
  return { title: 'Watch — StreamVerse Studio' };
}

export default async function WatchPage({ params }) {
  let episode  = null;
  let related  = [];
  let error    = null;

  try {
    const data = await fetchHistory();
    episode    = data?.history?.find(e => e.id === params.id) || null;
    related    = (data?.history || []).filter(e => e.id !== params.id).slice(0, 4);
  } catch (e) {
    error = e.message;
  }

  if (error || !episode) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 text-center">
        <div className="glass rounded-2xl border border-white/10 p-12">
          <p className="text-muted mb-4">{error || 'Episode not found'}</p>
          <Link href="/" className="text-violet-light hover:underline text-sm">
            ← Back to all episodes
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back nav */}
      <Link
        href="/"
        className="inline-flex items-center gap-1.5 text-sm text-muted hover:text-white mb-6 transition-colors group"
      >
        <ArrowLeft size={14} className="group-hover:-translate-x-0.5 transition-transform" />
        All Episodes
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: player + info */}
        <div className="lg:col-span-2 space-y-6">
          {/* Player */}
          <WatchClientWrapper episode={episode} />

          {/* Episode info */}
          <div className="glass rounded-2xl border border-white/7 p-6">
            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  <GenreBadge genre={episode.genre} size="sm" />
                  <span className="text-xs text-muted">{episode.title}</span>
                  <span className="text-xs text-muted">•</span>
                  <span className="text-xs text-muted">{timeAgo(episode.postedAt)}</span>
                </div>
                <h1 className="font-display text-2xl sm:text-3xl font-bold text-white leading-tight">
                  {episode.episodeTitle || 'Untitled Episode'}
                </h1>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                {episode.facebookLink && (
                  <a
                    href={episode.facebookLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-lg glass border border-white/10 text-muted hover:text-cyan transition-colors"
                    title="View on Facebook"
                  >
                    <ExternalLink size={15} />
                  </a>
                )}
              </div>
            </div>

            {episode.synopsis && (
              <p className="text-sm text-white/70 leading-relaxed border-t border-white/5 pt-4">
                {episode.synopsis}
              </p>
            )}

            {/* Meta row */}
            <div className="flex items-center gap-4 mt-4 pt-4 border-t border-white/5 flex-wrap">
              {episode.scenes > 0 && (
                <div className="flex items-center gap-1.5">
                  <Sparkles size={12} className="text-violet-light" />
                  <span className="text-xs text-muted">{episode.scenes} scenes</span>
                </div>
              )}
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                <span className="text-xs text-muted">Free to watch</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: related */}
        {related.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles size={14} className="text-violet-light" />
              <h2 className="font-display text-base font-bold text-white">More Episodes</h2>
            </div>
            <div className="space-y-4 stagger-in">
              {related.map((ep, i) => (
                <EpisodeCard key={ep.id || i} episode={ep} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
