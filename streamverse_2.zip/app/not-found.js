import Link from 'next/link';
import { Tv2 } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center px-6 text-center">
      <div className="w-20 h-20 rounded-2xl glass border border-violet/20 flex items-center justify-center mb-6">
        <Tv2 size={36} className="text-violet/60" />
      </div>
      <h1 className="font-display text-6xl font-black gradient-text mb-4">404</h1>
      <p className="text-muted mb-2 text-lg">Page not found</p>
      <p className="text-muted/60 text-sm mb-8 max-w-xs">
        This episode or page doesn't exist. Head back and discover something new.
      </p>
      <Link
        href="/"
        className="btn-glow px-6 py-3 rounded-xl bg-gradient-to-r from-violet to-violet-dark text-white font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300"
      >
        Back to StreamVerse
      </Link>
    </div>
  );
}
