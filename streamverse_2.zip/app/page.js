import { Suspense } from 'react';
import { fetchHistory } from '@/lib/api';
import EpisodeCard from '@/components/EpisodeCard';
import HeroSection from '@/components/HeroSection';
import SkeletonCard from '@/components/SkeletonCard';
import GenreFilter from '@/components/GenreFilter';
import StatsBar from '@/components/StatsBar';
import { Sparkles, Tv2, AlertCircle } from 'lucide-react';

async function EpisodeGrid() {
  let data = null;
  let error = null;

  try {
    data = await fetchHistory();
  } catch (e) {
    error = e.message;
  }

  if (error || !data?.history?.length) {
    return (
      <div className="col-span-full flex flex-col items-center justify-center py-24 gap-4">
        <div className="w-16 h-16 rounded-2xl glass border border-white/10 flex items-center justify-center">
          {error
            ? <AlertCircle size={28} className="text-danger/70" />
            : <Tv2 size={28} className="text-muted/60" />
          }
        </div>
        <p className="text-sm text-muted text-center max-w-xs">
          {error
            ? `Couldn't reach the backend: ${error}`
            : 'No episodes published yet. Check back soon — new content is generated daily.'
          }
        </p>
      </div>
    );
  }

  const hero    = data.history[0];
  const rest    = data.history.slice(1);

  return (
    <>
      {/* Hero */}
      <div className="col-span-full">
        <HeroSection episode={hero} />
      </div>

      {/* Stats */}
      {data.activeShows?.length > 0 && (
        <div className="col-span-full">
          <StatsBar shows={data.activeShows} totalEpisodes={data.history.length} />
        </div>
      )}

      {/* Section heading */}
      {rest.length > 0 && (
        <div className="col-span-full flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-violet-light" />
            <h2 className="font-display text-xl font-bold text-white">More Episodes</h2>
          </div>
          <GenreFilter />
        </div>
      )}

      {/* Cards */}
      {rest.map((ep, i) => (
        <EpisodeCard key={ep.id || i} episode={ep} priority={i < 3} />
      ))}
    </>
  );
}

function LoadingGrid() {
  return (
    <>
      {/* Hero skeleton */}
      <div className="col-span-full">
        <div className="relative min-h-[70vh] rounded-3xl overflow-hidden shimmer mb-10" />
      </div>
      {/* Cards skeleton */}
      {Array.from({ length: 6 }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </>
  );
}

export default function HomePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page title */}
      <div className="mb-8 text-center">
        <h1 className="font-display text-5xl sm:text-6xl font-black text-white mb-3 leading-none">
          Stream<span className="gradient-text">Verse</span>
          <span className="block text-2xl sm:text-3xl font-light text-muted mt-1 tracking-widest uppercase">
            Studio
          </span>
        </h1>
        <p className="text-sm text-muted max-w-md mx-auto">
          Cinematic original series. New episodes daily.
        </p>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 stagger-in">
        <Suspense fallback={<LoadingGrid />}>
          <EpisodeGrid />
        </Suspense>
      </div>
    </div>
  );
}
