/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'res.cloudinary.com' },
      { protocol: 'https', hostname: '*.replit.app' },
      { protocol: 'https', hostname: '*.replit.dev' },
    ],
  },

  env: {
    // Support both NEXT_PUBLIC_BACKEND_URL and the legacy BACKEND_URL.
    NEXT_PUBLIC_BACKEND_URL:
      process.env.NEXT_PUBLIC_BACKEND_URL ||
      process.env.BACKEND_URL ||
      '',
  },

  // During local development, when no production backend URL is supplied,
  // forward /api/* requests to the local Express backend on port 3001.
  async rewrites() {
    const backendUrl =
      process.env.NEXT_PUBLIC_BACKEND_URL ||
      process.env.BACKEND_URL ||
      '';

    if (!backendUrl) {
      return [
        {
          source: '/api/:path*',
          destination: 'http://localhost:3001/api/:path*',
        },
      ];
    }

    return [];
  },

  // Replit-specific outputFileTracingRoot intentionally removed.
  // Netlify deploys this frontend as a standalone Next.js project,
  // so Next.js should use the project root as its tracing root.

  // Development-only origins. These do not affect production routing.
  allowedDevOrigins: [
    '127.0.0.1',
    'localhost',
    '*.replit.dev',
    '*.replit.app',
    '*.kirk.replit.dev',
    '*.repl.co',
  ],
};

module.exports = nextConfig;