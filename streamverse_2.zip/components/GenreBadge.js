import { getGenreClass, formatGenre } from '@/lib/api';

export default function GenreBadge({ genre, size = 'sm' }) {
  const cls = getGenreClass(genre);
  const label = formatGenre(genre);
  const sizes = {
    xs: 'text-[10px] px-2 py-0.5',
    sm: 'text-xs px-2.5 py-1',
    md: 'text-sm px-3 py-1',
  };

  return (
    <span className={`inline-flex items-center rounded-full font-semibold tracking-wide ${cls} ${sizes[size]}`}>
      {label}
    </span>
  );
}
