'use client';

// Client-side genre filter — future enhancement placeholder
// Currently shown as a decorative element; full filtering requires client state
export default function GenreFilter() {
  const genres = ['All', 'Drama', 'Thriller', 'Sci-Fi', 'Rom-Com'];
  return (
    <div className="flex items-center gap-1 overflow-x-auto pb-1">
      {genres.map((g, i) => (
        <button
          key={g}
          className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all duration-200 ${
            i === 0
              ? 'bg-violet/20 text-violet-light border border-violet/30'
              : 'glass border border-white/8 text-muted hover:text-white hover:border-white/20'
          }`}
        >
          {g}
        </button>
      ))}
    </div>
  );
}
