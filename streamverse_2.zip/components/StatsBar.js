import { Tv2, Film, Layers, TrendingUp } from 'lucide-react';

export default function StatsBar({ shows = [], totalEpisodes = 0 }) {
  const activeShows    = shows.filter(s => s.status === 'active').length;
  const totalEps       = shows.reduce((a, s) => a + (s.episode_count || 0), 0);
  const totalSeasons   = shows.reduce((a, s) => a + (s.current_season || 1), 0);

  const stats = [
    { icon: Tv2,       label: 'Active Shows',   value: activeShows || shows.length },
    { icon: Film,      label: 'Episodes',        value: totalEps || totalEpisodes   },
    { icon: Layers,    label: 'Seasons',         value: totalSeasons                },
    { icon: TrendingUp,label: 'Daily New',       value: '2+'                        },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
      {stats.map(({ icon: Icon, label, value }) => (
        <div
          key={label}
          className="glass rounded-xl border border-white/5 p-4 flex items-center gap-3 hover:border-violet/20 transition-colors duration-300"
        >
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-violet/20 to-cyan/10 flex items-center justify-center flex-shrink-0">
            <Icon size={16} className="text-violet-light" />
          </div>
          <div>
            <div className="text-lg font-bold text-white">{value}</div>
            <div className="text-[11px] text-muted">{label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
