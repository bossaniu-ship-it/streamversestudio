'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { User } from 'lucide-react';
import { useAuth } from './AuthContext';
import logo from './Logo/logo-icon.png';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [live, setLive]         = useState(false);
  const { user, loading }       = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });

    // Check backend live status via local Next.js proxy (avoids CORS)
    fetch('/api/health')
      .then(r => r.ok ? r.json() : null)
      .then(d => setLive(d?.ok === true))
      .catch(() => {});

    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass-strong shadow-lg shadow-black/50' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="relative w-9 h-9 rounded-lg overflow-hidden flex items-center justify-center shadow-glow-violet group-hover:shadow-glow-cyan transition-shadow duration-300">
              <Image
                src={logo}
                alt="StreamVerse Studio logo"
                fill
                sizes="36px"
                className="object-cover scale-125"
                priority
              />
            </div>
            <div>
              <span className="font-display font-bold text-lg tracking-wide text-white">
                Stream<span className="gradient-text">Verse</span>
              </span>
              <span className="block text-[10px] text-muted leading-none tracking-widest uppercase">
                Studio
              </span>
            </div>
          </Link>

          {/* Nav */}
          <nav className="hidden sm:flex items-center gap-1">
            <Link
              href="/"
              className="px-3 py-1.5 rounded-lg text-sm text-muted hover:text-white hover:bg-white/5 transition-all duration-200"
            >
              Episodes
            </Link>
            <Link
              href="/shows"
              className="px-3 py-1.5 rounded-lg text-sm text-muted hover:text-white hover:bg-white/5 transition-all duration-200"
            >
              Shows
            </Link>
          </nav>

          {/* Right: live badge + account */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full glass border border-white/10">
              <div className={`w-1.5 h-1.5 rounded-full ${live ? 'bg-green-400 animate-pulse' : 'bg-muted'}`} />
              <span className="text-[11px] font-medium text-muted">
                {live ? 'Live' : 'Studio'}
              </span>
            </div>

            {!loading && (
              user ? (
                <Link
                  href="/account"
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full glass border border-white/10 text-sm text-white/90 hover:border-violet/40 transition-colors"
                >
                  <User size={14} className="text-violet-light" />
                  <span className="hidden sm:inline max-w-[120px] truncate">
                    {user.displayName || user.email}
                  </span>
                </Link>
              ) : (
                <Link
                  href="/login"
                  className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-violet to-violet-dark text-white text-sm font-semibold shadow-glow-violet hover:shadow-glow-cyan transition-all duration-300"
                >
                  Sign In
                </Link>
              )
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
