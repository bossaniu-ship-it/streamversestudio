export default function SkeletonCard() {
  return (
    <div className="glass rounded-2xl overflow-hidden border border-white/5">
      <div className="aspect-video shimmer" />
      <div className="p-4 space-y-2">
        <div className="h-3 w-20 rounded-full shimmer" />
        <div className="h-4 w-3/4 rounded-full shimmer" />
        <div className="h-3 w-full rounded-full shimmer" />
        <div className="h-3 w-2/3 rounded-full shimmer" />
      </div>
    </div>
  );
}
