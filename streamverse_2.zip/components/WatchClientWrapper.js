'use client';

import dynamic from 'next/dynamic';

const VideoPlayer = dynamic(() => import('./VideoPlayer'), { ssr: false });

export default function WatchClientWrapper({ episode }) {
  return (
    <div className="rounded-2xl overflow-hidden shadow-2xl">
      <VideoPlayer episode={episode} />
    </div>
  );
}
