'use client';

import { Clapperboard, Film, Layers } from 'lucide-react';
import GenreBadge from './GenreBadge';

const genreGradients = {
  romcom:   'from-pink-500/20 to-rose-500/10',
  thriller: 'from-red-500/20 to-orange-500/10',
  'sci-fi': 'from-cyan-500/20 to-blue-500/10',
  drama:    'from-amber-500/20 to-yellow-500/10',
};

export default function ShowCard({ show }) {
  const g    = (show.genre || '').toLowerCase();
  const grad = genreGradients[g] || 'from-violet/20 to-violet/5';

  return (
    <div className={`glass rounded-2xl overflow-hidden border border-white/5 hover:border-white/10 transition-all duration-300 card-lift`}>
      {/* Gradient header */}
      <div className={`h-24 bg-gradient-to-br ${grad} flex items-end p-4 relative overflow-hidden`}>
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: 'radial-gradient(circle at 50% 100%, rgba(255,255,255,0.1) 0%, transparent 70%)'
        }} />
        <div className="relative">
          <div className="flex items-center gap-2 mb-1">
            <GenreBadge genre={show.genre} size="xs" />
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${
              show.status === 'active'
                ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                : 'bg-muted/20 text-muted border border-white/10'
            }`}>
              {show.status === 'active' ? '● Airing' : 'Completed'}
            </span>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="p-4">
        <h3 className="font-display font-bold text-white text-base mb-3 leading-tight">{show.title}</h3>

        <div className="grid grid-cols-3 gap-2">
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/3 border border-white/5">
            <Layers size={12} className="text-violet-light mb-1" />
            <span className="text-sm font-bold text-white">{show.current_season}</span>
            <span className="text-[10px] text-muted">Season</span>
          </div>
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/3 border border-white/5">
            <Film size={12} className="text-cyan mb-1" />
            <span className="text-sm font-bold text-white">{show.episode_count}</span>
            <span className="text-[10px] text-muted">Episodes</span>
          </div>
          <div className="flex flex-col items-center p-2 rounded-lg bg-white/3 border border-white/5">
            <Clapperboard size={12} className="text-gold mb-1" />
            <span className="text-sm font-bold text-white">S{show.current_season}E{show.current_episode}</span>
            <span className="text-[10px] text-muted">Latest</span>
          </div>
        </div>
      </div>
    </div>
  );
}
